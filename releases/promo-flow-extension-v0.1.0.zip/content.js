(() => {
  // src/lib/money.js
  var RUPEE_RE = /(?:₹|rs\.?|inr)\s*(\d[\d,]*)(?:\.(\d{1,2}))?/gi;
  function toPaise(whole, frac) {
    const w = String(whole).replace(/,/g, "");
    if (!w) return null;
    const paise = Number(w) * 100 + Number(String(frac || "").padEnd(2, "0"));
    return Number.isSafeInteger(paise) ? paise : null;
  }
  function findRupeeAmounts(text) {
    const out = [];
    if (text == null) return out;
    const s = String(text).replace(/ /g, " ");
    for (const m of s.matchAll(RUPEE_RE)) {
      const p = toPaise(m[1], m[2]);
      if (p != null) out.push(p);
    }
    return out;
  }
  function formatRupees(paise) {
    if (!Number.isInteger(paise)) return "";
    const neg = paise < 0;
    const abs = Math.abs(paise);
    const whole = String(Math.trunc(abs / 100));
    const frac = String(abs % 100).padStart(2, "0");
    let grouped = whole;
    if (whole.length > 3) {
      const last3 = whole.slice(-3);
      const rest = whole.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ",");
      grouped = `${rest},${last3}`;
    }
    return `${neg ? "-" : ""}\u20B9${grouped}.${frac}`;
  }
  function percentOf(amountPaise, basisPoints) {
    return Math.floor(amountPaise * basisPoints / 1e4);
  }

  // src/algorithms/Knapsack.js
  function applyOption(payable, opt) {
    if (Number.isInteger(opt.payableAfter)) {
      return opt.payableAfter <= payable ? opt.payableAfter : null;
    }
    if (opt.minSpend != null && payable < opt.minSpend) return null;
    let discount;
    if (opt.type === "percent") {
      discount = percentOf(payable, opt.value);
      if (opt.maxDiscount != null) discount = Math.min(discount, opt.maxDiscount);
    } else if (opt.type === "flat") {
      discount = opt.value;
    } else {
      return null;
    }
    discount = Math.max(0, Math.min(discount, payable));
    return payable - discount;
  }
  function bestCombination({ baseline, layers }) {
    let states = /* @__PURE__ */ new Map([[baseline, []]]);
    for (const options of layers) {
      const next = /* @__PURE__ */ new Map();
      for (const [payable, picks] of states) {
        if (!next.has(payable) || next.get(payable).length > picks.length) next.set(payable, picks);
        for (const opt of options) {
          if (opt.exclusive && picks.length > 0) continue;
          if (picks.some((x) => x.exclusive)) continue;
          const after = applyOption(payable, opt);
          if (after == null || after === payable) continue;
          const cand = [...picks, opt];
          const cur = next.get(after);
          if (!cur || cand.length < cur.length || cand.length === cur.length && cand.map((x) => x.id).join() < cur.map((x) => x.id).join()) {
            next.set(after, cand);
          }
        }
      }
      states = next;
    }
    let bestPayable = baseline;
    let bestPicks = [];
    for (const [payable, picks] of states) {
      if (payable < bestPayable || payable === bestPayable && picks.length < bestPicks.length) {
        bestPayable = payable;
        bestPicks = picks;
      }
    }
    return { payable: bestPayable, saving: baseline - bestPayable, picks: bestPicks };
  }

  // src/lib/offerParser.js
  var BANKS = [
    "HDFC",
    "ICICI",
    "SBI",
    "Axis",
    "Kotak",
    "Yes Bank",
    "IDFC",
    "Federal",
    "AU Small",
    "RBL",
    "IndusInd",
    "Bank of Baroda",
    "BOB",
    "American Express",
    "Amex",
    "Citi",
    "HSBC",
    "Standard Chartered",
    "OneCard",
    "Paytm",
    "Amazon Pay",
    "PhonePe",
    "Google Pay",
    "BHIM"
  ];
  var RS = "(?:\u20B9|rs\\.?|inr)\\s*";
  var NUM = "(\\d[\\d,]*)";
  var toPaise2 = (s) => Number(String(s).replace(/,/g, "")) * 100;
  function parseOffer(rawText) {
    const t2 = String(rawText ?? "").replace(/\s+/g, " ").trim();
    if (!t2) return null;
    const issuer = BANKS.find((b) => new RegExp(`\\b${b.replace(/ /g, "\\s+")}\\b`, "i").test(t2)) ?? null;
    const cardType = /credit/i.test(t2) ? "credit" : /debit/i.test(t2) ? "debit" : null;
    const cashback = /cash\s*back|reward points?|super\s*coins?|\bcoins?\b/i.test(t2) && !/instant/i.test(t2);
    const pct = t2.match(/(\d{1,2}(?:\.\d+)?)\s*%/);
    const upTo = t2.match(new RegExp(`up\\s*to\\s*${RS}${NUM}`, "i"));
    const flat = t2.match(new RegExp(`${RS}${NUM}\\s*(?:instant\\s*)?(?:off|discount)`, "i"));
    const min = t2.match(
      new RegExp(
        `(?:min(?:imum)?\\.?\\s*(?:purchase|order|spend|transaction|cart)?\\s*(?:value|amount)?\\s*(?:of)?|(?:orders?|purchases?|shopping)\\s*(?:of|above|over|worth)|above|over)\\s*:?\\s*${RS}${NUM}`,
        "i"
      )
    );
    let type = null;
    let value = null;
    let maxDiscount = null;
    if (pct) {
      type = "percent";
      value = Math.round(Number(pct[1]) * 100);
      if (upTo) maxDiscount = toPaise2(upTo[1]);
      else if (flat) maxDiscount = toPaise2(flat[1]);
    } else if (flat) {
      type = "flat";
      value = toPaise2(flat[1]);
    }
    if (!type) return null;
    return {
      raw: t2,
      issuer,
      cardType,
      kind: cashback ? "cashback" : "instant",
      type,
      value,
      maxDiscount,
      minSpend: min ? toPaise2(min[1]) : null
    };
  }
  function estimateSaving(offer, payable) {
    if (!offer || offer.kind !== "instant") return 0;
    if (offer.minSpend != null && payable < offer.minSpend) return 0;
    let d = offer.type === "percent" ? percentOf(payable, offer.value) : offer.value;
    if (offer.type === "percent" && offer.maxDiscount != null) d = Math.min(d, offer.maxDiscount);
    return Math.max(0, Math.min(d, payable));
  }

  // src/content/domDetector.js
  var PROMO_WORDS = /coupon|promo|voucher|discount|reduction|offer\s*code/i;
  var WEAK_WORDS = /gift\s*card|\bcode\b/i;
  var NEGATIVE = /search|e-?mail|phone|mobile|pin\s*code|zip|otp|password|address|first\s*name|last\s*name|\bcard\s*number\b|cvv|expiry/i;
  var BAD_TYPES = /* @__PURE__ */ new Set(["password", "email", "tel", "search", "number", "hidden", "checkbox", "radio", "file"]);
  var APPLY_WORDS = /apply|redeem|submit|check|add|use|ok|go/i;
  var STRONG_APPLY = /apply|redeem/i;
  var TOGGLE_WORDS = /(have|got|add|enter|use|apply)\s+(a\s+|your\s+)?(promo|coupon|voucher|discount|gift)/i;
  var TOTAL_LABEL = /(order\s*total|grand\s*total|amount\s*payable|total\s*payable|total\s*amount|you\s*pay|to\s*pay|net\s*payable|^total\b)/i;
  var NOT_TOTAL = /sub\s*-?\s*total|saving|you\s*save|discount|coupon|shipping|delivery|tax\b|gst|fee\b/i;
  var OFFER_WORDS = /(bank|card|upi|wallet)\s*offer|instant\s*discount|cash\s*back|%\s*(instant\s*)?(off|discount)|flat\s*₹|₹\s*[\d,]+\s*off/i;
  function isVisible(el) {
    if (!el || !el.ownerDocument) return false;
    const win = el.ownerDocument.defaultView;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      if (n.hidden) return false;
      const cs = win.getComputedStyle(n);
      if (cs.display === "none" || cs.visibility === "hidden") return false;
    }
    return true;
  }
  function labelText(input) {
    const doc = input.ownerDocument;
    const parts = [];
    if (input.id) {
      const esc = doc.defaultView?.CSS?.escape;
      const l = doc.querySelector(`label[for="${esc ? esc(input.id) : input.id.replace(/"/g, "")}"]`);
      if (l) parts.push(l.textContent);
    }
    const wrap = input.closest("label");
    if (wrap) parts.push(wrap.textContent);
    return parts.join(" ");
  }
  function inputSignals(input) {
    return [
      input.name,
      input.id,
      input.placeholder,
      input.getAttribute("aria-label"),
      input.getAttribute("data-testid"),
      input.title,
      input.getAttribute("autocomplete"),
      labelText(input)
    ].filter(Boolean).join(" ");
  }
  function scorePromoInput(input) {
    const type = (input.getAttribute("type") || "text").toLowerCase();
    if (BAD_TYPES.has(type)) return -10;
    const s = inputSignals(input);
    let score = 0;
    if (PROMO_WORDS.test(s)) score += 3;
    if (WEAK_WORDS.test(s)) score += 1;
    if (NEGATIVE.test(s)) score -= 5;
    return score;
  }
  function findPromoField(doc) {
    let best = null;
    for (const input of doc.querySelectorAll("input")) {
      if (!isVisible(input)) continue;
      const score = scorePromoInput(input);
      if (score >= 3 && (!best || score > best.score)) best = { input, score };
    }
    if (!best) return null;
    return { input: best.input, button: findApplyButton(best.input) };
  }
  function findApplyButton(input) {
    const sel = "button, input[type=submit], input[type=button], [role=button]";
    let scope = input.parentElement;
    for (let depth = 0; scope && depth < 5; depth++, scope = scope.parentElement) {
      const buttons = [...scope.querySelectorAll(sel)].filter((b) => b !== input && isVisible(b));
      const text = (b) => `${b.textContent || ""} ${b.value || ""} ${b.getAttribute("aria-label") || ""}`.trim();
      const strong = buttons.find((b) => STRONG_APPLY.test(text(b)));
      if (strong) return strong;
      const weak = buttons.find((b) => APPLY_WORDS.test(text(b)) && !/remove|clear|cancel/i.test(text(b)));
      if (weak) return weak;
      if (scope.tagName === "FORM") break;
    }
    return null;
  }
  function findPromoToggle(doc) {
    const els = doc.querySelectorAll("button, a, summary, [role=button], [aria-expanded]");
    for (const el of els) {
      if (!isVisible(el)) continue;
      const t2 = (el.textContent || "").replace(/\s+/g, " ").trim();
      if (t2.length < 80 && TOGGLE_WORDS.test(t2)) return el;
    }
    return null;
  }
  function readTotalPaise(doc, { selectors = [] } = {}) {
    for (const sel of selectors) {
      let el = null;
      try {
        el = doc.querySelector(sel);
      } catch {
      }
      if (el && isVisible(el)) {
        const amounts = findRupeeAmounts(el.textContent);
        if (amounts.length) return amounts[amounts.length - 1];
      }
    }
    let best = null;
    for (const el of doc.body.querySelectorAll("tr, li, div, p, span, dd, dl, section")) {
      const text = (el.textContent || "").replace(/\s+/g, " ").trim();
      if (text.length > 140 || !TOTAL_LABEL.test(text)) continue;
      const core = text.replace(/\([^)]*\)/g, " ").replace(/incl(?:uding|usive|\.)?\s*(?:of\s*)?(?:all\s*)?(?:taxes|tax|gst)?/gi, " ");
      if (NOT_TOTAL.test(core.replace(TOTAL_LABEL, " "))) continue;
      if (!isVisible(el)) continue;
      const amounts = findRupeeAmounts(text);
      if (!amounts.length) continue;
      if (!best || text.length <= best.len) best = { len: text.length, value: amounts[amounts.length - 1] };
    }
    return best ? best.value : null;
  }
  function readPromoMessage(doc, input) {
    const parts = [];
    for (const el of doc.querySelectorAll("[role=alert], [role=status], [aria-live]")) {
      if (isVisible(el) && el.textContent.trim()) parts.push(el.textContent.trim());
    }
    let scope = input ? input.parentElement : null;
    for (let d = 0; scope && d < 3; d++, scope = scope.parentElement) {
      const t2 = scope.textContent.replace(/\s+/g, " ").trim();
      if (t2.length < 300) {
        parts.push(t2);
        break;
      }
    }
    return parts.join(" | ");
  }
  function readOfferTexts(root, limit = 8) {
    const scope = root.body || root;
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const el of scope.querySelectorAll("p, li, div, span, label")) {
      const t2 = (el.textContent || "").replace(/\s+/g, " ").trim();
      if (t2.length < 20 || t2.length > 260 || !OFFER_WORDS.test(t2) || seen.has(t2)) continue;
      if ([...el.children].some((c) => OFFER_WORDS.test(c.textContent || ""))) continue;
      if (!isVisible(el)) continue;
      seen.add(t2);
      out.push(t2);
      if (out.length >= limit) break;
    }
    return out;
  }
  function looksLikeCaptcha(doc) {
    const sel = 'iframe[src*="recaptcha"], iframe[src*="hcaptcha"], .g-recaptcha, #captcha, [id*="captcha" i]';
    if ([...doc.querySelectorAll(sel)].some((el) => isVisible(el))) return true;
    let t2 = doc.body.innerText;
    if (typeof t2 !== "string") {
      t2 = "";
      const w = doc.createTreeWalker(doc.body, 4);
      while (t2.length < 4e3 && w.nextNode()) {
        const n = w.currentNode;
        if (n.nodeValue.trim() && isVisible(n.parentElement)) t2 += ` ${n.nodeValue}`;
      }
    }
    t2 = t2.slice(0, 4e3);
    return /are you a robot|verify (that )?you are human|unusual traffic|enter the characters you see/i.test(t2);
  }
  function findRemoveControl(doc, input) {
    const sel = "a, button, [role=button], span[role=link]";
    let scope = input ? input.parentElement : doc.body;
    for (let d = 0; scope && d < 6; d++, scope = scope.parentElement) {
      for (const el of scope.querySelectorAll(sel)) {
        const t2 = `${el.textContent || ""} ${el.getAttribute("aria-label") || ""}`.trim();
        if (isVisible(el) && /^(remove|clear|delete|×|✕|x)\b|\bremove\b/i.test(t2) && t2.length < 40) return el;
      }
    }
    return null;
  }

  // src/adapters/recipe.js
  var TAG_RE = /^[a-z][a-z0-9-]{0,20}$/i;
  function visibleText(el) {
    const doc = el.ownerDocument;
    const w = doc.createTreeWalker(el, 4);
    let out = "";
    while (w.nextNode()) {
      const n = w.currentNode;
      if (n.nodeValue.trim() && isVisible(n.parentElement)) out += ` ${n.nodeValue}`;
    }
    return out;
  }
  var MAX_TEXT_CANDIDATES = 50;
  var norm = (s) => String(s || "").replace(/\s+/g, " ").trim().toLowerCase();
  function locateAll(root, loc) {
    if (!root || !loc) return [];
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    const add = (el) => {
      if (el && !seen.has(el) && isVisible(el)) {
        seen.add(el);
        out.push(el);
      }
    };
    if (loc.css) {
      let found = [];
      try {
        found = [...root.querySelectorAll(loc.css)];
      } catch {
        found = [];
      }
      found.forEach(add);
      if (out.length) return out;
    }
    if (loc.text?.length) {
      const needles = loc.text.map(norm).filter(Boolean);
      const sel = loc.tag?.length ? loc.tag.filter((t2) => TAG_RE.test(t2)).join(",") : "*";
      let els = [];
      try {
        els = [...root.querySelectorAll(sel || "*")];
      } catch {
        els = [];
      }
      const hits = [];
      for (const el of els) {
        if (/^(script|style|noscript|head|meta|link|title)$/i.test(el.tagName)) continue;
        const t2 = norm(el.textContent);
        if (!t2 || !needles.some((n) => t2.includes(n))) continue;
        hits.push({ el, len: t2.length, i: hits.length });
      }
      hits.sort((a, b) => a.len - b.len || a.i - b.i);
      for (const h of hits.slice(0, MAX_TEXT_CANDIDATES)) {
        const vt = norm(visibleText(h.el));
        if (needles.some((n) => vt.includes(n))) add(h.el);
      }
    }
    return out;
  }
  function locate(root, loc) {
    return locateAll(root, loc)[0] ?? null;
  }
  function pageKind(recipe, pathname) {
    const path = String(pathname || "");
    for (const kind of ["bag", "payment"]) {
      const prefixes = recipe?.pages?.[kind]?.pathPrefixes;
      if (prefixes?.some((p) => path.startsWith(p))) return kind;
    }
    return null;
  }

  // src/algorithms/Trie.js
  var normalizeCode = (code) => String(code ?? "").trim().toUpperCase();

  // src/content/setValue.js
  function setNativeValue(input, value) {
    const win = input.ownerDocument.defaultView;
    const desc = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), "value") || Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, "value");
    input.focus?.();
    desc.set.call(input, value);
    input.dispatchEvent(new win.Event("input", { bubbles: true }));
    input.dispatchEvent(new win.Event("change", { bubbles: true }));
  }

  // src/content/drivers.js
  var CODE_RE = /^[A-Z0-9_-]{3,32}$/;
  var norm2 = (s) => String(s || "").replace(/\s+/g, " ").trim().toLowerCase();
  var defaultSleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function pressEnter(input) {
    input.dispatchEvent(new input.ownerDocument.defaultView.KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
  }
  function genericDriver(doc, adapter, overrides = {}, { sleep = defaultSleep, settleMs = 4e3 } = {}) {
    let field = null;
    const stillThere = () => field && field.input.isConnected && field.input.ownerDocument === doc;
    return {
      kind: "generic",
      limits: null,
      panelClosesOnApply: false,
      async ensureOpen() {
        if (stillThere()) return true;
        field = adapter.findField(doc, overrides);
        if (!field) {
          const toggle = adapter.findToggle(doc);
          if (toggle) {
            toggle.click();
            await sleep(Math.min(400, settleMs));
            field = adapter.findField(doc, overrides);
          }
        }
        return !!field;
      },
      panelOpen: () => null,
      listCodes: () => [],
      async apply(code) {
        setNativeValue(field.input, code);
        if (field.button) field.button.click();
        else pressEnter(field.input);
      },
      readTotal: () => adapter.readTotal(doc, overrides),
      readOffers: () => adapter.readOffers(doc),
      readMessage: () => readPromoMessage(doc, field?.input),
      isApplied: () => !!(field && findRemoveControl(doc, field.input)),
      appliedText() {
        const ctl = field && findRemoveControl(doc, field.input);
        return ctl?.parentElement?.textContent?.replace(/\s+/g, " ").trim() ?? "";
      },
      async remove() {
        const ctl = field && findRemoveControl(doc, field.input);
        if (!ctl) return false;
        ctl.click();
        return true;
      },
      loginRequired: () => false,
      captcha: () => looksLikeCaptcha(doc)
    };
  }
  function recipeDriver(doc, recipe, { sleep = defaultSleep, pollMs = 100, openWaitMs = 3e3 } = {}) {
    const c = recipe.coupon;
    const reachable = () => !!(locate(doc, c.input) || c.listed && locate(doc, c.listed.item));
    const items = () => c.listed ? locateAll(doc, c.listed.item) : [];
    function itemCode(item) {
      const spec = c.listed.code;
      const raw = spec.attr ? item.getAttribute(spec.attr) : item.querySelector(spec.css)?.textContent;
      const code = normalizeCode(raw);
      return CODE_RE.test(code) ? code : null;
    }
    return {
      kind: "recipe",
      limits: recipe.limits,
      panelClosesOnApply: !!c.panelClosesOnApply,
      async ensureOpen() {
        const settle = async (from) => {
          if (!c.listed) return;
          while (!items().length && Date.now() - from < openWaitMs) await sleep(pollMs);
        };
        if (reachable()) {
          await settle(Date.now());
          return true;
        }
        const opener = locate(doc, c.open);
        if (!opener) return false;
        opener.click();
        const start = Date.now();
        while (!reachable() && Date.now() - start < openWaitMs) await sleep(pollMs);
        if (!reachable()) return false;
        await settle(start);
        return true;
      },
      panelOpen: () => c.panel ? !!locate(doc, c.panel) : null,
      listCodes() {
        if (!c.listed) return [];
        const seen = /* @__PURE__ */ new Set();
        const out = [];
        for (const item of items()) {
          const code = itemCode(item);
          if (!code || seen.has(code)) continue;
          seen.add(code);
          const text = norm2(item.textContent);
          out.push({ code, eligible: !c.listed.ineligibleText.some((t2) => text.includes(norm2(t2))) });
        }
        return out;
      },
      async apply(code) {
        const item = c.listed ? items().find((i) => itemCode(i) === code) : null;
        const pick = item && c.listed.select ? locate(item, c.listed.select) : null;
        const input = locate(doc, c.input);
        if (pick && !pick.disabled) pick.click();
        else if (input) setNativeValue(input, code);
        const button = locate(doc, c.apply);
        if (button) button.click();
        else if (input) pressEnter(input);
        if (c.applyConfirm) {
          const from = Date.now();
          let ok = locate(doc, c.applyConfirm);
          while ((!ok || ok.disabled) && Date.now() - from < 2e3) {
            await sleep(pollMs);
            ok = locate(doc, c.applyConfirm);
          }
          if (ok && !ok.disabled) ok.click();
        }
      },
      readTotal() {
        const el = locate(doc, recipe.total);
        if (el) {
          const amounts = findRupeeAmounts(el.textContent);
          if (amounts.length) return amounts[amounts.length - 1];
        }
        return readTotalPaise(doc);
      },
      readMessage: () => c.message ? locateAll(doc, c.message).map((e) => e.textContent.replace(/\s+/g, " ").trim()).filter(Boolean).join(" | ") : "",
      isApplied: () => !!locate(doc, c.applied || c.remove),
      // Every visible match, not just the shortest: an open coupon panel can show a bare "Coupon applied" message
      // while the chip that names the code sits elsewhere on the page.
      appliedText() {
        const all = c.applied ? locateAll(doc, c.applied) : [];
        const els = all.filter((el) => !all.some((o) => o !== el && el.contains(o)));
        if (!els.length && c.remove) {
          const r = locate(doc, c.remove)?.parentElement;
          if (r) els.push(r);
        }
        return els.map((el) => el.textContent.replace(/\s+/g, " ").trim()).filter(Boolean).join(" | ");
      },
      async remove() {
        const ctl = locate(doc, c.remove);
        if (ctl) {
          ctl.click();
          return true;
        }
        if (!c.deselect) return false;
        if (!await this.ensureOpen()) return false;
        const tick = locate(doc, c.deselect);
        if (!tick) return false;
        tick.click();
        const ok = locate(doc, c.confirm);
        if (ok) ok.click();
        return true;
      },
      // With a recipe, offers are read ONLY from the recipe's offers container (coupon list entries look like offers otherwise).
      readOffers() {
        if (!recipe.offers?.container) return [];
        const box = locate(doc, recipe.offers.container);
        if (!box) return [];
        if (recipe.offers.item) {
          const seen = /* @__PURE__ */ new Set();
          const out = [];
          for (const el of locateAll(box, recipe.offers.item)) {
            const parts = [];
            const w = doc.createTreeWalker(el, 4);
            while (w.nextNode()) if (w.currentNode.nodeValue.trim()) parts.push(w.currentNode.nodeValue.trim());
            const t2 = parts.join(" ").replace(/\s+/g, " ").trim();
            if (t2 && !seen.has(t2)) {
              seen.add(t2);
              out.push(t2);
            }
            if (out.length >= 20) break;
          }
          return out;
        }
        return readOfferTexts(box);
      },
      loginRequired: () => !!(recipe.loginWall && locate(doc, recipe.loginWall)),
      captcha: () => looksLikeCaptcha(doc)
    };
  }

  // src/background/candidates.js
  var CODE_RE2 = /^[A-Z0-9_-]{3,32}$/;
  var USER_ORIGIN = "user";
  function mergeCandidates({ known = [], listed = [] } = {}, cap = 10) {
    const knownNorm = known.map((k) => typeof k === "string" ? { code: k, origin: "known" } : k).map((k) => ({ code: normalizeCode(k?.code), origin: k?.origin || "known" })).filter((k) => k.code.length > 0);
    const listedNorm = listed.map((l) => ({ code: normalizeCode(l?.code), eligible: l?.eligible !== false })).filter((l) => CODE_RE2.test(l.code));
    const skipped = [...new Set(listedNorm.filter((l) => !l.eligible).map((l) => l.code))];
    const skip = new Set(skipped);
    const ordered = [
      ...knownNorm.filter((k) => k.origin === USER_ORIGIN),
      ...listedNorm.filter((l) => l.eligible).map((l) => ({ code: l.code, origin: "listed" })),
      ...knownNorm.filter((k) => k.origin !== USER_ORIGIN)
    ];
    const seen = /* @__PURE__ */ new Set();
    const list = [];
    for (const c of ordered) {
      if (seen.has(c.code) || skip.has(c.code)) continue;
      seen.add(c.code);
      list.push(c);
      if (list.length >= cap) break;
    }
    return { list, skipped };
  }

  // src/content/applyEngine.js
  var OUTCOME = Object.freeze({
    APPLIED: "applied",
    INVALID: "invalid",
    EXPIRED: "expired",
    MIN_SPEND: "min_spend_not_met",
    NOT_APPLICABLE: "not_applicable",
    NO_EFFECT: "no_effect"
  });
  var RE_EXPIRED = /expired|no longer valid|has ended/i;
  var RE_MIN = /minimum|min\.?\s*(order|purchase|spend|cart|value)|at least|spend .{0,20}more|add .{0,20}more/i;
  var RE_NOT_APPLICABLE = /not applicable|cannot be applied|can'?t be applied|not eligible|only valid|already applied|already used|not valid for/i;
  var RE_INVALID = /invalid|incorrect|doesn'?t exist|does not exist|not found|unable to apply|couldn'?t apply|not recogni[sz]ed|wrong/i;
  var RE_RATE_LIMITED = /too many|try again later/i;
  var RE_FINAL = new RegExp(
    [RE_EXPIRED, RE_MIN, RE_NOT_APPLICABLE, RE_INVALID, RE_RATE_LIMITED, /applied|success|saved/i].map((r) => r.source).join("|"),
    "i"
  );
  function classify({ before, after, message }) {
    if (after != null && before != null && after < before) return OUTCOME.APPLIED;
    const m = message || "";
    if (RE_EXPIRED.test(m)) return OUTCOME.EXPIRED;
    if (RE_MIN.test(m)) return OUTCOME.MIN_SPEND;
    if (RE_NOT_APPLICABLE.test(m)) return OUTCOME.NOT_APPLICABLE;
    if (RE_INVALID.test(m)) return OUTCOME.INVALID;
    return OUTCOME.NO_EFFECT;
  }
  var defaultSleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
  var RATE_LIMITED = RE_RATE_LIMITED;
  var HANDS_OFF = /* @__PURE__ */ new Set(["blocked_captcha", "rate_limited", "login_required"]);
  async function runSearch({ doc, adapter, overrides = {}, recipe = null, candidates, exclude = [], signal, onProgress = () => {
  }, cfg = {}, now = Date.now() }) {
    const base = {
      maxAttempts: 10,
      delayMs: 500,
      jitterMs: 250,
      settleMs: 4e3,
      pollMs: 100,
      stableMs: 300,
      minWaitMs: 700,
      sleep: defaultSleep2,
      random: Math.random,
      ...cfg
    };
    const useRecipe = !!recipe && pageKind(recipe, doc.location?.pathname) === "bag";
    const driver = useRecipe ? recipeDriver(doc, recipe, { sleep: base.sleep, pollMs: base.pollMs }) : genericDriver(doc, adapter, overrides, { sleep: base.sleep, settleMs: base.settleMs });
    const c = { ...base };
    for (const k of ["maxAttempts", "delayMs", "jitterMs"]) {
      if (cfg[k] === void 0 && driver.limits?.[k] !== void 0) c[k] = driver.limits[k];
    }
    const aborted = () => !!signal?.aborted;
    const readTotal = () => driver.readTotal();
    async function waitFor(pred, timeoutMs) {
      const start = Date.now();
      for (; ; ) {
        const elapsed = Date.now() - start;
        if (pred(elapsed)) return true;
        if (elapsed >= timeoutMs) return false;
        await c.sleep(c.pollMs);
      }
    }
    if (driver.loginRequired()) return { status: "login_required" };
    if (driver.captcha()) return { status: "blocked_captcha" };
    if (!await driver.ensureOpen()) return { status: "no_promo_field" };
    if (driver.loginRequired()) return { status: "login_required" };
    if (readTotal() == null) return { status: "no_total" };
    const known = (candidates || []).map((x) => typeof x === "string" ? { code: x, origin: "known" } : x);
    const skipCodes = new Set(exclude.map((x) => String(x).trim().toUpperCase()));
    const notExcluded = (x) => !skipCodes.has(String(x.code).trim().toUpperCase());
    const listedNow = () => driver.listCodes().filter(notExcluded);
    let preApplied = null;
    if (driver.isApplied()) {
      const text = driver.appliedText().toUpperCase();
      const pool = [...known.map((k) => String(k.code).trim().toUpperCase()), ...driver.listCodes().map((l) => l.code)];
      const code = pool.filter((k) => k && text.includes(k)).sort((a, b) => b.length - a.length)[0] ?? null;
      preApplied = { code };
    }
    const first = mergeCandidates({ known: known.filter(notExcluded), listed: listedNow() }, c.maxAttempts);
    if (!first.list.length && !preApplied?.code) return { status: "no_codes", baseline: readTotal(), skipped: first.skipped };
    if (preApplied) {
      const before = readTotal();
      await driver.remove();
      await waitFor(() => readTotal() !== before, c.settleMs);
      await driver.ensureOpen();
    }
    const baseline = readTotal();
    if (baseline == null) return { status: "no_total" };
    const tooSmall = [];
    const usable = known.filter(notExcluded).filter((k) => {
      if (k.expiresAt != null && k.expiresAt < now) return false;
      if (Number.isInteger(k.minSpend) && k.minSpend > baseline) {
        tooSmall.push(String(k.code).toUpperCase());
        return false;
      }
      return true;
    });
    const listedAfter = listedNow();
    const merged = mergeCandidates({ known: usable, listed: listedAfter }, c.maxAttempts);
    let list = merged.list;
    if (preApplied?.code && !list.some((x) => x.code === preApplied.code)) {
      list = [{ code: preApplied.code, origin: "preapplied" }, ...list].slice(0, c.maxAttempts);
    }
    if (!list.length) return { status: "no_codes", baseline, skipped: merged.skipped, skippedMinSpend: tooSmall };
    const trial = async (code) => {
      const before = readTotal();
      const msgBefore = driver.readMessage();
      const panelWasOpen = driver.panelOpen();
      let lastMsg = "";
      await driver.apply(code);
      await waitFor((elapsed) => {
        if (readTotal() !== before) return true;
        if (driver.panelClosesOnApply && panelWasOpen && driver.panelOpen() === false) return true;
        const m = driver.readMessage();
        if (m) lastMsg = m;
        if (!RE_FINAL.test(m)) return false;
        return m !== msgBefore || elapsed >= c.minWaitMs;
      }, c.settleMs);
      await c.sleep(c.stableMs);
      return { before, after: readTotal(), message: driver.readMessage() || lastMsg };
    };
    const results = [];
    let stopped = null;
    for (let i = 0; i < list.length; i++) {
      if (aborted()) {
        stopped = "aborted";
        break;
      }
      if (driver.captcha()) {
        stopped = "blocked_captcha";
        break;
      }
      if (driver.loginRequired()) {
        stopped = "login_required";
        break;
      }
      const { code, origin } = list[i];
      onProgress({ phase: "trying", n: i + 1, total: list.length, code });
      if (!await driver.ensureOpen()) {
        stopped = "panel_unavailable";
        break;
      }
      const r = await trial(code);
      const outcome = classify(r);
      if (outcome !== OUTCOME.APPLIED && RATE_LIMITED.test(r.message || "")) {
        stopped = "rate_limited";
        break;
      }
      const entry = { code, origin, outcome, payable: outcome === OUTCOME.APPLIED ? r.after : null, saving: outcome === OUTCOME.APPLIED ? baseline - r.after : 0 };
      results.push(entry);
      onProgress({ phase: "result", ...entry });
      if (outcome === OUTCOME.APPLIED) {
        if (driver.panelClosesOnApply && driver.panelOpen()) await waitFor(() => driver.panelOpen() === false, Math.min(c.settleMs, 2e3));
        const removed = await driver.remove();
        const restored = removed && await waitFor(() => readTotal() === baseline, c.settleMs);
        if (!restored) {
          stopped = "could_not_restore";
          break;
        }
      }
      if (i < list.length - 1) await c.sleep(c.delayMs + Math.floor(c.random() * c.jitterMs));
    }
    const applied = results.filter((r) => r.outcome === OUTCOME.APPLIED);
    const offers = driver.readOffers().map(parseOffer).filter((o) => o && o.kind === "instant");
    const couponOpts = applied.map((r) => ({ id: r.code, payableAfter: r.payable }));
    const offerOpts = offers.map((o, i) => ({ id: `offer:${i}`, ...o }));
    const combo = bestCombination({ baseline, layers: [couponOpts, offerOpts] });
    const couponPick = combo.picks.find((p) => !String(p.id).startsWith("offer:")) ?? null;
    const offerPick = combo.picks.find((p) => String(p.id).startsWith("offer:")) ?? null;
    let finalApplied = false;
    let finalPayable = readTotal();
    if (couponPick && !aborted() && stopped !== "could_not_restore" && !HANDS_OFF.has(stopped) && await driver.ensureOpen()) {
      const before = readTotal();
      await driver.apply(couponPick.id);
      await waitFor(() => readTotal() !== before, c.settleMs);
      await c.sleep(c.stableMs);
      finalPayable = readTotal();
      finalApplied = finalPayable === couponPick.payableAfter;
    }
    const basePayable = finalApplied ? finalPayable : baseline;
    const offerSaving = offerPick ? estimateSaving(offerPick, basePayable) : 0;
    const summary = {
      status: "ok",
      stopped,
      baseline,
      results,
      skipped: merged.skipped,
      skippedMinSpend: tooSmall.filter((x) => !merged.skipped.includes(x)),
      tried: results.map((r) => r.code),
      cap: c.maxAttempts,
      // Codes still untried for this cart (for "Try more"). Codes tried before this run were excluded already.
      remaining: mergeCandidates({ known: usable, listed: listedAfter }, 1e3).list.filter((x) => !results.some((r) => r.code === x.code)).length,
      coupon: couponPick ? { code: couponPick.id, payable: couponPick.payableAfter, saving: baseline - couponPick.payableAfter, origin: results.find((r) => r.code === couponPick.id)?.origin } : null,
      offer: offerPick && offerSaving > 0 ? { text: offerPick.raw, issuer: offerPick.issuer, estimatedSaving: offerSaving } : null,
      estimatedPayable: basePayable - offerSaving,
      finalPayable,
      finalApplied,
      preAppliedLost: !!preApplied && !finalApplied
    };
    onProgress({ phase: "done", summary });
    return summary;
  }

  // src/adapters/index.js
  function firstVisible(doc, selectors) {
    for (const s of selectors) {
      if (!s) continue;
      try {
        const el = doc.querySelector(s);
        if (el && isVisible(el)) return el;
      } catch {
      }
    }
    return null;
  }
  function makeAdapter({ id, hostRe, checkoutRe = null, totalSelectors = [], inputSelectors = [], buttonSelectors = [], unverified = false }) {
    return {
      id,
      unverified,
      matches: (host) => hostRe.test(host),
      /** True when the URL looks like a cart/checkout/payment step. The generic adapter always says yes (the user clicked). */
      isCheckout: (loc) => checkoutRe ? checkoutRe.test(`${loc.pathname}${loc.search}`) : true,
      findField(doc, overrides = {}) {
        const input = firstVisible(doc, [overrides.input, ...inputSelectors]);
        if (!input) return findPromoField(doc);
        const button = firstVisible(doc, [overrides.button, ...buttonSelectors]) ?? findApplyButton(input);
        return { input, button };
      },
      readTotal: (doc, overrides = {}) => readTotalPaise(doc, { selectors: [overrides.total, ...totalSelectors].filter(Boolean) }),
      readOffers: (doc) => readOfferTexts(doc),
      findToggle: (doc) => findPromoToggle(doc)
    };
  }
  var generic = makeAdapter({ id: "generic", hostRe: /./ });
  var amazon = makeAdapter({
    id: "amazon",
    hostRe: /(^|\.)amazon\.(in|com)$/i,
    checkoutRe: /\/(gp\/buy|checkout|gp\/cart|cart)/i,
    inputSelectors: ['input[name="ppw-claimCode"]'],
    buttonSelectors: ['input[name="ppw-claimCodeApplyPressed"]'],
    unverified: true
  });
  var flipkart = makeAdapter({
    id: "flipkart",
    hostRe: /(^|\.)flipkart\.com$/i,
    checkoutRe: /(checkout|viewcart|payments)/i,
    unverified: true
  });
  var ADAPTERS = [amazon, flipkart];
  function pickAdapter(hostname) {
    const host = String(hostname || "").toLowerCase().replace(/^www\./, "");
    return ADAPTERS.find((a) => a.matches(host)) ?? generic;
  }
  function normalizeHost(hostname) {
    return String(hostname || "").toLowerCase().replace(/^www\./, "");
  }

  // src/i18n/en.json
  var en_default = {
    appName: "Promo-Flow",
    tagline: "Finds the best coupon and bank offer at checkout",
    find: "Find best savings",
    stop: "Stop",
    language: "Language",
    yourCodes: "My coupon codes",
    yourCodesHint: "One code per line. Only codes you already have.",
    addCode: "Save",
    telemetry: "Share anonymous results",
    telemetryHint: "Sends only: store, code, worked or not. No personal data.",
    apiBase: "Server address",
    working: "Working\u2026",
    trying: "Trying {code} ({n}/{total})",
    noField: "Couldn't find a promo-code box on this page. Open the payment/checkout step and try again.",
    captcha: "The site is asking for a verification check. Stopped so you can finish it yourself.",
    noTotal: "Couldn't read the payable total on this page.",
    noCodes: "No codes to try for this store. Add your own codes in the popup.",
    done: "Done",
    before: "Before",
    after: "After",
    youSave: "You save",
    bankOffer: "Bank/payment offer",
    bankHint: "Estimated from the offer text. Pay with that card/method to get it; not applied by Promo-Flow.",
    couponApplied: "Coupon applied",
    noneWorked: "No code worked on this cart.",
    estimate: "Estimate",
    close: "Close",
    stopped: "Stopped.",
    unverifiedSite: "This site's support is experimental. Check the final total before paying.",
    notCheckout: "Open the cart or payment page first.",
    capReached: "Stopped after the maximum number of tries.",
    diagnoseTitle: "Diagnose this page",
    diagnoseState: "Page state",
    stateBag: "Bag / cart",
    stateCouponPanelOpen: "Coupon panel open",
    stateCouponApplied: "Coupon applied",
    stateCouponError: "Coupon error",
    statePayment: "Payment page",
    diagnoseCopy: "Copy snapshot",
    diagnoseDownload: "Download",
    diagnoseNotice: "The snapshot is copied on this device and sent nowhere.",
    diagnoseCopied: "Copied.",
    diagnoseFailed: "Could not capture this page.",
    loginRequired: "This site needs you to log in before coupons can be applied. Log in, then try again.",
    rateLimited: "The site is limiting coupon attempts. Stopped to avoid problems; try again later.",
    originUser: "From your own codes",
    originListed: "Listed by the site for your cart",
    originShared: "From the shared list",
    skippedIneligible: "Skipped, the site says not applicable: {codes}",
    couponNotApplied: "The best coupon ({code}) is not applied right now. Enter it yourself to get this saving.",
    preAppliedLost: "A coupon that was already applied was removed during the search. Re-apply it if you still want it.",
    couldNotRestore: "Could not remove the last coupon tried. Check your cart total before paying.",
    noOffers: "No instant bank offers found on this page.",
    payHint: "Next: open the payment page and click Promo-Flow again to see the best bank offer.",
    totalOnPage: "Total on this page",
    tryMore: "Try {n} more",
    tryMoreWait: "Try more in {s}s",
    srcYours: "yours",
    srcSite: "site",
    srcShared: "shared",
    srcFeed: "feed",
    srcDataset: "old list",
    srcKnown: "known",
    ageToday: "today",
    ageDays: "{d}d ago",
    skippedMinSpend: "Skipped, needs a bigger cart: {codes}",
    sharePrompt: "{code} worked. Share it with other Promo-Flow users? Only the store and the code are sent.",
    shareYes: "Share",
    shareNo: "No",
    shareAlways: "Always share",
    sharedThanks: "Shared. Thank you.",
    shareModeL: "Sharing codes that worked for me",
    shareAsk: "Ask each time",
    shareAlwaysOpt: "Always",
    shareNever: "Never"
  };

  // src/i18n/hi.json
  var hi_default = {
    appName: "Promo-Flow",
    tagline: "\u091A\u0947\u0915\u0906\u0909\u091F \u092A\u0930 \u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u093E \u0915\u0942\u092A\u0928 \u0914\u0930 \u092C\u0948\u0902\u0915 \u0911\u092B\u093C\u0930 \u0916\u094B\u091C\u0924\u093E \u0939\u0948",
    find: "\u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u0940 \u092C\u091A\u0924 \u0916\u094B\u091C\u0947\u0902",
    stop: "\u0930\u094B\u0915\u0947\u0902",
    language: "\u092D\u093E\u0937\u093E",
    yourCodes: "\u092E\u0947\u0930\u0947 \u0915\u0942\u092A\u0928 \u0915\u094B\u0921",
    yourCodesHint: "\u0939\u0930 \u092A\u0902\u0915\u094D\u0924\u093F \u092E\u0947\u0902 \u090F\u0915 \u0915\u094B\u0921\u0964 \u0915\u0947\u0935\u0932 \u0935\u0939\u0940 \u0915\u094B\u0921 \u091C\u094B \u0906\u092A\u0915\u0947 \u092A\u093E\u0938 \u092A\u0939\u0932\u0947 \u0938\u0947 \u0939\u0948\u0902\u0964",
    addCode: "\u0938\u0939\u0947\u091C\u0947\u0902",
    telemetry: "\u0917\u0941\u092E\u0928\u093E\u092E \u092A\u0930\u093F\u0923\u093E\u092E \u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902",
    telemetryHint: "\u0915\u0947\u0935\u0932 \u092D\u0947\u091C\u093E \u091C\u093E\u0924\u093E \u0939\u0948: \u0938\u094D\u091F\u094B\u0930, \u0915\u094B\u0921, \u091A\u0932\u093E \u092F\u093E \u0928\u0939\u0940\u0902\u0964 \u0915\u094B\u0908 \u0928\u093F\u091C\u0940 \u0921\u0947\u091F\u093E \u0928\u0939\u0940\u0902\u0964",
    apiBase: "\u0938\u0930\u094D\u0935\u0930 \u0915\u093E \u092A\u0924\u093E",
    working: "\u0915\u093E\u092E \u091A\u0932 \u0930\u0939\u093E \u0939\u0948\u2026",
    trying: "{code} \u0906\u091C\u093C\u092E\u093E\u092F\u093E \u091C\u093E \u0930\u0939\u093E \u0939\u0948 ({n}/{total})",
    noField: "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u092A\u094D\u0930\u094B\u092E\u094B-\u0915\u094B\u0921 \u092C\u0949\u0915\u094D\u0938 \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u093E\u0964 \u092A\u0947\u092E\u0947\u0902\u091F/\u091A\u0947\u0915\u0906\u0909\u091F \u091A\u0930\u0923 \u0916\u094B\u0932\u0915\u0930 \u092B\u093F\u0930 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
    captcha: "\u0938\u093E\u0907\u091F \u0938\u0924\u094D\u092F\u093E\u092A\u0928 \u092E\u093E\u0901\u0917 \u0930\u0939\u0940 \u0939\u0948\u0964 \u0906\u092A \u0916\u0941\u0926 \u092A\u0942\u0930\u093E \u0915\u0930 \u0938\u0915\u0947\u0902, \u0907\u0938\u0932\u093F\u090F \u0930\u094B\u0915 \u0926\u093F\u092F\u093E \u0917\u092F\u093E\u0964",
    noTotal: "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u0926\u0947\u092F \u0915\u0941\u0932 \u0930\u093E\u0936\u093F \u092A\u0922\u093C \u0928\u0939\u0940\u0902 \u0938\u0915\u0947\u0964",
    noCodes: "\u0907\u0938 \u0938\u094D\u091F\u094B\u0930 \u0915\u0947 \u0932\u093F\u090F \u0906\u091C\u093C\u092E\u093E\u0928\u0947 \u0915\u094B \u0915\u094B\u0908 \u0915\u094B\u0921 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964 \u092A\u0949\u092A\u0905\u092A \u092E\u0947\u0902 \u0905\u092A\u0928\u0947 \u0915\u094B\u0921 \u091C\u094B\u0921\u093C\u0947\u0902\u0964",
    done: "\u092A\u0942\u0930\u093E \u0939\u0941\u0906",
    before: "\u092A\u0939\u0932\u0947",
    after: "\u092C\u093E\u0926 \u092E\u0947\u0902",
    youSave: "\u0906\u092A\u0915\u0940 \u092C\u091A\u0924",
    bankOffer: "\u092C\u0948\u0902\u0915/\u092A\u0947\u092E\u0947\u0902\u091F \u0911\u092B\u093C\u0930",
    bankHint: "\u0911\u092B\u093C\u0930 \u0915\u0947 \u091F\u0947\u0915\u094D\u0938\u094D\u091F \u0938\u0947 \u0905\u0928\u0941\u092E\u093E\u0928\u093F\u0924\u0964 \u0909\u0938 \u0915\u093E\u0930\u094D\u0921/\u0924\u0930\u0940\u0915\u0947 \u0938\u0947 \u092D\u0941\u0917\u0924\u093E\u0928 \u0915\u0930\u0928\u0947 \u092A\u0930 \u092E\u093F\u0932\u0947\u0917\u093E; Promo-Flow \u0907\u0938\u0947 \u0932\u093E\u0917\u0942 \u0928\u0939\u0940\u0902 \u0915\u0930\u0924\u093E\u0964",
    couponApplied: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942 \u0939\u0941\u0906",
    noneWorked: "\u0907\u0938 \u0915\u093E\u0930\u094D\u091F \u092A\u0930 \u0915\u094B\u0908 \u0915\u094B\u0921 \u0928\u0939\u0940\u0902 \u091A\u0932\u093E\u0964",
    estimate: "\u0905\u0928\u0941\u092E\u093E\u0928",
    close: "\u092C\u0902\u0926 \u0915\u0930\u0947\u0902",
    stopped: "\u0930\u094B\u0915 \u0926\u093F\u092F\u093E \u0917\u092F\u093E\u0964",
    unverifiedSite: "\u0907\u0938 \u0938\u093E\u0907\u091F \u0915\u093E \u0938\u092E\u0930\u094D\u0925\u0928 \u092A\u094D\u0930\u093E\u092F\u094B\u0917\u093F\u0915 \u0939\u0948\u0964 \u092D\u0941\u0917\u0924\u093E\u0928 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0905\u0902\u0924\u093F\u092E \u0930\u093E\u0936\u093F \u091C\u093E\u0901\u091A \u0932\u0947\u0902\u0964",
    notCheckout: "\u092A\u0939\u0932\u0947 \u0915\u093E\u0930\u094D\u091F \u092F\u093E \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u0947\u091C \u0916\u094B\u0932\u0947\u0902\u0964",
    capReached: "\u0905\u0927\u093F\u0915\u0924\u092E \u0915\u094B\u0936\u093F\u0936\u094B\u0902 \u0915\u0947 \u092C\u093E\u0926 \u0930\u0941\u0915 \u0917\u092F\u093E\u0964",
    diagnoseTitle: "\u0907\u0938 \u092A\u0947\u091C \u0915\u0940 \u091C\u093E\u0901\u091A",
    diagnoseState: "\u092A\u0947\u091C \u0915\u0940 \u0938\u094D\u0925\u093F\u0924\u093F",
    stateBag: "\u092C\u0948\u0917 / \u0915\u093E\u0930\u094D\u091F",
    stateCouponPanelOpen: "\u0915\u0942\u092A\u0928 \u092A\u0948\u0928\u0932 \u0916\u0941\u0932\u093E",
    stateCouponApplied: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942",
    stateCouponError: "\u0915\u0942\u092A\u0928 \u092E\u0947\u0902 \u0924\u094D\u0930\u0941\u091F\u093F",
    statePayment: "\u092A\u0947\u092E\u0947\u0902\u091F \u092A\u0947\u091C",
    diagnoseCopy: "\u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902",
    diagnoseDownload: "\u0921\u093E\u0909\u0928\u0932\u094B\u0921",
    diagnoseNotice: "\u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F \u0907\u0938\u0940 \u0921\u093F\u0935\u093E\u0907\u0938 \u092A\u0930 \u0915\u0949\u092A\u0940 \u0939\u094B\u0924\u093E \u0939\u0948, \u0915\u0939\u0940\u0902 \u092D\u0947\u091C\u093E \u0928\u0939\u0940\u0902 \u091C\u093E\u0924\u093E\u0964",
    diagnoseCopied: "\u0915\u0949\u092A\u0940 \u0939\u094B \u0917\u092F\u093E\u0964",
    diagnoseFailed: "\u0907\u0938 \u092A\u0947\u091C \u0915\u093E \u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F \u0928\u0939\u0940\u0902 \u0932\u093F\u092F\u093E \u091C\u093E \u0938\u0915\u093E\u0964",
    loginRequired: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942 \u0915\u0930\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0907\u0938 \u0938\u093E\u0907\u091F \u092A\u0930 \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u0928\u093E \u0939\u094B\u0917\u093E\u0964 \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u0915\u0947 \u092B\u093F\u0930 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
    rateLimited: "\u0938\u093E\u0907\u091F \u0915\u0942\u092A\u0928 \u0915\u0940 \u0915\u094B\u0936\u093F\u0936\u0947\u0902 \u0938\u0940\u092E\u093F\u0924 \u0915\u0930 \u0930\u0939\u0940 \u0939\u0948\u0964 \u092A\u0930\u0947\u0936\u093E\u0928\u0940 \u0938\u0947 \u092C\u091A\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0930\u094B\u0915 \u0926\u093F\u092F\u093E \u0917\u092F\u093E; \u092C\u093E\u0926 \u092E\u0947\u0902 \u092B\u093F\u0930 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
    originUser: "\u0906\u092A\u0915\u0947 \u0905\u092A\u0928\u0947 \u0915\u094B\u0921 \u0938\u0947",
    originListed: "\u0938\u093E\u0907\u091F \u0928\u0947 \u0906\u092A\u0915\u0947 \u0915\u093E\u0930\u094D\u091F \u0915\u0947 \u0932\u093F\u090F \u0938\u0941\u091D\u093E\u092F\u093E",
    originShared: "\u0938\u093E\u091D\u093E \u0938\u0942\u091A\u0940 \u0938\u0947",
    skippedIneligible: "\u091B\u094B\u0921\u093C \u0926\u093F\u090F \u0917\u090F, \u0938\u093E\u0907\u091F \u0915\u0947 \u0905\u0928\u0941\u0938\u093E\u0930 \u0932\u093E\u0917\u0942 \u0928\u0939\u0940\u0902: {codes}",
    couponNotApplied: "\u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u093E \u0915\u0942\u092A\u0928 ({code}) \u0905\u092D\u0940 \u0932\u093E\u0917\u0942 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964 \u092F\u0939 \u092C\u091A\u0924 \u092A\u093E\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0907\u0938\u0947 \u0916\u0941\u0926 \u0921\u093E\u0932\u0947\u0902\u0964",
    preAppliedLost: "\u092A\u0939\u0932\u0947 \u0938\u0947 \u0932\u093E\u0917\u0942 \u0915\u0942\u092A\u0928 \u0916\u094B\u091C \u0915\u0947 \u0926\u094C\u0930\u093E\u0928 \u0939\u091F\u093E \u0926\u093F\u092F\u093E \u0917\u092F\u093E\u0964 \u091A\u093E\u0939\u0947\u0902 \u0924\u094B \u0909\u0938\u0947 \u092B\u093F\u0930 \u0938\u0947 \u0932\u0917\u093E\u090F\u0901\u0964",
    couldNotRestore: "\u0906\u0916\u093C\u093F\u0930\u0940 \u0906\u091C\u093C\u092E\u093E\u092F\u093E \u0915\u0942\u092A\u0928 \u0939\u091F\u093E\u092F\u093E \u0928\u0939\u0940\u0902 \u091C\u093E \u0938\u0915\u093E\u0964 \u092D\u0941\u0917\u0924\u093E\u0928 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0915\u093E\u0930\u094D\u091F \u0915\u0940 \u0915\u0941\u0932 \u0930\u093E\u0936\u093F \u091C\u093E\u0901\u091A \u0932\u0947\u0902\u0964",
    noOffers: "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u0915\u094B\u0908 \u0924\u0941\u0930\u0902\u0924 \u092E\u093F\u0932\u0928\u0947 \u0935\u093E\u0932\u093E \u092C\u0948\u0902\u0915 \u0911\u092B\u093C\u0930 \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u093E\u0964",
    payHint: "\u0905\u0917\u0932\u093E \u0915\u0926\u092E: \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u0947\u091C \u0916\u094B\u0932\u0947\u0902 \u0914\u0930 \u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u093E \u092C\u0948\u0902\u0915 \u0911\u092B\u093C\u0930 \u0926\u0947\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F Promo-Flow \u092B\u093F\u0930 \u0938\u0947 \u0926\u092C\u093E\u090F\u0901\u0964",
    totalOnPage: "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u0915\u0941\u0932 \u0930\u093E\u0936\u093F",
    tryMore: "{n} \u0914\u0930 \u0906\u091C\u093C\u092E\u093E\u090F\u0901",
    tryMoreWait: "{s} \u0938\u0947\u0915\u0902\u0921 \u092E\u0947\u0902 \u0914\u0930 \u0906\u091C\u093C\u092E\u093E\u090F\u0901",
    srcYours: "\u0906\u092A\u0915\u093E",
    srcSite: "\u0938\u093E\u0907\u091F",
    srcShared: "\u0938\u093E\u091D\u093E",
    srcFeed: "\u092B\u093C\u0940\u0921",
    srcDataset: "\u092A\u0941\u0930\u093E\u0928\u0940 \u0938\u0942\u091A\u0940",
    srcKnown: "\u091C\u094D\u091E\u093E\u0924",
    ageToday: "\u0906\u091C",
    ageDays: "{d} \u0926\u093F\u0928 \u092A\u0939\u0932\u0947",
    skippedMinSpend: "\u091B\u094B\u0921\u093C\u093E \u0917\u092F\u093E, \u092C\u0921\u093C\u093E \u0915\u093E\u0930\u094D\u091F \u091A\u093E\u0939\u093F\u090F: {codes}",
    sharePrompt: "{code} \u091A\u0932 \u0917\u092F\u093E\u0964 \u0915\u094D\u092F\u093E \u0907\u0938\u0947 \u0926\u0942\u0938\u0930\u0947 Promo-Flow \u0909\u092A\u092F\u094B\u0917\u0915\u0930\u094D\u0924\u093E\u0913\u0902 \u0915\u0947 \u0938\u093E\u0925 \u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902? \u0915\u0947\u0935\u0932 \u0938\u094D\u091F\u094B\u0930 \u0914\u0930 \u0915\u094B\u0921 \u092D\u0947\u091C\u093E \u091C\u093E\u0924\u093E \u0939\u0948\u0964",
    shareYes: "\u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902",
    shareNo: "\u0928\u0939\u0940\u0902",
    shareAlways: "\u0939\u092E\u0947\u0936\u093E \u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902",
    sharedThanks: "\u0938\u093E\u091D\u093E \u0915\u093F\u092F\u093E \u0917\u092F\u093E\u0964 \u0927\u0928\u094D\u092F\u0935\u093E\u0926\u0964",
    shareModeL: "\u092E\u0947\u0930\u0947 \u0932\u093F\u090F \u091A\u0932\u0947 \u0915\u094B\u0921 \u0938\u093E\u091D\u093E \u0915\u0930\u0928\u093E",
    shareAsk: "\u0939\u0930 \u092C\u093E\u0930 \u092A\u0942\u091B\u0947\u0902",
    shareAlwaysOpt: "\u0939\u092E\u0947\u0936\u093E",
    shareNever: "\u0915\u092D\u0940 \u0928\u0939\u0940\u0902"
  };

  // src/i18n/mr.json
  var mr_default = {
    appName: "Promo-Flow",
    tagline: "\u091A\u0947\u0915\u0906\u0909\u091F\u0935\u0930 \u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u0915\u0942\u092A\u0928 \u0906\u0923\u093F \u092C\u0901\u0915 \u0911\u092B\u0930 \u0936\u094B\u0927\u0924\u094B",
    find: "\u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u092C\u091A\u0924 \u0936\u094B\u0927\u093E",
    stop: "\u0925\u093E\u0902\u092C\u0935\u093E",
    language: "\u092D\u093E\u0937\u093E",
    yourCodes: "\u092E\u093E\u091D\u0947 \u0915\u0942\u092A\u0928 \u0915\u094B\u0921",
    yourCodesHint: "\u092A\u094D\u0930\u0924\u094D\u092F\u0947\u0915 \u0913\u0933\u0940\u0924 \u090F\u0915 \u0915\u094B\u0921. \u092B\u0915\u094D\u0924 \u0924\u0941\u092E\u091A\u094D\u092F\u093E\u0915\u0921\u0947 \u0906\u0927\u0940\u092A\u093E\u0938\u0942\u0928 \u0905\u0938\u0932\u0947\u0932\u0947 \u0915\u094B\u0921.",
    addCode: "\u091C\u0924\u0928 \u0915\u0930\u093E",
    telemetry: "\u0928\u093F\u0928\u093E\u0935\u0940 \u0928\u093F\u0915\u093E\u0932 \u0936\u0947\u0905\u0930 \u0915\u0930\u093E",
    telemetryHint: "\u092B\u0915\u094D\u0924 \u092A\u093E\u0920\u0935\u0932\u0947 \u091C\u093E\u0924\u0947: \u0938\u094D\u091F\u094B\u0905\u0930, \u0915\u094B\u0921, \u091A\u093E\u0932\u0932\u093E \u0915\u0940 \u0928\u093E\u0939\u0940. \u0935\u0948\u092F\u0915\u094D\u0924\u093F\u0915 \u092E\u093E\u0939\u093F\u0924\u0940 \u0928\u093E\u0939\u0940.",
    apiBase: "\u0938\u0930\u094D\u0935\u094D\u0939\u0930 \u092A\u0924\u094D\u0924\u093E",
    working: "\u0915\u093E\u092E \u0938\u0941\u0930\u0942 \u0906\u0939\u0947\u2026",
    trying: "{code} \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u093E\u0939\u0924 \u0906\u0939\u0947 ({n}/{total})",
    noField: "\u092F\u093E \u092A\u093E\u0928\u093E\u0935\u0930 \u092A\u094D\u0930\u094B\u092E\u094B-\u0915\u094B\u0921 \u092C\u0949\u0915\u094D\u0938 \u0938\u093E\u092A\u0921\u0932\u093E \u0928\u093E\u0939\u0940. \u092A\u0947\u092E\u0947\u0902\u091F/\u091A\u0947\u0915\u0906\u0909\u091F \u091F\u092A\u094D\u092A\u093E \u0909\u0918\u0921\u0942\u0928 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
    captcha: "\u0938\u093E\u0907\u091F \u092A\u0921\u0924\u093E\u0933\u0923\u0940 \u092E\u093E\u0917\u0924 \u0906\u0939\u0947. \u0924\u0941\u092E\u094D\u0939\u0940 \u0938\u094D\u0935\u0924\u0903 \u092A\u0942\u0930\u094D\u0923 \u0915\u0930\u0942 \u0936\u0915\u093E\u0932 \u092E\u094D\u0939\u0923\u0942\u0928 \u0925\u093E\u0902\u092C\u0935\u0932\u0947.",
    noTotal: "\u092F\u093E \u092A\u093E\u0928\u093E\u0935\u0930 \u0926\u0947\u092F \u090F\u0915\u0942\u0923 \u0930\u0915\u094D\u0915\u092E \u0935\u093E\u091A\u0924\u093E \u0906\u0932\u0940 \u0928\u093E\u0939\u0940.",
    noCodes: "\u092F\u093E \u0938\u094D\u091F\u094B\u0905\u0930\u0938\u093E\u0920\u0940 \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u093E\u0939\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u0915\u094B\u0921 \u0928\u093E\u0939\u0940\u0924. \u092A\u0949\u092A\u0905\u092A\u092E\u0927\u094D\u092F\u0947 \u0938\u094D\u0935\u0924\u0903\u091A\u0947 \u0915\u094B\u0921 \u091C\u094B\u0921\u093E.",
    done: "\u092A\u0942\u0930\u094D\u0923 \u091D\u093E\u0932\u0947",
    before: "\u0906\u0927\u0940",
    after: "\u0928\u0902\u0924\u0930",
    youSave: "\u0924\u0941\u092E\u091A\u0940 \u092C\u091A\u0924",
    bankOffer: "\u092C\u0901\u0915/\u092A\u0947\u092E\u0947\u0902\u091F \u0911\u092B\u0930",
    bankHint: "\u0911\u092B\u0930\u091A\u094D\u092F\u093E \u092E\u091C\u0915\u0941\u0930\u093E\u0935\u0930\u0942\u0928 \u0905\u0902\u0926\u093E\u091C. \u0924\u094D\u092F\u093E \u0915\u093E\u0930\u094D\u0921/\u092A\u0926\u094D\u0927\u0924\u0940\u0928\u0947 \u092A\u0948\u0938\u0947 \u092D\u0930\u0932\u094D\u092F\u093E\u0935\u0930 \u092E\u093F\u0933\u0947\u0932; Promo-Flow \u0924\u0940 \u0932\u093E\u0917\u0942 \u0915\u0930\u0924 \u0928\u093E\u0939\u0940.",
    couponApplied: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942 \u091D\u093E\u0932\u0947",
    noneWorked: "\u092F\u093E \u0915\u093E\u0930\u094D\u091F\u0935\u0930 \u0915\u094B\u0923\u0924\u093E\u0939\u0940 \u0915\u094B\u0921 \u091A\u093E\u0932\u0932\u093E \u0928\u093E\u0939\u0940.",
    estimate: "\u0905\u0902\u0926\u093E\u091C",
    close: "\u092C\u0902\u0926 \u0915\u0930\u093E",
    stopped: "\u0925\u093E\u0902\u092C\u0935\u0932\u0947.",
    unverifiedSite: "\u092F\u093E \u0938\u093E\u0907\u091F\u091A\u093E \u0938\u092A\u094B\u0930\u094D\u091F \u092A\u094D\u0930\u093E\u092F\u094B\u0917\u093F\u0915 \u0906\u0939\u0947. \u092A\u0948\u0938\u0947 \u092D\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u0905\u0902\u0924\u093F\u092E \u0930\u0915\u094D\u0915\u092E \u0924\u092A\u093E\u0938\u093E.",
    notCheckout: "\u0906\u0927\u0940 \u0915\u093E\u0930\u094D\u091F \u0915\u093F\u0902\u0935\u093E \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u093E\u0928 \u0909\u0918\u0921\u093E.",
    capReached: "\u0915\u092E\u093E\u0932 \u092A\u094D\u0930\u092F\u0924\u094D\u0928\u093E\u0902\u0928\u0902\u0924\u0930 \u0925\u093E\u0902\u092C\u0932\u0947.",
    diagnoseTitle: "\u0939\u0947 \u092A\u093E\u0928 \u0924\u092A\u093E\u0938\u093E",
    diagnoseState: "\u092A\u093E\u0928\u093E\u091A\u0940 \u0938\u094D\u0925\u093F\u0924\u0940",
    stateBag: "\u092C\u0945\u0917 / \u0915\u093E\u0930\u094D\u091F",
    stateCouponPanelOpen: "\u0915\u0942\u092A\u0928 \u092A\u0945\u0928\u0932 \u0909\u0918\u0921\u0947",
    stateCouponApplied: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942",
    stateCouponError: "\u0915\u0942\u092A\u0928 \u0924\u094D\u0930\u0941\u091F\u0940",
    statePayment: "\u092A\u0947\u092E\u0947\u0902\u091F \u092A\u093E\u0928",
    diagnoseCopy: "\u0938\u094D\u0928\u0945\u092A\u0936\u0949\u091F \u0915\u0949\u092A\u0940 \u0915\u0930\u093E",
    diagnoseDownload: "\u0921\u093E\u0909\u0928\u0932\u094B\u0921",
    diagnoseNotice: "\u0938\u094D\u0928\u0945\u092A\u0936\u0949\u091F \u092F\u093E\u091A \u0921\u093F\u0935\u094D\u0939\u093E\u0907\u0938\u0935\u0930 \u0915\u0949\u092A\u0940 \u0939\u094B\u0924\u094B, \u0915\u0941\u0920\u0947\u0939\u0940 \u092A\u093E\u0920\u0935\u0932\u093E \u091C\u093E\u0924 \u0928\u093E\u0939\u0940.",
    diagnoseCopied: "\u0915\u0949\u092A\u0940 \u091D\u093E\u0932\u0947.",
    diagnoseFailed: "\u0939\u0947 \u092A\u093E\u0928 \u0915\u0945\u092A\u094D\u091A\u0930 \u0915\u0930\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940.",
    loginRequired: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942 \u0915\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u092F\u093E \u0938\u093E\u0907\u091F\u0935\u0930 \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u093E\u0935\u0947 \u0932\u093E\u0917\u0947\u0932. \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u0942\u0928 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
    rateLimited: "\u0938\u093E\u0907\u091F \u0915\u0942\u092A\u0928 \u092A\u094D\u0930\u092F\u0924\u094D\u0928\u093E\u0902\u0935\u0930 \u092E\u0930\u094D\u092F\u093E\u0926\u093E \u0918\u093E\u0932\u0924 \u0906\u0939\u0947. \u0905\u0921\u091A\u0923 \u091F\u093E\u0933\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u0925\u093E\u0902\u092C\u0935\u0932\u0947; \u0928\u0902\u0924\u0930 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
    originUser: "\u0924\u0941\u092E\u091A\u094D\u092F\u093E \u0938\u094D\u0935\u0924\u0903\u091A\u094D\u092F\u093E \u0915\u094B\u0921\u092E\u0927\u0942\u0928",
    originListed: "\u0938\u093E\u0907\u091F\u0928\u0947 \u0924\u0941\u092E\u091A\u094D\u092F\u093E \u0915\u093E\u0930\u094D\u091F\u0938\u093E\u0920\u0940 \u0926\u093E\u0916\u0935\u0932\u0947\u0932\u0947",
    originShared: "\u0936\u0947\u0905\u0930 \u0915\u0947\u0932\u0947\u0932\u094D\u092F\u093E \u092F\u093E\u0926\u0940\u0924\u0942\u0928",
    skippedIneligible: "\u0935\u0917\u0933\u0932\u0947, \u0938\u093E\u0907\u091F\u0928\u0941\u0938\u093E\u0930 \u0932\u093E\u0917\u0942 \u0928\u093E\u0939\u0940\u0924: {codes}",
    couponNotApplied: "\u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u0915\u0942\u092A\u0928 ({code}) \u0938\u0927\u094D\u092F\u093E \u0932\u093E\u0917\u0942 \u0928\u093E\u0939\u0940. \u0939\u0940 \u092C\u091A\u0924 \u092E\u093F\u0933\u0935\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u0924\u0947 \u0938\u094D\u0935\u0924\u0903 \u091F\u093E\u0915\u093E.",
    preAppliedLost: "\u0906\u0927\u0940\u092A\u093E\u0938\u0942\u0928 \u0932\u093E\u0917\u0942 \u0905\u0938\u0932\u0947\u0932\u0947 \u0915\u0942\u092A\u0928 \u0936\u094B\u0927\u093E\u0926\u0930\u092E\u094D\u092F\u093E\u0928 \u0915\u093E\u0922\u0932\u0947 \u0917\u0947\u0932\u0947. \u0939\u0935\u0947 \u0905\u0938\u0932\u094D\u092F\u093E\u0938 \u092A\u0941\u0928\u094D\u0939\u093E \u0932\u093E\u0935\u093E.",
    couldNotRestore: "\u0936\u0947\u0935\u091F\u091A\u0947 \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u093E\u0939\u093F\u0932\u0947\u0932\u0947 \u0915\u0942\u092A\u0928 \u0915\u093E\u0922\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940. \u092A\u0948\u0938\u0947 \u092D\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u0915\u093E\u0930\u094D\u091F\u091A\u0940 \u090F\u0915\u0942\u0923 \u0930\u0915\u094D\u0915\u092E \u0924\u092A\u093E\u0938\u093E.",
    noOffers: "\u092F\u093E \u092A\u093E\u0928\u093E\u0935\u0930 \u0924\u093E\u0924\u094D\u0915\u093E\u0933 \u092E\u093F\u0933\u0923\u093E\u0930\u0940 \u092C\u0901\u0915 \u0911\u092B\u0930 \u0938\u093E\u092A\u0921\u0932\u0940 \u0928\u093E\u0939\u0940.",
    payHint: "\u092A\u0941\u0922\u0940\u0932 \u092A\u093E\u092F\u0930\u0940: \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u093E\u0928 \u0909\u0918\u0921\u093E \u0906\u0923\u093F \u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u092C\u0901\u0915 \u0911\u092B\u0930 \u092A\u093E\u0939\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 Promo-Flow \u092A\u0941\u0928\u094D\u0939\u093E \u0926\u093E\u092C\u093E.",
    totalOnPage: "\u092F\u093E \u092A\u093E\u0928\u093E\u0935\u0930\u0940\u0932 \u090F\u0915\u0942\u0923 \u0930\u0915\u094D\u0915\u092E",
    tryMore: "\u0906\u0923\u0916\u0940 {n} \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u0939\u093E",
    tryMoreWait: "{s} \u0938\u0947\u0915\u0902\u0926\u093E\u0902\u0924 \u0906\u0923\u0916\u0940 \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u0939\u093E",
    srcYours: "\u0924\u0941\u092E\u091A\u093E",
    srcSite: "\u0938\u093E\u0907\u091F",
    srcShared: "\u0936\u0947\u0905\u0930 \u0915\u0947\u0932\u0947\u0932\u093E",
    srcFeed: "\u092B\u0940\u0921",
    srcDataset: "\u091C\u0941\u0928\u0940 \u092F\u093E\u0926\u0940",
    srcKnown: "\u091C\u094D\u091E\u093E\u0924",
    ageToday: "\u0906\u091C",
    ageDays: "{d} \u0926\u093F\u0935\u0938\u093E\u0902\u092A\u0942\u0930\u094D\u0935\u0940",
    skippedMinSpend: "\u0935\u0917\u0933\u0932\u0947, \u092E\u094B\u0920\u093E \u0915\u093E\u0930\u094D\u091F \u0939\u0935\u093E: {codes}",
    sharePrompt: "{code} \u091A\u093E\u0932\u0932\u093E. \u0907\u0924\u0930 Promo-Flow \u0935\u093E\u092A\u0930\u0915\u0930\u094D\u0924\u094D\u092F\u093E\u0902\u0938\u094B\u092C\u0924 \u0936\u0947\u0905\u0930 \u0915\u0930\u093E\u092F\u091A\u093E? \u092B\u0915\u094D\u0924 \u0938\u094D\u091F\u094B\u0905\u0930 \u0906\u0923\u093F \u0915\u094B\u0921 \u092A\u093E\u0920\u0935\u0932\u093E \u091C\u093E\u0924\u094B.",
    shareYes: "\u0936\u0947\u0905\u0930 \u0915\u0930\u093E",
    shareNo: "\u0928\u093E\u0939\u0940",
    shareAlways: "\u0928\u0947\u0939\u092E\u0940 \u0936\u0947\u0905\u0930 \u0915\u0930\u093E",
    sharedThanks: "\u0936\u0947\u0905\u0930 \u0915\u0947\u0932\u0947. \u0927\u0928\u094D\u092F\u0935\u093E\u0926.",
    shareModeL: "\u092E\u093E\u091D\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u091A\u093E\u0932\u0932\u0947\u0932\u0947 \u0915\u094B\u0921 \u0936\u0947\u0905\u0930 \u0915\u0930\u0923\u0947",
    shareAsk: "\u092A\u094D\u0930\u0924\u094D\u092F\u0947\u0915 \u0935\u0947\u0933\u0940 \u0935\u093F\u091A\u093E\u0930\u093E",
    shareAlwaysOpt: "\u0928\u0947\u0939\u092E\u0940",
    shareNever: "\u0915\u0927\u0940\u091A \u0928\u093E\u0939\u0940"
  };

  // src/i18n/ta.json
  var ta_default = {
    appName: "Promo-Flow",
    tagline: "\u0B9A\u0BC6\u0B95\u0BCD\u0B85\u0BB5\u0BC1\u0B9F\u0BCD\u0B9F\u0BBF\u0BB2\u0BCD \u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BB5\u0B99\u0BCD\u0B95\u0BBF \u0B9A\u0BB2\u0BC1\u0B95\u0BC8\u0BAF\u0BC8\u0B95\u0BCD \u0B95\u0BA3\u0BCD\u0B9F\u0BB1\u0BBF\u0BAF\u0BC1\u0BAE\u0BCD",
    find: "\u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0B9A\u0BC7\u0BAE\u0BBF\u0BAA\u0BCD\u0BAA\u0BC8\u0B95\u0BCD \u0B95\u0BA3\u0BCD\u0B9F\u0BC1\u0BAA\u0BBF\u0B9F\u0BBF",
    stop: "\u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1",
    language: "\u0BAE\u0BCA\u0BB4\u0BBF",
    yourCodes: "\u0B8E\u0BA9\u0BCD \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BCD",
    yourCodesHint: "\u0B92\u0BB0\u0BC1 \u0BB5\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC1 \u0B92\u0BB0\u0BC1 \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1. \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0B9F\u0BAE\u0BCD \u0B8F\u0BB1\u0BCD\u0B95\u0BA9\u0BB5\u0BC7 \u0B89\u0BB3\u0BCD\u0BB3\u0BB5\u0BC8 \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD.",
    addCode: "\u0B9A\u0BC7\u0BAE\u0BBF",
    telemetry: "\u0BAA\u0BC6\u0BAF\u0BB0\u0BBF\u0BB2\u0BCD\u0BB2\u0BBE \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0BC1\u0B95\u0BB3\u0BC8\u0BAA\u0BCD \u0BAA\u0B95\u0BBF\u0BB0\u0BCD",
    telemetryHint: "\u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BB5\u0BA4\u0BC1: \u0B95\u0B9F\u0BC8, \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1, \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BA4\u0BBE \u0B87\u0BB2\u0BCD\u0BB2\u0BC8\u0BAF\u0BBE. \u0BA4\u0BA9\u0BBF\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BA4\u0BB0\u0BB5\u0BC1 \u0B87\u0BB2\u0BCD\u0BB2\u0BC8.",
    apiBase: "\u0B9A\u0BB0\u0BCD\u0BB5\u0BB0\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    working: "\u0BB5\u0BC7\u0BB2\u0BC8 \u0BA8\u0B9F\u0B95\u0BCD\u0B95\u0BBF\u0BB1\u0BA4\u0BC1\u2026",
    trying: "{code} \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1 ({n}/{total})",
    noField: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BAA\u0BCD\u0BB0\u0BCB\u0BAE\u0BCB \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BCD\u0B9F\u0BC1\u0BAA\u0BCD \u0BAA\u0BC6\u0B9F\u0BCD\u0B9F\u0BBF \u0B95\u0BBF\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAA\u0BA3\u0BAE\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BAE\u0BCD/\u0B9A\u0BC6\u0B95\u0BCD\u0B85\u0BB5\u0BC1\u0B9F\u0BCD \u0BAA\u0B9F\u0BBF\u0BAF\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BB5\u0BC1\u0BAE\u0BCD.",
    captcha: "\u0BA4\u0BB3\u0BAE\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BC1 \u0B95\u0BC7\u0B9F\u0BCD\u0B95\u0BBF\u0BB1\u0BA4\u0BC1. \u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BC7 \u0BAE\u0BC1\u0B9F\u0BBF\u0B95\u0BCD\u0B95 \u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
    noTotal: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BBF\u0BAF \u0BAE\u0BCA\u0BA4\u0BCD\u0BA4\u0BA4\u0BCD\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0B9F\u0BBF\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8.",
    noCodes: "\u0B87\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BC1 \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95 \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAA\u0BBE\u0BAA\u0BCD\u0B85\u0BAA\u0BCD\u0BAA\u0BBF\u0BB2\u0BCD \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BC8\u0B9A\u0BCD \u0B9A\u0BC7\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
    done: "\u0BAE\u0BC1\u0B9F\u0BBF\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1",
    before: "\u0BAE\u0BC1\u0BA9\u0BCD",
    after: "\u0BAA\u0BBF\u0BA9\u0BCD",
    youSave: "\u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BC7\u0BAE\u0BBF\u0BAA\u0BCD\u0BAA\u0BA4\u0BC1",
    bankOffer: "\u0BB5\u0B99\u0BCD\u0B95\u0BBF/\u0BAA\u0BC7\u0BAE\u0BC6\u0BA3\u0BCD\u0B9F\u0BCD \u0B9A\u0BB2\u0BC1\u0B95\u0BC8",
    bankHint: "\u0B9A\u0BB2\u0BC1\u0B95\u0BC8 \u0B89\u0BB0\u0BC8\u0BAF\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC0\u0B9F\u0BC1. \u0B85\u0BA8\u0BCD\u0BA4 \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BC1/\u0BAE\u0BC1\u0BB1\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BBE\u0BB2\u0BCD \u0B95\u0BBF\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD; Promo-Flow \u0B87\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BBE\u0BA4\u0BC1.",
    couponApplied: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
    noneWorked: "\u0B87\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BBF\u0BB2\u0BCD \u0B8E\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0BAE\u0BCD \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8.",
    estimate: "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC0\u0B9F\u0BC1",
    close: "\u0BAE\u0BC2\u0B9F\u0BC1",
    stopped: "\u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
    unverifiedSite: "\u0B87\u0BA8\u0BCD\u0BA4\u0BA4\u0BCD \u0BA4\u0BB3\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BCD \u0B86\u0BA4\u0BB0\u0BB5\u0BC1 \u0B9A\u0BCB\u0BA4\u0BA9\u0BC8 \u0BA8\u0BBF\u0BB2\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1. \u0BAA\u0BA3\u0BAE\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD \u0B87\u0BB1\u0BC1\u0BA4\u0BBF\u0BA4\u0BCD \u0BA4\u0BCA\u0B95\u0BC8\u0BAF\u0BC8\u0B9A\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
    notCheckout: "\u0BAE\u0BC1\u0BA4\u0BB2\u0BBF\u0BB2\u0BCD \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD \u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0BAA\u0BC7\u0BAE\u0BC6\u0BA3\u0BCD\u0B9F\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
    capReached: "\u0B85\u0BA4\u0BBF\u0B95\u0BAA\u0B9F\u0BCD\u0B9A \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD \u0BAA\u0BBF\u0BB1\u0B95\u0BC1 \u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
    diagnoseTitle: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0B9A\u0BCD \u0B9A\u0BCB\u0BA4\u0BBF",
    diagnoseState: "\u0BAA\u0B95\u0BCD\u0B95 \u0BA8\u0BBF\u0BB2\u0BC8",
    stateBag: "\u0BAA\u0BC8 / \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD",
    stateCouponPanelOpen: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAA\u0BB2\u0B95\u0BAE\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1",
    stateCouponApplied: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
    stateCouponError: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAA\u0BBF\u0BB4\u0BC8",
    statePayment: "\u0BAA\u0BC7\u0BAE\u0BC6\u0BA3\u0BCD\u0B9F\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BAE\u0BCD",
    diagnoseCopy: "\u0BB8\u0BCD\u0BA9\u0BBE\u0BAA\u0BCD\u0BB7\u0BBE\u0B9F\u0BCD\u0B9F\u0BC8 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1",
    diagnoseDownload: "\u0BAA\u0BA4\u0BBF\u0BB5\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BC1",
    diagnoseNotice: "\u0BB8\u0BCD\u0BA9\u0BBE\u0BAA\u0BCD\u0BB7\u0BBE\u0B9F\u0BCD \u0B87\u0BA8\u0BCD\u0BA4\u0B9A\u0BCD \u0B9A\u0BBE\u0BA4\u0BA9\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BC7\u0BAF\u0BC7 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BAE\u0BCD; \u0B8E\u0B99\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BBE\u0BA4\u0BC1.",
    diagnoseCopied: "\u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
    diagnoseFailed: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0BBF\u0B9F\u0BBF\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8.",
    loginRequired: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD\u0B95\u0BB3\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4 \u0BAE\u0BC1\u0BA9\u0BCD \u0B87\u0BA8\u0BCD\u0BA4\u0BA4\u0BCD \u0BA4\u0BB3\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BA8\u0BC1\u0BB4\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD. \u0B89\u0BB3\u0BCD\u0BA8\u0BC1\u0BB4\u0BC8\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BB5\u0BC1\u0BAE\u0BCD.",
    rateLimited: "\u0BA4\u0BB3\u0BAE\u0BCD \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BC8\u0B95\u0BCD \u0B95\u0B9F\u0BCD\u0B9F\u0BC1\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1. \u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BB2\u0BC8\u0BA4\u0BCD \u0BA4\u0BB5\u0BBF\u0BB0\u0BCD\u0B95\u0BCD\u0B95 \u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1; \u0BAA\u0BBF\u0BB1\u0B95\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BB5\u0BC1\u0BAE\u0BCD.",
    originUser: "\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BCA\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1",
    originListed: "\u0BA4\u0BB3\u0BAE\u0BCD \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BBE\u0B95\u0BAA\u0BCD \u0BAA\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BB2\u0BBF\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
    originShared: "\u0BAA\u0B95\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BAA\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BB2\u0BBF\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1",
    skippedIneligible: "\u0BA4\u0BB5\u0BBF\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BB5\u0BC8, \u0BA4\u0BB3\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BCD\u0BAA\u0B9F\u0BBF \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBE\u0BA4\u0BC1: {codes}",
    couponNotApplied: "\u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD ({code}) \u0B87\u0BAA\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1 \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0B87\u0BA8\u0BCD\u0BA4\u0B9A\u0BCD \u0B9A\u0BC7\u0BAE\u0BBF\u0BAA\u0BCD\u0BAA\u0BC8\u0BAA\u0BCD \u0BAA\u0BC6\u0BB1 \u0B85\u0BA4\u0BC8 \u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BC7 \u0B89\u0BB3\u0BCD\u0BB3\u0BBF\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD.",
    preAppliedLost: "\u0B8F\u0BB1\u0BCD\u0B95\u0BA9\u0BB5\u0BC7 \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BA4\u0BC7\u0B9F\u0BB2\u0BBF\u0BA9\u0BCD \u0BAA\u0BCB\u0BA4\u0BC1 \u0BA8\u0BC0\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. \u0BA4\u0BC7\u0BB5\u0BC8\u0BAF\u0BC6\u0BA9\u0BBF\u0BB2\u0BCD \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
    couldNotRestore: "\u0B95\u0B9F\u0BC8\u0B9A\u0BBF\u0BAF\u0BBE\u0B95 \u0BAE\u0BC1\u0BAF\u0BA9\u0BCD\u0BB1 \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BC8 \u0BA8\u0BC0\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAA\u0BA3\u0BAE\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD \u0BA4\u0BCA\u0B95\u0BC8\u0BAF\u0BC8\u0B9A\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
    noOffers: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B89\u0B9F\u0BA9\u0B9F\u0BBF \u0BB5\u0B99\u0BCD\u0B95\u0BBF\u0B9A\u0BCD \u0B9A\u0BB2\u0BC1\u0B95\u0BC8\u0B95\u0BB3\u0BCD \u0B8E\u0BA4\u0BC1\u0BB5\u0BC1\u0BAE\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8.",
    payHint: "\u0B85\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BA4\u0BC1: \u0BAA\u0BC7\u0BAE\u0BC6\u0BA3\u0BCD\u0B9F\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1 \u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0BB5\u0B99\u0BCD\u0B95\u0BBF\u0B9A\u0BCD \u0B9A\u0BB2\u0BC1\u0B95\u0BC8\u0BAF\u0BC8\u0BAA\u0BCD \u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95 Promo-Flow-\u0B90 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
    totalOnPage: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BAE\u0BCA\u0BA4\u0BCD\u0BA4\u0BA4\u0BCD \u0BA4\u0BCA\u0B95\u0BC8",
    tryMore: "\u0BAE\u0BC7\u0BB2\u0BC1\u0BAE\u0BCD {n} \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF \u0B9A\u0BC6\u0BAF\u0BCD",
    tryMoreWait: "{s} \u0BB5\u0BBF\u0BA8\u0BBE\u0B9F\u0BBF\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0BAE\u0BC7\u0BB2\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF",
    srcYours: "\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B9F\u0BC8\u0BAF\u0BA4\u0BC1",
    srcSite: "\u0BA4\u0BB3\u0BAE\u0BCD",
    srcShared: "\u0BAA\u0B95\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
    srcFeed: "\u0B83\u0BAA\u0BC0\u0B9F\u0BCD",
    srcDataset: "\u0BAA\u0BB4\u0BC8\u0BAF \u0BAA\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BB2\u0BCD",
    srcKnown: "\u0B85\u0BB1\u0BBF\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1",
    ageToday: "\u0B87\u0BA9\u0BCD\u0BB1\u0BC1",
    ageDays: "{d} \u0BA8\u0BBE\u0BB3\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD",
    skippedMinSpend: "\u0BA4\u0BB5\u0BBF\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1, \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD \u0BA4\u0BC7\u0BB5\u0BC8: {codes}",
    sharePrompt: "{code} \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BA4\u0BC1. \u0BAE\u0BB1\u0BCD\u0BB1 Promo-Flow \u0BAA\u0BAF\u0BA9\u0BB0\u0BCD\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0B95\u0BBF\u0BB0\u0BB5\u0BBE? \u0B95\u0B9F\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BC7 \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BAE\u0BCD.",
    shareYes: "\u0BAA\u0B95\u0BBF\u0BB0\u0BCD",
    shareNo: "\u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BBE\u0BAE\u0BCD",
    shareAlways: "\u0B8E\u0BAA\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1\u0BAE\u0BCD \u0BAA\u0B95\u0BBF\u0BB0\u0BCD",
    sharedThanks: "\u0BAA\u0B95\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. \u0BA8\u0BA9\u0BCD\u0BB1\u0BBF.",
    shareModeL: "\u0B8E\u0BA9\u0B95\u0BCD\u0B95\u0BC1 \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4 \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BC8\u0BAA\u0BCD \u0BAA\u0B95\u0BBF\u0BB0\u0BCD\u0BA4\u0BB2\u0BCD",
    shareAsk: "\u0B92\u0BB5\u0BCD\u0BB5\u0BCA\u0BB0\u0BC1 \u0BAE\u0BC1\u0BB1\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0B95\u0BC7\u0BB3\u0BCD",
    shareAlwaysOpt: "\u0B8E\u0BAA\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1\u0BAE\u0BCD",
    shareNever: "\u0B92\u0BB0\u0BC1\u0BAA\u0BCB\u0BA4\u0BC1\u0BAE\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8"
  };

  // src/i18n/te.json
  var te_default = {
    appName: "Promo-Flow",
    tagline: "\u0C1A\u0C46\u0C15\u0C4D\u200C\u0C05\u0C35\u0C41\u0C1F\u0C4D\u200C\u0C32\u0C4B \u0C09\u0C24\u0C4D\u0C24\u0C2E \u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C2E\u0C30\u0C3F\u0C2F\u0C41 \u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D \u0C06\u0C2B\u0C30\u0C4D\u200C\u0C28\u0C41 \u0C15\u0C28\u0C41\u0C17\u0C4A\u0C02\u0C1F\u0C41\u0C02\u0C26\u0C3F",
    find: "\u0C09\u0C24\u0C4D\u0C24\u0C2E \u0C06\u0C26\u0C3E\u0C28\u0C41 \u0C15\u0C28\u0C41\u0C17\u0C4A\u0C28\u0C02\u0C21\u0C3F",
    stop: "\u0C06\u0C2A\u0C02\u0C21\u0C3F",
    language: "\u0C2D\u0C3E\u0C37",
    yourCodes: "\u0C28\u0C3E \u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32\u0C41",
    yourCodesHint: "\u0C2A\u0C4D\u0C30\u0C24\u0C3F \u0C32\u0C48\u0C28\u0C4D\u200C\u0C15\u0C41 \u0C12\u0C15 \u0C15\u0C4B\u0C21\u0C4D. \u0C2E\u0C40 \u0C26\u0C17\u0C4D\u0C17\u0C30 \u0C07\u0C2A\u0C4D\u0C2A\u0C1F\u0C3F\u0C15\u0C47 \u0C09\u0C28\u0C4D\u0C28\u0C35\u0C3F \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47.",
    addCode: "\u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
    telemetry: "\u0C05\u0C1C\u0C4D\u0C1E\u0C3E\u0C24 \u0C2B\u0C32\u0C3F\u0C24\u0C3E\u0C32\u0C28\u0C41 \u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C02\u0C21\u0C3F",
    telemetryHint: "\u0C2A\u0C02\u0C2A\u0C47\u0C26\u0C3F: \u0C38\u0C4D\u0C1F\u0C4B\u0C30\u0C4D, \u0C15\u0C4B\u0C21\u0C4D, \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C38\u0C3F\u0C02\u0C26\u0C3E \u0C32\u0C47\u0C26\u0C3E. \u0C35\u0C4D\u0C2F\u0C15\u0C4D\u0C24\u0C3F\u0C17\u0C24 \u0C21\u0C47\u0C1F\u0C3E \u0C32\u0C47\u0C26\u0C41.",
    apiBase: "\u0C38\u0C30\u0C4D\u0C35\u0C30\u0C4D \u0C1A\u0C3F\u0C30\u0C41\u0C28\u0C3E\u0C2E\u0C3E",
    working: "\u0C2A\u0C28\u0C3F \u0C1C\u0C30\u0C41\u0C17\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F\u2026",
    trying: "{code} \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C38\u0C4D\u0C24\u0C4B\u0C02\u0C26\u0C3F ({n}/{total})",
    noField: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C2A\u0C4D\u0C30\u0C4B\u0C2E\u0C4B \u0C15\u0C4B\u0C21\u0C4D \u0C2C\u0C3E\u0C15\u0C4D\u0C38\u0C4D \u0C15\u0C28\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41. \u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D/\u0C1A\u0C46\u0C15\u0C4D\u200C\u0C05\u0C35\u0C41\u0C1F\u0C4D \u0C26\u0C36\u0C28\u0C41 \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
    captcha: "\u0C38\u0C48\u0C1F\u0C4D \u0C27\u0C43\u0C35\u0C40\u0C15\u0C30\u0C23 \u0C05\u0C21\u0C41\u0C17\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F. \u0C2E\u0C40\u0C30\u0C47 \u0C2A\u0C42\u0C30\u0C4D\u0C24\u0C3F \u0C1A\u0C47\u0C2F\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C06\u0C2A\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F.",
    noTotal: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C3F\u0C02\u0C1A\u0C3E\u0C32\u0C4D\u0C38\u0C3F\u0C28 \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C1A\u0C26\u0C35\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C02.",
    noCodes: "\u0C08 \u0C38\u0C4D\u0C1F\u0C4B\u0C30\u0C4D\u200C\u0C15\u0C41 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32\u0C41 \u0C32\u0C47\u0C35\u0C41. \u0C2A\u0C3E\u0C2A\u0C2A\u0C4D\u200C\u0C32\u0C4B \u0C2E\u0C40 \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C1C\u0C4B\u0C21\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
    done: "\u0C2A\u0C42\u0C30\u0C4D\u0C24\u0C2F\u0C3F\u0C02\u0C26\u0C3F",
    before: "\u0C2E\u0C41\u0C02\u0C26\u0C41",
    after: "\u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24",
    youSave: "\u0C2E\u0C40 \u0C06\u0C26\u0C3E",
    bankOffer: "\u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D/\u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C06\u0C2B\u0C30\u0C4D",
    bankHint: "\u0C06\u0C2B\u0C30\u0C4D \u0C1F\u0C46\u0C15\u0C4D\u0C38\u0C4D\u0C1F\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C05\u0C02\u0C1A\u0C28\u0C3E. \u0C06 \u0C15\u0C3E\u0C30\u0C4D\u0C21\u0C4D/\u0C2A\u0C26\u0C4D\u0C27\u0C24\u0C3F\u0C24\u0C4B \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C3F\u0C38\u0C4D\u0C24\u0C47 \u0C35\u0C38\u0C4D\u0C24\u0C41\u0C02\u0C26\u0C3F; Promo-Flow \u0C26\u0C40\u0C28\u0C4D\u0C28\u0C3F \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C26\u0C41.",
    couponApplied: "\u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F",
    noneWorked: "\u0C08 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D\u200C\u0C32\u0C4B \u0C0F \u0C15\u0C4B\u0C21\u0C4D \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C2F\u0C32\u0C47\u0C26\u0C41.",
    estimate: "\u0C05\u0C02\u0C1A\u0C28\u0C3E",
    close: "\u0C2E\u0C42\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C02\u0C21\u0C3F",
    stopped: "\u0C06\u0C2A\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F.",
    unverifiedSite: "\u0C08 \u0C38\u0C48\u0C1F\u0C4D \u0C2E\u0C26\u0C4D\u0C26\u0C24\u0C41 \u0C2A\u0C4D\u0C30\u0C2F\u0C4B\u0C17\u0C3E\u0C24\u0C4D\u0C2E\u0C15\u0C02. \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C3F\u0C02\u0C1A\u0C47 \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C24\u0C41\u0C26\u0C3F \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
    notCheckout: "\u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D \u0C32\u0C47\u0C26\u0C3E \u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C24\u0C46\u0C30\u0C35\u0C02\u0C21\u0C3F.",
    capReached: "\u0C17\u0C30\u0C3F\u0C37\u0C4D\u0C20 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3E\u0C32 \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 \u0C06\u0C17\u0C3F\u0C02\u0C26\u0C3F.",
    diagnoseTitle: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C2A\u0C30\u0C3F\u0C36\u0C40\u0C32\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F",
    diagnoseState: "\u0C2A\u0C47\u0C1C\u0C40 \u0C38\u0C4D\u0C25\u0C3F\u0C24\u0C3F",
    stateBag: "\u0C2C\u0C4D\u0C2F\u0C3E\u0C17\u0C4D / \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D",
    stateCouponPanelOpen: "\u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C2A\u0C4D\u0C2F\u0C3E\u0C28\u0C46\u0C32\u0C4D \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3F \u0C09\u0C02\u0C26\u0C3F",
    stateCouponApplied: "\u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F",
    stateCouponError: "\u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C32\u0C4B\u0C2A\u0C02",
    statePayment: "\u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C2A\u0C47\u0C1C\u0C40",
    diagnoseCopy: "\u0C38\u0C4D\u0C28\u0C3E\u0C2A\u0C4D\u200C\u0C37\u0C3E\u0C1F\u0C4D \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
    diagnoseDownload: "\u0C21\u0C4C\u0C28\u0C4D\u200C\u0C32\u0C4B\u0C21\u0C4D",
    diagnoseNotice: "\u0C38\u0C4D\u0C28\u0C3E\u0C2A\u0C4D\u200C\u0C37\u0C3E\u0C1F\u0C4D \u0C08 \u0C2A\u0C30\u0C3F\u0C15\u0C30\u0C02\u0C32\u0C4B\u0C28\u0C47 \u0C15\u0C3E\u0C2A\u0C40 \u0C05\u0C35\u0C41\u0C24\u0C41\u0C02\u0C26\u0C3F; \u0C0E\u0C15\u0C4D\u0C15\u0C21\u0C3F\u0C15\u0C40 \u0C2A\u0C02\u0C2A\u0C2C\u0C21\u0C26\u0C41.",
    diagnoseCopied: "\u0C15\u0C3E\u0C2A\u0C40 \u0C05\u0C2F\u0C3F\u0C02\u0C26\u0C3F.",
    diagnoseFailed: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C15\u0C4D\u0C2F\u0C3E\u0C2A\u0C4D\u0C1A\u0C30\u0C4D \u0C1A\u0C47\u0C2F\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C02.",
    loginRequired: "\u0C15\u0C42\u0C2A\u0C28\u0C4D\u0C32\u0C41 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C08 \u0C38\u0C48\u0C1F\u0C4D\u200C\u0C32\u0C4B \u0C32\u0C3E\u0C17\u0C3F\u0C28\u0C4D \u0C15\u0C3E\u0C35\u0C3E\u0C32\u0C3F. \u0C32\u0C3E\u0C17\u0C3F\u0C28\u0C4D \u0C05\u0C2F\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
    rateLimited: "\u0C38\u0C48\u0C1F\u0C4D \u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3E\u0C32\u0C28\u0C41 \u0C2A\u0C30\u0C3F\u0C2E\u0C3F\u0C24\u0C02 \u0C1A\u0C47\u0C38\u0C4D\u0C24\u0C4B\u0C02\u0C26\u0C3F. \u0C38\u0C2E\u0C38\u0C4D\u0C2F \u0C30\u0C3E\u0C15\u0C41\u0C02\u0C21\u0C3E \u0C06\u0C2A\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F; \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
    originUser: "\u0C2E\u0C40 \u0C38\u0C4D\u0C35\u0C02\u0C24 \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32 \u0C28\u0C41\u0C02\u0C21\u0C3F",
    originListed: "\u0C38\u0C48\u0C1F\u0C4D \u0C2E\u0C40 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D \u0C15\u0C4B\u0C38\u0C02 \u0C1A\u0C42\u0C2A\u0C3F\u0C28\u0C26\u0C3F",
    originShared: "\u0C37\u0C47\u0C30\u0C4D \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C1C\u0C3E\u0C2C\u0C3F\u0C24\u0C3E \u0C28\u0C41\u0C02\u0C21\u0C3F",
    skippedIneligible: "\u0C26\u0C3E\u0C1F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F, \u0C38\u0C48\u0C1F\u0C4D \u0C2A\u0C4D\u0C30\u0C15\u0C3E\u0C30\u0C02 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C1A\u0C35\u0C41: {codes}",
    couponNotApplied: "\u0C09\u0C24\u0C4D\u0C24\u0C2E \u0C15\u0C42\u0C2A\u0C28\u0C4D ({code}) \u0C2A\u0C4D\u0C30\u0C38\u0C4D\u0C24\u0C41\u0C24\u0C02 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41. \u0C08 \u0C06\u0C26\u0C3E \u0C2A\u0C4A\u0C02\u0C26\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C26\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C2E\u0C40\u0C30\u0C47 \u0C28\u0C2E\u0C4B\u0C26\u0C41 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
    preAppliedLost: "\u0C07\u0C02\u0C24\u0C15\u0C41 \u0C2E\u0C41\u0C02\u0C26\u0C47 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C38\u0C3F\u0C28 \u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C36\u0C4B\u0C27\u0C28 \u0C38\u0C2E\u0C2F\u0C02\u0C32\u0C4B \u0C24\u0C40\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F. \u0C15\u0C3E\u0C35\u0C3E\u0C32\u0C02\u0C1F\u0C47 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
    couldNotRestore: "\u0C1A\u0C3F\u0C35\u0C30\u0C17\u0C3E \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C3F\u0C28 \u0C15\u0C42\u0C2A\u0C28\u0C4D\u200C\u0C28\u0C41 \u0C24\u0C40\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C02. \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C3F\u0C02\u0C1A\u0C47 \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
    noOffers: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C24\u0C15\u0C4D\u0C37\u0C23 \u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D \u0C06\u0C2B\u0C30\u0C4D\u0C32\u0C41 \u0C15\u0C28\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41.",
    payHint: "\u0C24\u0C26\u0C41\u0C2A\u0C30\u0C3F: \u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3F \u0C09\u0C24\u0C4D\u0C24\u0C2E \u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D \u0C06\u0C2B\u0C30\u0C4D\u200C\u0C28\u0C41 \u0C1A\u0C42\u0C21\u0C1F\u0C3E\u0C28\u0C3F\u0C15\u0C3F Promo-Flow\u200C\u0C28\u0C41 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F.",
    totalOnPage: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C02",
    tryMore: "\u0C2E\u0C30\u0C4B {n} \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F",
    tryMoreWait: "{s} \u0C38\u0C46\u0C15\u0C28\u0C4D\u0C32\u0C32\u0C4B \u0C2E\u0C30\u0C3F\u0C28\u0C4D\u0C28\u0C3F \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F",
    srcYours: "\u0C2E\u0C40\u0C26\u0C3F",
    srcSite: "\u0C38\u0C48\u0C1F\u0C4D",
    srcShared: "\u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C41\u0C28\u0C4D\u0C28\u0C26\u0C3F",
    srcFeed: "\u0C2B\u0C40\u0C21\u0C4D",
    srcDataset: "\u0C2A\u0C3E\u0C24 \u0C1C\u0C3E\u0C2C\u0C3F\u0C24\u0C3E",
    srcKnown: "\u0C24\u0C46\u0C32\u0C3F\u0C38\u0C3F\u0C28\u0C26\u0C3F",
    ageToday: "\u0C08\u0C30\u0C4B\u0C1C\u0C41",
    ageDays: "{d} \u0C30\u0C4B\u0C1C\u0C41\u0C32 \u0C15\u0C4D\u0C30\u0C3F\u0C24\u0C02",
    skippedMinSpend: "\u0C35\u0C26\u0C3F\u0C32\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F, \u0C2A\u0C46\u0C26\u0C4D\u0C26 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D \u0C15\u0C3E\u0C35\u0C3E\u0C32\u0C3F: {codes}",
    sharePrompt: "{code} \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C38\u0C3F\u0C02\u0C26\u0C3F. \u0C07\u0C24\u0C30 Promo-Flow \u0C35\u0C3F\u0C28\u0C3F\u0C2F\u0C4B\u0C17\u0C26\u0C3E\u0C30\u0C41\u0C32\u0C24\u0C4B \u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C35\u0C3E\u0C32\u0C3E? \u0C38\u0C4D\u0C1F\u0C4B\u0C30\u0C4D \u0C2E\u0C30\u0C3F\u0C2F\u0C41 \u0C15\u0C4B\u0C21\u0C4D \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C2A\u0C02\u0C2A\u0C2C\u0C21\u0C24\u0C3E\u0C2F\u0C3F.",
    shareYes: "\u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C02\u0C21\u0C3F",
    shareNo: "\u0C35\u0C26\u0C4D\u0C26\u0C41",
    shareAlways: "\u0C0E\u0C32\u0C4D\u0C32\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C42 \u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C02\u0C21\u0C3F",
    sharedThanks: "\u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F. \u0C27\u0C28\u0C4D\u0C2F\u0C35\u0C3E\u0C26\u0C3E\u0C32\u0C41.",
    shareModeL: "\u0C28\u0C3E\u0C15\u0C41 \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C35\u0C21\u0C02",
    shareAsk: "\u0C2A\u0C4D\u0C30\u0C24\u0C3F\u0C38\u0C3E\u0C30\u0C3F \u0C05\u0C21\u0C17\u0C02\u0C21\u0C3F",
    shareAlwaysOpt: "\u0C0E\u0C32\u0C4D\u0C32\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C42",
    shareNever: "\u0C0E\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C42 \u0C35\u0C26\u0C4D\u0C26\u0C41"
  };

  // src/i18n/i18n.js
  var TABLES = { en: en_default, hi: hi_default, mr: mr_default, ta: ta_default, te: te_default };
  function t(lang, key, vars = {}) {
    const s = TABLES[lang]?.[key] ?? en_default[key] ?? key;
    return s.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? `{${k}}`);
  }

  // src/ui/overlay.js
  var CSS = `
/* Glass panel. Direction: calm, exact. One accent (blue) for actions and focus; green only for money saved.
   Spacing on a 4px grid, one easing curve, motion limited to opacity and transform. */
:host{all:initial}
.box{--ease:cubic-bezier(.22,1,.36,1);--fg:rgba(0,0,0,.88);--fg2:rgba(60,60,67,.72);--fg3:rgba(60,60,67,.56);--line:rgba(0,0,0,.08);
 --glass:rgba(255,255,255,.58);--edge:rgba(255,255,255,.8);--ctl:rgba(120,120,128,.12);--ctl-h:rgba(120,120,128,.2);--ac:#0a6cdc;--ok:#1f7a3d;--warn:#8a5a00;
 position:fixed;right:16px;top:16px;z-index:2147483647;box-sizing:border-box;width:336px;max-width:calc(100vw - 32px);max-height:calc(100vh - 32px);overflow:auto;
 font:14px/20px -apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI Variable Text","Segoe UI",Roboto,"Noto Sans","Noto Sans Devanagari","Noto Sans Tamil","Noto Sans Telugu",sans-serif;
 color:var(--fg);padding:16px;border-radius:20px;background:var(--glass);border:1px solid var(--edge);
 box-shadow:inset 0 1px 0 rgba(255,255,255,.7),0 0 0 .5px var(--line),0 12px 32px rgba(0,0,0,.14),0 2px 6px rgba(0,0,0,.06);
 -webkit-backdrop-filter:blur(28px) saturate(180%);backdrop-filter:blur(28px) saturate(180%);
 animation:in 320ms var(--ease) both}
@supports not ((backdrop-filter:blur(1px)) or (-webkit-backdrop-filter:blur(1px))){.box{background:rgba(250,250,252,.98)}}
@keyframes in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.row{display:flex;justify-content:space-between;align-items:center;gap:8px;min-height:32px}
h1{font-size:16px;line-height:20px;font-weight:600;margin:0}
button{font:inherit;color:var(--fg);border:0;background:var(--ctl);border-radius:10px;min-height:32px;padding:4px 12px;cursor:pointer;
 box-shadow:inset 0 1px 0 rgba(255,255,255,.35);transition:background-color 150ms var(--ease),transform 150ms var(--ease),opacity 150ms var(--ease)}
button:hover{background:var(--ctl-h)}button:active{transform:scale(.98)}
button:focus-visible{outline:2px solid var(--ac);outline-offset:2px}button:disabled{opacity:.5;cursor:default;transform:none}
.msg{margin:12px 0 0}.msg>div+div{margin-top:4px}
.big{font-size:24px;line-height:28px;font-weight:500;color:var(--ok);font-variant-numeric:tabular-nums;margin:12px 0!important}
.muted{color:var(--fg2);font-size:12px;line-height:16px;margin-top:8px}.msg .muted{margin-top:2px}.warn{color:var(--warn)}
ul{margin:12px 0 0;padding:4px 0 0;list-style:none;max-height:160px;overflow:auto;border-top:1px solid var(--line)}
li{display:flex;justify-content:space-between;align-items:center;min-height:32px;font-size:13px;line-height:20px;gap:8px;font-variant-numeric:tabular-nums}
li+li{border-top:1px solid var(--line)}
li .tag{color:var(--fg3);font-size:12px;margin-left:8px}li .fail{color:var(--fg3)}
.acts{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.acts button:first-child:not(:only-child),.acts button[data-more]{background:var(--ac);color:#fff;box-shadow:inset 0 1px 0 rgba(255,255,255,.25)}
.acts button[data-more]:disabled{background:var(--ctl);color:var(--fg2)}
@media (prefers-reduced-motion:reduce){.box{animation:none}button{transition:none}}
`;
  var DAY = 864e5;
  var SOURCE_KEYS = { user: "srcYours", listed: "srcSite", preapplied: "srcSite", shared: "srcShared", feed: "srcFeed", dataset: "srcDataset", crowd: "srcShared" };
  function sourceTag(lang, origin, meta = {}, now = Date.now()) {
    const key = SOURCE_KEYS[origin] ?? SOURCE_KEYS[meta.source] ?? "srcKnown";
    const parts = [t(lang, key)];
    const ref = Math.max(meta.lastSuccessAt ?? 0, meta.lastSeen ?? 0);
    if (ref && origin !== "user" && origin !== "listed") {
      const d = Math.floor(Math.max(0, now - ref) / DAY);
      parts.push(d === 0 ? t(lang, "ageToday") : t(lang, "ageDays", { d }));
    }
    return parts.join(" \xB7 ");
  }
  function createOverlay(doc, lang, { onStop }) {
    const host = doc.createElement("div");
    host.setAttribute("data-promoflow", "");
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${CSS}</style><div class="box" role="status" aria-live="polite">
    <div class="row"><h1></h1><button type="button" data-act></button></div><div class="msg"></div><ul></ul><div class="muted"></div></div>`;
    doc.documentElement.appendChild(host);
    const $ = (s) => root.querySelector(s);
    $("h1").textContent = t(lang, "appName");
    let closeMode = false;
    const act = $("[data-act]");
    act.textContent = t(lang, "stop");
    act.addEventListener("click", () => closeMode ? host.remove() : onStop());
    const setClose = () => {
      closeMode = true;
      act.textContent = t(lang, "close");
    };
    const outcomeLine = (e) => `${e.code}`;
    return {
      working: (m) => {
        $(".msg").textContent = m;
      },
      trying: ({ code, n, total }) => {
        $(".msg").textContent = t(lang, "trying", { code, n, total });
      },
      result: (e) => {
        const li = doc.createElement("li");
        const a = doc.createElement("span");
        a.textContent = outcomeLine(e);
        const tag = doc.createElement("span");
        tag.className = "tag";
        tag.textContent = sourceTag(lang, e.origin, e.meta);
        a.appendChild(tag);
        const b = doc.createElement("span");
        b.textContent = e.outcome === "applied" ? `\u2212${formatRupees(e.saving)}` : "\u2715";
        if (e.outcome !== "applied") b.className = "fail";
        li.append(a, b);
        $("ul").appendChild(li);
      },
      message(text, warn = true) {
        $(".msg").textContent = text;
        $(".msg").className = warn ? "msg warn" : "msg";
        setClose();
      },
      summary(s, unverified) {
        setClose();
        const m = $(".msg");
        m.textContent = "";
        const line = (txt, cls) => {
          const d = doc.createElement("div");
          if (cls) d.className = cls;
          d.textContent = txt;
          m.appendChild(d);
        };
        if (!s.coupon && !s.offer) {
          line(t(lang, "noneWorked"));
        }
        if (s.coupon) {
          line(`${t(lang, "couponApplied")}: ${s.coupon.code}`);
          const originKey = { user: "originUser", listed: "originListed", server: "originShared", seed: "originShared" }[s.coupon.origin];
          if (originKey) line(t(lang, originKey), "muted");
          line(`${t(lang, "before")} ${formatRupees(s.baseline)} \u2192 ${t(lang, "after")} ${formatRupees(s.coupon.payable)}`);
          if (!s.finalApplied) line(t(lang, "couponNotApplied", { code: s.coupon.code }), "warn");
          line(`${t(lang, "youSave")} ${formatRupees(s.coupon.saving)}`, "big");
        }
        if (s.offer) {
          line(`${t(lang, "bankOffer")}: ${s.offer.text}`);
          line(`${t(lang, "estimate")}: \u2212${formatRupees(s.offer.estimatedSaving)} \u2192 ${formatRupees(s.estimatedPayable)}`);
          $(".box > .muted").textContent = t(lang, "bankHint");
        }
        if (s.skipped?.length) line(t(lang, "skippedIneligible", { codes: s.skipped.join(", ") }), "muted");
        if (s.skippedMinSpend?.length) line(t(lang, "skippedMinSpend", { codes: s.skippedMinSpend.join(", ") }), "muted");
        if (s.preAppliedLost) line(t(lang, "preAppliedLost"), "warn");
        const stopKey = { blocked_captcha: "captcha", aborted: "stopped", rate_limited: "rateLimited", login_required: "loginRequired", could_not_restore: "couldNotRestore", panel_unavailable: "noField" }[s.stopped];
        if (stopKey) line(t(lang, stopKey), "warn");
        if (unverified) $(".box > .muted").textContent += ` ${t(lang, "unverifiedSite")}`;
      },
      /** "Try N more" button, enabled after a cooldown so tries stay paced. */
      tryMore({ n, cooldownMs, onClick, now = Date.now, setTimer = setTimeout }) {
        const wrap = doc.createElement("div");
        wrap.className = "acts";
        const b = doc.createElement("button");
        b.type = "button";
        b.setAttribute("data-more", "");
        wrap.appendChild(b);
        $(".msg").appendChild(wrap);
        const until = now() + cooldownMs;
        const tick = () => {
          const left = Math.ceil((until - now()) / 1e3);
          if (left > 0) {
            b.disabled = true;
            b.textContent = t(lang, "tryMoreWait", { s: left });
            setTimer(tick, 1e3);
            return;
          }
          b.disabled = false;
          b.textContent = t(lang, "tryMore", { n });
        };
        tick();
        b.addEventListener("click", () => {
          if (!b.disabled) {
            b.disabled = true;
            onClick();
          }
        });
        return b;
      },
      /** Asks before sharing a code that worked. onAnswer('yes' | 'no' | 'always'). */
      sharePrompt({ code, onAnswer }) {
        const box = doc.createElement("div");
        box.className = "muted";
        box.setAttribute("data-share", "");
        box.textContent = t(lang, "sharePrompt", { code });
        const wrap = doc.createElement("div");
        wrap.className = "acts";
        for (const [ans, key] of [["yes", "shareYes"], ["no", "shareNo"], ["always", "shareAlways"]]) {
          const b = doc.createElement("button");
          b.type = "button";
          b.textContent = t(lang, key);
          b.setAttribute("data-answer", ans);
          b.addEventListener("click", () => {
            box.remove();
            wrap.remove();
            onAnswer(ans);
          });
          wrap.appendChild(b);
        }
        $(".msg").append(box, wrap);
      },
      note(text) {
        const d = doc.createElement("div");
        d.className = "muted";
        d.textContent = text;
        $(".msg").appendChild(d);
      },
      payment(res) {
        setClose();
        const m = $(".msg");
        m.textContent = "";
        const line = (txt, cls) => {
          const d = doc.createElement("div");
          if (cls) d.className = cls;
          d.textContent = txt;
          m.appendChild(d);
        };
        if (res.status !== "ok") {
          line(t(lang, "noTotal"), "warn");
          return;
        }
        if (res.coupon) {
          line(`${t(lang, "couponApplied")}: ${res.coupon.code}`);
          line(`${t(lang, "youSave")} ${formatRupees(res.coupon.saving)}`, "big");
        }
        line(`${t(lang, "totalOnPage")}: ${formatRupees(res.total)}`);
        if (res.offer) {
          line(`${t(lang, "bankOffer")}: ${res.offer.text}`);
          line(`${t(lang, "estimate")}: \u2212${formatRupees(res.offer.estimatedSaving)} \u2192 ${formatRupees(res.estimatedPayable)}`);
          $(".box > .muted").textContent = t(lang, "bankHint");
        } else {
          line(t(lang, "noOffers"));
        }
      },
      destroy: () => host.remove()
    };
  }

  // src/content/capture.js
  var MAX_BYTES = 200 * 1024;
  var STATES = ["bag", "coupon_panel_open", "coupon_applied", "coupon_error", "payment"];
  var ANCHOR = /coupon|promo|voucher|offer|apply|remove|total|payable|amount|bank|login|sign\s*in/i;
  var SENSITIVE = /address|pin\s*code|pincode|deliver(?:y|ing)?\s+to|profile|account\s*name|saved\s*card|upi\s*id/i;
  var DROP_TAGS = "script, style, svg, img, picture, video, iframe, noscript, link, meta, input[type=hidden]";
  var SKIP_TAGS = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "SVG", "IMG", "PICTURE", "VIDEO", "IFRAME", "NOSCRIPT", "LINK", "META", "HTML", "BODY", "HEAD"]);
  var KEEP_ATTRS = /* @__PURE__ */ new Set(["id", "class", "name", "type", "role", "placeholder", "for", "href", "disabled", "checked"]);
  var ATTR_FOR_ANCHOR = ["id", "class", "name", "placeholder", "aria-label", "role", "title"];
  var EMAIL = /[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g;
  var PHONE = /(?<![\d₹])\+?\d(?:[\s-]?\d){9,}(?!\d)/g;
  var PIN = /(?<![\d₹.,])\b\d{6}\b(?![.,]\d)/g;
  function redact(text) {
    return String(text).replace(EMAIL, "[removed]").replace(PHONE, "[removed]").replace(PIN, "[removed]");
  }
  var bytes = (s) => new TextEncoder().encode(s).length;
  function ownText(el) {
    let t2 = "";
    for (const n of el.childNodes) if (n.nodeType === 3) t2 += ` ${n.nodeValue}`;
    return t2.replace(/\s+/g, " ").trim();
  }
  function attrBlob(el) {
    const parts = ATTR_FOR_ANCHOR.map((a) => el.getAttribute(a) || "");
    for (const a of el.attributes) if (a.name.startsWith("data-") && a.value.length < 60) parts.push(a.name, a.value);
    return parts.join(" ");
  }
  function isAnchor(el) {
    if (SKIP_TAGS.has(el.tagName.toUpperCase())) return false;
    if (el.closest("[data-promoflow]")) return false;
    const own = ownText(el);
    if (own.length > 0 && own.length <= 80 && ANCHOR.test(own)) return true;
    return ANCHOR.test(attrBlob(el));
  }
  function depthOf(el) {
    let d = 0;
    for (let n = el; n.parentElement; n = n.parentElement) d++;
    return d;
  }
  function climb(doc, el, levels) {
    let n = el;
    for (let i = 0; i < levels; i++) {
      const p = n.parentElement;
      if (!p || p === doc.body || p === doc.documentElement) break;
      n = p;
    }
    return n;
  }
  function mergeRoots(roots) {
    const uniq = [...new Set(roots)];
    const kept = uniq.filter((r) => !uniq.some((o) => o !== r && o.contains(r)));
    kept.sort((a, b) => a.compareDocumentPosition(b) & 4 ? -1 : 1);
    return kept;
  }
  function pathOnly(href) {
    try {
      const u = new URL(href, "https://x.invalid/");
      if (!/^https?:$/.test(u.protocol)) return "";
      return u.pathname;
    } catch {
      return "";
    }
  }
  function sanitize(doc, root) {
    const box = doc.createElement("div");
    box.appendChild(root.cloneNode(true));
    box.querySelectorAll(DROP_TAGS).forEach((n) => n.remove());
    box.querySelectorAll("textarea").forEach((n) => {
      n.textContent = "";
    });
    const hits = [...box.querySelectorAll("*")].reverse();
    for (const el of hits) {
      if (!box.contains(el)) continue;
      if (SENSITIVE.test(attrBlob(el))) {
        el.remove();
        continue;
      }
      const own = ownText(el);
      if (own.length === 0 || own.length > 120 || !SENSITIVE.test(own)) continue;
      const p = el.parentElement;
      const target = p && p !== box && (p.textContent || "").length <= 300 && !ANCHOR.test(p.textContent || "") ? p : el;
      target.remove();
    }
    for (const el of box.querySelectorAll("*")) {
      for (const a of [...el.attributes]) {
        const name = a.name.toLowerCase();
        const keep = KEEP_ATTRS.has(name) || name.startsWith("aria-") || name.startsWith("data-") && a.value.length < 60;
        if (!keep) {
          el.removeAttribute(a.name);
          continue;
        }
        if (name === "href") {
          const p = pathOnly(a.value);
          if (p) el.setAttribute("href", p);
          else el.removeAttribute("href");
        } else {
          el.setAttribute(a.name, redact(a.value));
        }
      }
    }
    const walker = doc.createTreeWalker(box, 4 | 128);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const n of nodes) {
      if (n.nodeType === 8) {
        n.remove();
        continue;
      }
      let v = redact(n.nodeValue);
      if (v.length > 120) v = `${v.slice(0, 120)}\u2026`;
      n.nodeValue = v;
    }
    return box.innerHTML;
  }
  function captureSnapshot(doc, { state = "bag", maxBytes = MAX_BYTES, now = () => /* @__PURE__ */ new Date() } = {}) {
    const loc = doc.location || doc.defaultView?.location;
    const anchors = [...doc.body.querySelectorAll("*")].filter(isAnchor);
    let pieces = [];
    for (let levels = 4; levels >= 0; levels--) {
      const roots = mergeRoots(anchors.map((a) => climb(doc, a, levels)));
      pieces = roots.map((r) => ({ depth: depthOf(r), html: sanitize(doc, r) }));
      if (bytes(pieces.map((p) => p.html).join("\n")) <= maxBytes) break;
    }
    while (pieces.length > 0 && bytes(pieces.map((p) => p.html).join("\n")) > maxBytes) {
      let di = 0;
      pieces.forEach((p, i) => {
        if (p.depth > pieces[di].depth) di = i;
      });
      pieces.splice(di, 1);
    }
    return {
      host: String(loc?.hostname || "").toLowerCase(),
      path: String(loc?.pathname || ""),
      state: STATES.includes(state) ? state : "bag",
      capturedAt: now().toISOString(),
      html: pieces.map((p) => p.html).join("\n")
    };
  }

  // src/lib/telemetry.js
  var REPORTABLE_ORIGINS = Object.freeze(["server", "seed", "listed"]);
  var shouldReport = (origin) => REPORTABLE_ORIGINS.includes(origin);

  // src/lib/lastResult.js
  var LAST_MAX_AGE_MS = 30 * 60 * 1e3;
  function freshLast(entry, host, now = Date.now()) {
    if (!entry || typeof entry.at !== "number") return null;
    if (entry.host !== String(host).toLowerCase()) return null;
    const age = now - entry.at;
    return age >= 0 && age <= LAST_MAX_AGE_MS ? entry : null;
  }

  // src/content/paymentAdvice.js
  function pageTotal(doc, recipe) {
    const el = recipe?.total ? locate(doc, recipe.total) : null;
    if (el) {
      const amounts = findRupeeAmounts(el.textContent);
      if (amounts.length) return amounts[amounts.length - 1];
    }
    return readTotalPaise(doc);
  }
  function pageOffers(doc, recipe) {
    if (recipe?.offers?.container) {
      const box = locate(doc, recipe.offers.container);
      return box ? readOfferTexts(box) : [];
    }
    return readOfferTexts(doc);
  }
  function adviseOnPayment({ doc, recipe = null, last = null, now = Date.now() }) {
    const total = pageTotal(doc, recipe);
    if (total == null) return { status: "no_total" };
    const host = String(doc.location?.hostname || "").toLowerCase();
    const stored = freshLast(last, host, now);
    const couponShown = !!stored && stored.baseline > total;
    const baseline = couponShown ? stored.baseline : total;
    const offerOpts = pageOffers(doc, recipe).map(parseOffer).filter((o) => o && o.kind === "instant").map((o, i) => ({ id: `offer:${i}`, ...o }));
    const couponOpts = couponShown ? [{ id: stored.code, payableAfter: total }] : [];
    const combo = bestCombination({ baseline, layers: [couponOpts, offerOpts] });
    const offerPick = combo.picks.find((p) => String(p.id).startsWith("offer:")) ?? null;
    const saving = offerPick ? estimateSaving(offerPick, total) : 0;
    return {
      status: "ok",
      total,
      coupon: couponShown ? { code: stored.code, saving: baseline - total } : null,
      pageDiffers: couponShown && stored.payable !== total,
      offer: offerPick && saving > 0 ? { text: offerPick.raw, issuer: offerPick.issuer, estimatedSaving: saving } : null,
      estimatedPayable: total - (offerPick && saving > 0 ? saving : 0)
    };
  }

  // src/content/share.js
  function offerShare(ui, s, { host, lang, shareMode, send = (m) => chrome.runtime.sendMessage(m) }) {
    if (shareMode === "never" || !s.coupon || !s.finalApplied || s.coupon.origin !== "user" || !(s.coupon.saving > 0)) return false;
    const share = () => send({ type: "PF_SHARE", domain: host, code: s.coupon.code }).then((r) => {
      if (r?.ok) ui.note(t(lang, "sharedThanks"));
    }).catch(() => {
    });
    if (shareMode === "always") {
      share();
      return true;
    }
    ui.sharePrompt({
      code: s.coupon.code,
      onAnswer: (a) => {
        if (a === "always") send({ type: "PF_SET_SHARE_MODE", mode: "always" }).catch(() => {
        });
        if (a === "yes" || a === "always") share();
      }
    });
    return true;
  }

  // src/content/contentScript.js
  var MORE_COOLDOWN_MS = 3e4;
  if (!window.__promoFlowLoaded) {
    window.__promoFlowLoaded = true;
    let running = null;
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg?.type === "PF_PING") {
        sendResponse({ ok: true });
        return;
      }
      if (msg?.type === "PF_STOP") {
        running?.abort();
        sendResponse({ ok: true });
        return;
      }
      if (msg?.type === "PF_CAPTURE") {
        try {
          sendResponse({ ok: true, snapshot: captureSnapshot(document, { state: msg.state }) });
        } catch (e) {
          sendResponse({ ok: false, error: String(e?.message || e) });
        }
        return;
      }
      if (msg?.type !== "PF_START") return;
      sendResponse({ ok: true });
      start(msg).catch((e) => console.warn("[Promo-Flow]", e?.message));
    });
    async function start(msg) {
      const { candidates, lang, overrides, recipe, shareMode = "ask", exclude = [] } = msg;
      document.querySelectorAll("[data-promoflow]").forEach((n) => n.remove());
      if (running) running.abort();
      const ctrl = new AbortController();
      running = { abort: () => ctrl.abort() };
      const host = normalizeHost(location.hostname);
      const adapter = pickAdapter(host);
      const siteRecipe = recipe && Array.isArray(recipe.hosts) && recipe.hosts.includes(host) ? recipe : null;
      const ui = createOverlay(document, lang, { onStop: () => ctrl.abort() });
      const metaByCode = new Map((candidates || []).filter((c) => c && typeof c === "object").map((c) => [String(c.code).toUpperCase(), c]));
      ui.working(t(lang, "working"));
      if (siteRecipe && pageKind(siteRecipe, location.pathname) === "payment") {
        try {
          const last = await chrome.runtime.sendMessage({ type: "PF_GET_LAST", host }).catch(() => null);
          ui.payment(adviseOnPayment({ doc: document, recipe: siteRecipe, last }));
        } finally {
          running = null;
        }
        return;
      }
      try {
        const s = await runSearch({
          doc: document,
          adapter,
          overrides: overrides || {},
          recipe: siteRecipe,
          candidates,
          exclude,
          signal: ctrl.signal,
          onProgress: (p) => {
            if (p.phase === "trying") ui.trying(p);
            else if (p.phase === "result") {
              ui.result({ ...p, meta: metaByCode.get(p.code) });
              if (shouldReport(p.origin)) {
                chrome.runtime.sendMessage({ type: "PF_REPORT", domain: host, code: p.code, outcome: p.outcome }).catch(() => {
                });
              }
            }
          }
        });
        const failKey = { no_promo_field: "noField", blocked_captcha: "captcha", no_total: "noTotal", no_codes: "noCodes", login_required: "loginRequired" }[s.status];
        if (s.status !== "ok") ui.message(t(lang, failKey || "noField"));
        else {
          ui.summary(s, !!adapter.unverified);
          if (s.coupon && s.finalApplied) {
            chrome.runtime.sendMessage({ type: "PF_SAVE_LAST", host, code: s.coupon.code, baseline: s.baseline, payable: s.finalPayable }).catch(() => {
            });
          }
          if (siteRecipe?.pages?.payment && pageKind(siteRecipe, location.pathname) === "bag") ui.note(t(lang, "payHint"));
          offerShare(ui, s, { host, lang, shareMode });
          if (s.remaining > 0 && !s.stopped && s.cap - (s.finalApplied ? 1 : 0) > 0) {
            const tried = [.../* @__PURE__ */ new Set([...exclude, ...s.tried])];
            const n = Math.min(s.remaining, s.cap - (s.finalApplied ? 1 : 0));
            ui.tryMore({ n, cooldownMs: MORE_COOLDOWN_MS, onClick: () => start({ ...msg, exclude: tried }) });
          }
        }
      } finally {
        running = null;
      }
    }
  }
})();
