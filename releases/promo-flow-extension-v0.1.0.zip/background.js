// src/algorithms/Trie.js
var Node = class {
  constructor() {
    this.children = /* @__PURE__ */ new Map();
    this.end = false;
    this.tries = 0;
    this.successes = 0;
  }
};
var normalizeCode = (code) => String(code ?? "").trim().toUpperCase();
var Trie = class {
  constructor() {
    this.root = new Node();
    this.size = 0;
  }
  insert(code) {
    const w = normalizeCode(code);
    if (!w) return false;
    let n = this.root;
    for (const ch of w) {
      if (!n.children.has(ch)) n.children.set(ch, new Node());
      n = n.children.get(ch);
    }
    if (!n.end) {
      n.end = true;
      this.size++;
    }
    return true;
  }
  #walk(w) {
    let n = this.root;
    for (const ch of w) {
      n = n.children.get(ch);
      if (!n) return null;
    }
    return n;
  }
  search(code) {
    const n = this.#walk(normalizeCode(code));
    return !!n && n.end;
  }
  startsWith(prefix) {
    return this.#walk(normalizeCode(prefix)) !== null;
  }
  /** Add historical counts for a code; counts are added to every node on the path. */
  recordCounts(code, tries, successes) {
    const w = normalizeCode(code);
    if (!w || tries < 0 || successes < 0 || successes > tries) return false;
    this.insert(w);
    let n = this.root;
    for (const ch of w) {
      n = n.children.get(ch);
      n.tries += tries;
      n.successes += successes;
    }
    return true;
  }
  record(code, success) {
    return this.recordCounts(code, 1, success ? 1 : 0);
  }
  /**
   * Smoothed success probability for a code: uses the deepest node on the code's path that has at
   * least `minTries` observations, with Laplace smoothing. Falls back to `fallback` when nothing is known.
   */
  prior(code, { alpha = 1, beta = 1, minTries = 3, fallback = 0.2 } = {}) {
    const w = normalizeCode(code);
    let n = this.root;
    let best = null;
    for (const ch of w) {
      n = n.children.get(ch);
      if (!n) break;
      if (n.tries >= minTries) best = n;
    }
    if (!best) return fallback;
    return (best.successes + alpha) / (best.tries + alpha + beta);
  }
};

// src/algorithms/Heap.js
var Heap = class {
  /** @param before (a, b) => number; negative when `a` must be closer to the top than `b`. */
  constructor(before, items = []) {
    this.before = before;
    this.seq = 0;
    this.a = items.map((item) => ({ item, seq: this.seq++ }));
    for (let i = (this.a.length >> 1) - 1; i >= 0; i--) this.#down(i);
  }
  get size() {
    return this.a.length;
  }
  #less(i, j) {
    const c = this.before(this.a[i].item, this.a[j].item);
    return c < 0 || c === 0 && this.a[i].seq < this.a[j].seq;
  }
  #swap(i, j) {
    [this.a[i], this.a[j]] = [this.a[j], this.a[i]];
  }
  #up(i) {
    while (i > 0) {
      const p = i - 1 >> 1;
      if (!this.#less(i, p)) break;
      this.#swap(i, p);
      i = p;
    }
  }
  #down(i) {
    const n = this.a.length;
    for (; ; ) {
      const l = 2 * i + 1;
      const r = l + 1;
      let m = i;
      if (l < n && this.#less(l, m)) m = l;
      if (r < n && this.#less(r, m)) m = r;
      if (m === i) break;
      this.#swap(i, m);
      i = m;
    }
  }
  push(item) {
    this.a.push({ item, seq: this.seq++ });
    this.#up(this.a.length - 1);
  }
  peek() {
    return this.a.length ? this.a[0].item : void 0;
  }
  pop() {
    if (!this.a.length) return void 0;
    const top = this.a[0].item;
    const last = this.a.pop();
    if (this.a.length) {
      this.a[0] = last;
      this.#down(0);
    }
    return top;
  }
  /** Non-destructive snapshot of all items in heap order (best first). */
  toSortedArray() {
    return [...this.a].sort((x, y) => this.before(x.item, y.item) || x.seq - y.seq).map((e) => e.item);
  }
};
var MaxHeap = class extends Heap {
  constructor(key = (x) => x, items = []) {
    super((a, b) => key(b) - key(a), items);
  }
};
var MinHeap = class extends Heap {
  constructor(key = (x) => x, items = []) {
    super((a, b) => key(a) - key(b), items);
  }
};

// src/background/candidates.js
var CODE_RE = /^[A-Z0-9_-]{3,32}$/;
var META_KEYS = ["source", "lastSeen", "lastSuccessAt", "expiresAt", "minSpend", "firstOrderOnly"];
function buildCandidates({ server = [], seed = [], user = [] }, k = 10) {
  const trie = new Trie();
  const byCode = /* @__PURE__ */ new Map();
  const add = (item, origin) => {
    const code = normalizeCode(item.code);
    if (!code || !CODE_RE.test(code)) return;
    const prev = byCode.get(code);
    const meta = {};
    for (const k2 of META_KEYS) if (item[k2] != null) meta[k2] = item[k2];
    byCode.set(code, { ...prev, ...meta, code, origin: prev?.origin ?? origin, score: item.score ?? prev?.score, stats: item.stats ?? prev?.stats });
    if (item.stats && item.stats.tries >= 0) trie.recordCounts(code, item.stats.tries, Math.min(item.stats.successes ?? 0, item.stats.tries));
  };
  seed.forEach((c) => add(c, "seed"));
  server.forEach((c) => add(c, "server"));
  user.forEach((c) => add({ code: c }, "user"));
  for (const c of user) {
    const code = normalizeCode(c);
    if (code && byCode.has(code)) byCode.get(code).origin = "user";
  }
  const scored = [...byCode.values()].map((c) => {
    const base = c.score ?? trie.prior(c.code);
    return { ...c, rank: base + (c.origin === "user" ? 1 : 0) };
  });
  const heap = new MaxHeap((c) => c.rank, scored);
  const out = [];
  while (out.length < k && heap.size > 0) out.push(heap.pop());
  return out;
}
var TtlCache = class _TtlCache {
  constructor(ttlMs = 6 * 36e5, now = () => Date.now()) {
    this.ttlMs = ttlMs;
    this.now = now;
    this.map = /* @__PURE__ */ new Map();
    this.heap = new MinHeap((e) => e.expiresAt);
  }
  set(key, value) {
    const e = { key, value, expiresAt: this.now() + this.ttlMs };
    this.map.set(key, e);
    this.heap.push(e);
  }
  /** Drop everything expired. Heap entries that were overwritten are stale and skipped. */
  sweep() {
    const t = this.now();
    while (this.heap.size > 0 && this.heap.peek().expiresAt <= t) {
      const e = this.heap.pop();
      if (this.map.get(e.key) === e) this.map.delete(e.key);
    }
  }
  get(key) {
    this.sweep();
    return this.map.get(key)?.value;
  }
  get size() {
    this.sweep();
    return this.map.size;
  }
  serialize() {
    return [...this.map.values()];
  }
  static restore(entries, ttlMs, now) {
    const c = new _TtlCache(ttlMs, now);
    for (const e of entries || []) {
      if (!e || typeof e.key !== "string" || typeof e.expiresAt !== "number") continue;
      c.map.set(e.key, e);
      c.heap.push(e);
    }
    c.sweep();
    return c;
  }
};

// src/lib/money.js
var RUPEE_RE = /(?:₹|rs\.?|inr)\s*(\d[\d,]*)(?:\.(\d{1,2}))?/gi;
function toPaise(whole, frac) {
  const w = String(whole).replace(/,/g, "");
  if (!w) return null;
  const paise = Number(w) * 100 + Number(String(frac || "").padEnd(2, "0"));
  return Number.isSafeInteger(paise) ? paise : null;
}
function findRupeeAmounts(text) {
  const out = [];
  if (text == null) return out;
  const s = String(text).replace(/ /g, " ");
  for (const m of s.matchAll(RUPEE_RE)) {
    const p = toPaise(m[1], m[2]);
    if (p != null) out.push(p);
  }
  return out;
}

// src/content/domDetector.js
var PROMO_WORDS = /coupon|promo|voucher|discount|reduction|offer\s*code/i;
var WEAK_WORDS = /gift\s*card|\bcode\b/i;
var NEGATIVE = /search|e-?mail|phone|mobile|pin\s*code|zip|otp|password|address|first\s*name|last\s*name|\bcard\s*number\b|cvv|expiry/i;
var BAD_TYPES = /* @__PURE__ */ new Set(["password", "email", "tel", "search", "number", "hidden", "checkbox", "radio", "file"]);
var APPLY_WORDS = /apply|redeem|submit|check|add|use|ok|go/i;
var STRONG_APPLY = /apply|redeem/i;
var TOGGLE_WORDS = /(have|got|add|enter|use|apply)\s+(a\s+|your\s+)?(promo|coupon|voucher|discount|gift)/i;
var TOTAL_LABEL = /(order\s*total|grand\s*total|amount\s*payable|total\s*payable|total\s*amount|you\s*pay|to\s*pay|net\s*payable|^total\b)/i;
var NOT_TOTAL = /sub\s*-?\s*total|saving|you\s*save|discount|coupon|shipping|delivery|tax\b|gst|fee\b/i;
var OFFER_WORDS = /(bank|card|upi|wallet)\s*offer|instant\s*discount|cash\s*back|%\s*(instant\s*)?(off|discount)|flat\s*₹|₹\s*[\d,]+\s*off/i;
function isVisible(el) {
  if (!el || !el.ownerDocument) return false;
  const win = el.ownerDocument.defaultView;
  for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
    if (n.hidden) return false;
    const cs = win.getComputedStyle(n);
    if (cs.display === "none" || cs.visibility === "hidden") return false;
  }
  return true;
}
function labelText(input) {
  const doc = input.ownerDocument;
  const parts = [];
  if (input.id) {
    const esc = doc.defaultView?.CSS?.escape;
    const l = doc.querySelector(`label[for="${esc ? esc(input.id) : input.id.replace(/"/g, "")}"]`);
    if (l) parts.push(l.textContent);
  }
  const wrap = input.closest("label");
  if (wrap) parts.push(wrap.textContent);
  return parts.join(" ");
}
function inputSignals(input) {
  return [
    input.name,
    input.id,
    input.placeholder,
    input.getAttribute("aria-label"),
    input.getAttribute("data-testid"),
    input.title,
    input.getAttribute("autocomplete"),
    labelText(input)
  ].filter(Boolean).join(" ");
}
function scorePromoInput(input) {
  const type = (input.getAttribute("type") || "text").toLowerCase();
  if (BAD_TYPES.has(type)) return -10;
  const s = inputSignals(input);
  let score = 0;
  if (PROMO_WORDS.test(s)) score += 3;
  if (WEAK_WORDS.test(s)) score += 1;
  if (NEGATIVE.test(s)) score -= 5;
  return score;
}
function findPromoField(doc) {
  let best = null;
  for (const input of doc.querySelectorAll("input")) {
    if (!isVisible(input)) continue;
    const score = scorePromoInput(input);
    if (score >= 3 && (!best || score > best.score)) best = { input, score };
  }
  if (!best) return null;
  return { input: best.input, button: findApplyButton(best.input) };
}
function findApplyButton(input) {
  const sel = "button, input[type=submit], input[type=button], [role=button]";
  let scope = input.parentElement;
  for (let depth = 0; scope && depth < 5; depth++, scope = scope.parentElement) {
    const buttons = [...scope.querySelectorAll(sel)].filter((b) => b !== input && isVisible(b));
    const text = (b) => `${b.textContent || ""} ${b.value || ""} ${b.getAttribute("aria-label") || ""}`.trim();
    const strong = buttons.find((b) => STRONG_APPLY.test(text(b)));
    if (strong) return strong;
    const weak = buttons.find((b) => APPLY_WORDS.test(text(b)) && !/remove|clear|cancel/i.test(text(b)));
    if (weak) return weak;
    if (scope.tagName === "FORM") break;
  }
  return null;
}
function findPromoToggle(doc) {
  const els = doc.querySelectorAll("button, a, summary, [role=button], [aria-expanded]");
  for (const el of els) {
    if (!isVisible(el)) continue;
    const t = (el.textContent || "").replace(/\s+/g, " ").trim();
    if (t.length < 80 && TOGGLE_WORDS.test(t)) return el;
  }
  return null;
}
function readTotalPaise(doc, { selectors = [] } = {}) {
  for (const sel of selectors) {
    let el = null;
    try {
      el = doc.querySelector(sel);
    } catch {
    }
    if (el && isVisible(el)) {
      const amounts = findRupeeAmounts(el.textContent);
      if (amounts.length) return amounts[amounts.length - 1];
    }
  }
  let best = null;
  for (const el of doc.body.querySelectorAll("tr, li, div, p, span, dd, dl, section")) {
    const text = (el.textContent || "").replace(/\s+/g, " ").trim();
    if (text.length > 140 || !TOTAL_LABEL.test(text)) continue;
    const core = text.replace(/\([^)]*\)/g, " ").replace(/incl(?:uding|usive|\.)?\s*(?:of\s*)?(?:all\s*)?(?:taxes|tax|gst)?/gi, " ");
    if (NOT_TOTAL.test(core.replace(TOTAL_LABEL, " "))) continue;
    if (!isVisible(el)) continue;
    const amounts = findRupeeAmounts(text);
    if (!amounts.length) continue;
    if (!best || text.length <= best.len) best = { len: text.length, value: amounts[amounts.length - 1] };
  }
  return best ? best.value : null;
}
function readOfferTexts(root, limit = 8) {
  const scope = root.body || root;
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const el of scope.querySelectorAll("p, li, div, span, label")) {
    const t = (el.textContent || "").replace(/\s+/g, " ").trim();
    if (t.length < 20 || t.length > 260 || !OFFER_WORDS.test(t) || seen.has(t)) continue;
    if ([...el.children].some((c) => OFFER_WORDS.test(c.textContent || ""))) continue;
    if (!isVisible(el)) continue;
    seen.add(t);
    out.push(t);
    if (out.length >= limit) break;
  }
  return out;
}

// src/adapters/index.js
function firstVisible(doc, selectors) {
  for (const s of selectors) {
    if (!s) continue;
    try {
      const el = doc.querySelector(s);
      if (el && isVisible(el)) return el;
    } catch {
    }
  }
  return null;
}
function makeAdapter({ id, hostRe, checkoutRe = null, totalSelectors = [], inputSelectors = [], buttonSelectors = [], unverified = false }) {
  return {
    id,
    unverified,
    matches: (host) => hostRe.test(host),
    /** True when the URL looks like a cart/checkout/payment step. The generic adapter always says yes (the user clicked). */
    isCheckout: (loc) => checkoutRe ? checkoutRe.test(`${loc.pathname}${loc.search}`) : true,
    findField(doc, overrides = {}) {
      const input = firstVisible(doc, [overrides.input, ...inputSelectors]);
      if (!input) return findPromoField(doc);
      const button = firstVisible(doc, [overrides.button, ...buttonSelectors]) ?? findApplyButton(input);
      return { input, button };
    },
    readTotal: (doc, overrides = {}) => readTotalPaise(doc, { selectors: [overrides.total, ...totalSelectors].filter(Boolean) }),
    readOffers: (doc) => readOfferTexts(doc),
    findToggle: (doc) => findPromoToggle(doc)
  };
}
var generic = makeAdapter({ id: "generic", hostRe: /./ });
var amazon = makeAdapter({
  id: "amazon",
  hostRe: /(^|\.)amazon\.(in|com)$/i,
  checkoutRe: /\/(gp\/buy|checkout|gp\/cart|cart)/i,
  inputSelectors: ['input[name="ppw-claimCode"]'],
  buttonSelectors: ['input[name="ppw-claimCodeApplyPressed"]'],
  unverified: true
});
var flipkart = makeAdapter({
  id: "flipkart",
  hostRe: /(^|\.)flipkart\.com$/i,
  checkoutRe: /(checkout|viewcart|payments)/i,
  unverified: true
});
function normalizeHost(hostname) {
  return String(hostname || "").toLowerCase().replace(/^www\./, "");
}

// src/i18n/en.json
var en_default = {
  appName: "Promo-Flow",
  tagline: "Finds the best coupon and bank offer at checkout",
  find: "Find best savings",
  stop: "Stop",
  language: "Language",
  yourCodes: "My coupon codes",
  yourCodesHint: "One code per line. Only codes you already have.",
  addCode: "Save",
  telemetry: "Share anonymous results",
  telemetryHint: "Sends only: store, code, worked or not. No personal data.",
  apiBase: "Server address",
  working: "Working\u2026",
  trying: "Trying {code} ({n}/{total})",
  noField: "Couldn't find a promo-code box on this page. Open the payment/checkout step and try again.",
  captcha: "The site is asking for a verification check. Stopped so you can finish it yourself.",
  noTotal: "Couldn't read the payable total on this page.",
  noCodes: "No codes to try for this store. Add your own codes in the popup.",
  done: "Done",
  before: "Before",
  after: "After",
  youSave: "You save",
  bankOffer: "Bank/payment offer",
  bankHint: "Estimated from the offer text. Pay with that card/method to get it; not applied by Promo-Flow.",
  couponApplied: "Coupon applied",
  noneWorked: "No code worked on this cart.",
  estimate: "Estimate",
  close: "Close",
  stopped: "Stopped.",
  unverifiedSite: "This site's support is experimental. Check the final total before paying.",
  notCheckout: "Open the cart or payment page first.",
  capReached: "Stopped after the maximum number of tries.",
  diagnoseTitle: "Diagnose this page",
  diagnoseState: "Page state",
  stateBag: "Bag / cart",
  stateCouponPanelOpen: "Coupon panel open",
  stateCouponApplied: "Coupon applied",
  stateCouponError: "Coupon error",
  statePayment: "Payment page",
  diagnoseCopy: "Copy snapshot",
  diagnoseDownload: "Download",
  diagnoseNotice: "The snapshot is copied on this device and sent nowhere.",
  diagnoseCopied: "Copied.",
  diagnoseFailed: "Could not capture this page.",
  loginRequired: "This site needs you to log in before coupons can be applied. Log in, then try again.",
  rateLimited: "The site is limiting coupon attempts. Stopped to avoid problems; try again later.",
  originUser: "From your own codes",
  originListed: "Listed by the site for your cart",
  originShared: "From the shared list",
  skippedIneligible: "Skipped, the site says not applicable: {codes}",
  couponNotApplied: "The best coupon ({code}) is not applied right now. Enter it yourself to get this saving.",
  preAppliedLost: "A coupon that was already applied was removed during the search. Re-apply it if you still want it.",
  couldNotRestore: "Could not remove the last coupon tried. Check your cart total before paying.",
  noOffers: "No instant bank offers found on this page.",
  payHint: "Next: open the payment page and click Promo-Flow again to see the best bank offer.",
  totalOnPage: "Total on this page",
  tryMore: "Try {n} more",
  tryMoreWait: "Try more in {s}s",
  srcYours: "yours",
  srcSite: "site",
  srcShared: "shared",
  srcFeed: "feed",
  srcDataset: "old list",
  srcKnown: "known",
  ageToday: "today",
  ageDays: "{d}d ago",
  skippedMinSpend: "Skipped, needs a bigger cart: {codes}",
  sharePrompt: "{code} worked. Share it with other Promo-Flow users? Only the store and the code are sent.",
  shareYes: "Share",
  shareNo: "No",
  shareAlways: "Always share",
  sharedThanks: "Shared. Thank you.",
  shareModeL: "Sharing codes that worked for me",
  shareAsk: "Ask each time",
  shareAlwaysOpt: "Always",
  shareNever: "Never"
};

// src/i18n/hi.json
var hi_default = {
  appName: "Promo-Flow",
  tagline: "\u091A\u0947\u0915\u0906\u0909\u091F \u092A\u0930 \u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u093E \u0915\u0942\u092A\u0928 \u0914\u0930 \u092C\u0948\u0902\u0915 \u0911\u092B\u093C\u0930 \u0916\u094B\u091C\u0924\u093E \u0939\u0948",
  find: "\u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u0940 \u092C\u091A\u0924 \u0916\u094B\u091C\u0947\u0902",
  stop: "\u0930\u094B\u0915\u0947\u0902",
  language: "\u092D\u093E\u0937\u093E",
  yourCodes: "\u092E\u0947\u0930\u0947 \u0915\u0942\u092A\u0928 \u0915\u094B\u0921",
  yourCodesHint: "\u0939\u0930 \u092A\u0902\u0915\u094D\u0924\u093F \u092E\u0947\u0902 \u090F\u0915 \u0915\u094B\u0921\u0964 \u0915\u0947\u0935\u0932 \u0935\u0939\u0940 \u0915\u094B\u0921 \u091C\u094B \u0906\u092A\u0915\u0947 \u092A\u093E\u0938 \u092A\u0939\u0932\u0947 \u0938\u0947 \u0939\u0948\u0902\u0964",
  addCode: "\u0938\u0939\u0947\u091C\u0947\u0902",
  telemetry: "\u0917\u0941\u092E\u0928\u093E\u092E \u092A\u0930\u093F\u0923\u093E\u092E \u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902",
  telemetryHint: "\u0915\u0947\u0935\u0932 \u092D\u0947\u091C\u093E \u091C\u093E\u0924\u093E \u0939\u0948: \u0938\u094D\u091F\u094B\u0930, \u0915\u094B\u0921, \u091A\u0932\u093E \u092F\u093E \u0928\u0939\u0940\u0902\u0964 \u0915\u094B\u0908 \u0928\u093F\u091C\u0940 \u0921\u0947\u091F\u093E \u0928\u0939\u0940\u0902\u0964",
  apiBase: "\u0938\u0930\u094D\u0935\u0930 \u0915\u093E \u092A\u0924\u093E",
  working: "\u0915\u093E\u092E \u091A\u0932 \u0930\u0939\u093E \u0939\u0948\u2026",
  trying: "{code} \u0906\u091C\u093C\u092E\u093E\u092F\u093E \u091C\u093E \u0930\u0939\u093E \u0939\u0948 ({n}/{total})",
  noField: "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u092A\u094D\u0930\u094B\u092E\u094B-\u0915\u094B\u0921 \u092C\u0949\u0915\u094D\u0938 \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u093E\u0964 \u092A\u0947\u092E\u0947\u0902\u091F/\u091A\u0947\u0915\u0906\u0909\u091F \u091A\u0930\u0923 \u0916\u094B\u0932\u0915\u0930 \u092B\u093F\u0930 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
  captcha: "\u0938\u093E\u0907\u091F \u0938\u0924\u094D\u092F\u093E\u092A\u0928 \u092E\u093E\u0901\u0917 \u0930\u0939\u0940 \u0939\u0948\u0964 \u0906\u092A \u0916\u0941\u0926 \u092A\u0942\u0930\u093E \u0915\u0930 \u0938\u0915\u0947\u0902, \u0907\u0938\u0932\u093F\u090F \u0930\u094B\u0915 \u0926\u093F\u092F\u093E \u0917\u092F\u093E\u0964",
  noTotal: "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u0926\u0947\u092F \u0915\u0941\u0932 \u0930\u093E\u0936\u093F \u092A\u0922\u093C \u0928\u0939\u0940\u0902 \u0938\u0915\u0947\u0964",
  noCodes: "\u0907\u0938 \u0938\u094D\u091F\u094B\u0930 \u0915\u0947 \u0932\u093F\u090F \u0906\u091C\u093C\u092E\u093E\u0928\u0947 \u0915\u094B \u0915\u094B\u0908 \u0915\u094B\u0921 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964 \u092A\u0949\u092A\u0905\u092A \u092E\u0947\u0902 \u0905\u092A\u0928\u0947 \u0915\u094B\u0921 \u091C\u094B\u0921\u093C\u0947\u0902\u0964",
  done: "\u092A\u0942\u0930\u093E \u0939\u0941\u0906",
  before: "\u092A\u0939\u0932\u0947",
  after: "\u092C\u093E\u0926 \u092E\u0947\u0902",
  youSave: "\u0906\u092A\u0915\u0940 \u092C\u091A\u0924",
  bankOffer: "\u092C\u0948\u0902\u0915/\u092A\u0947\u092E\u0947\u0902\u091F \u0911\u092B\u093C\u0930",
  bankHint: "\u0911\u092B\u093C\u0930 \u0915\u0947 \u091F\u0947\u0915\u094D\u0938\u094D\u091F \u0938\u0947 \u0905\u0928\u0941\u092E\u093E\u0928\u093F\u0924\u0964 \u0909\u0938 \u0915\u093E\u0930\u094D\u0921/\u0924\u0930\u0940\u0915\u0947 \u0938\u0947 \u092D\u0941\u0917\u0924\u093E\u0928 \u0915\u0930\u0928\u0947 \u092A\u0930 \u092E\u093F\u0932\u0947\u0917\u093E; Promo-Flow \u0907\u0938\u0947 \u0932\u093E\u0917\u0942 \u0928\u0939\u0940\u0902 \u0915\u0930\u0924\u093E\u0964",
  couponApplied: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942 \u0939\u0941\u0906",
  noneWorked: "\u0907\u0938 \u0915\u093E\u0930\u094D\u091F \u092A\u0930 \u0915\u094B\u0908 \u0915\u094B\u0921 \u0928\u0939\u0940\u0902 \u091A\u0932\u093E\u0964",
  estimate: "\u0905\u0928\u0941\u092E\u093E\u0928",
  close: "\u092C\u0902\u0926 \u0915\u0930\u0947\u0902",
  stopped: "\u0930\u094B\u0915 \u0926\u093F\u092F\u093E \u0917\u092F\u093E\u0964",
  unverifiedSite: "\u0907\u0938 \u0938\u093E\u0907\u091F \u0915\u093E \u0938\u092E\u0930\u094D\u0925\u0928 \u092A\u094D\u0930\u093E\u092F\u094B\u0917\u093F\u0915 \u0939\u0948\u0964 \u092D\u0941\u0917\u0924\u093E\u0928 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0905\u0902\u0924\u093F\u092E \u0930\u093E\u0936\u093F \u091C\u093E\u0901\u091A \u0932\u0947\u0902\u0964",
  notCheckout: "\u092A\u0939\u0932\u0947 \u0915\u093E\u0930\u094D\u091F \u092F\u093E \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u0947\u091C \u0916\u094B\u0932\u0947\u0902\u0964",
  capReached: "\u0905\u0927\u093F\u0915\u0924\u092E \u0915\u094B\u0936\u093F\u0936\u094B\u0902 \u0915\u0947 \u092C\u093E\u0926 \u0930\u0941\u0915 \u0917\u092F\u093E\u0964",
  diagnoseTitle: "\u0907\u0938 \u092A\u0947\u091C \u0915\u0940 \u091C\u093E\u0901\u091A",
  diagnoseState: "\u092A\u0947\u091C \u0915\u0940 \u0938\u094D\u0925\u093F\u0924\u093F",
  stateBag: "\u092C\u0948\u0917 / \u0915\u093E\u0930\u094D\u091F",
  stateCouponPanelOpen: "\u0915\u0942\u092A\u0928 \u092A\u0948\u0928\u0932 \u0916\u0941\u0932\u093E",
  stateCouponApplied: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942",
  stateCouponError: "\u0915\u0942\u092A\u0928 \u092E\u0947\u0902 \u0924\u094D\u0930\u0941\u091F\u093F",
  statePayment: "\u092A\u0947\u092E\u0947\u0902\u091F \u092A\u0947\u091C",
  diagnoseCopy: "\u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902",
  diagnoseDownload: "\u0921\u093E\u0909\u0928\u0932\u094B\u0921",
  diagnoseNotice: "\u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F \u0907\u0938\u0940 \u0921\u093F\u0935\u093E\u0907\u0938 \u092A\u0930 \u0915\u0949\u092A\u0940 \u0939\u094B\u0924\u093E \u0939\u0948, \u0915\u0939\u0940\u0902 \u092D\u0947\u091C\u093E \u0928\u0939\u0940\u0902 \u091C\u093E\u0924\u093E\u0964",
  diagnoseCopied: "\u0915\u0949\u092A\u0940 \u0939\u094B \u0917\u092F\u093E\u0964",
  diagnoseFailed: "\u0907\u0938 \u092A\u0947\u091C \u0915\u093E \u0938\u094D\u0928\u0948\u092A\u0936\u0949\u091F \u0928\u0939\u0940\u0902 \u0932\u093F\u092F\u093E \u091C\u093E \u0938\u0915\u093E\u0964",
  loginRequired: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942 \u0915\u0930\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0907\u0938 \u0938\u093E\u0907\u091F \u092A\u0930 \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u0928\u093E \u0939\u094B\u0917\u093E\u0964 \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u0915\u0947 \u092B\u093F\u0930 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
  rateLimited: "\u0938\u093E\u0907\u091F \u0915\u0942\u092A\u0928 \u0915\u0940 \u0915\u094B\u0936\u093F\u0936\u0947\u0902 \u0938\u0940\u092E\u093F\u0924 \u0915\u0930 \u0930\u0939\u0940 \u0939\u0948\u0964 \u092A\u0930\u0947\u0936\u093E\u0928\u0940 \u0938\u0947 \u092C\u091A\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0930\u094B\u0915 \u0926\u093F\u092F\u093E \u0917\u092F\u093E; \u092C\u093E\u0926 \u092E\u0947\u0902 \u092B\u093F\u0930 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
  originUser: "\u0906\u092A\u0915\u0947 \u0905\u092A\u0928\u0947 \u0915\u094B\u0921 \u0938\u0947",
  originListed: "\u0938\u093E\u0907\u091F \u0928\u0947 \u0906\u092A\u0915\u0947 \u0915\u093E\u0930\u094D\u091F \u0915\u0947 \u0932\u093F\u090F \u0938\u0941\u091D\u093E\u092F\u093E",
  originShared: "\u0938\u093E\u091D\u093E \u0938\u0942\u091A\u0940 \u0938\u0947",
  skippedIneligible: "\u091B\u094B\u0921\u093C \u0926\u093F\u090F \u0917\u090F, \u0938\u093E\u0907\u091F \u0915\u0947 \u0905\u0928\u0941\u0938\u093E\u0930 \u0932\u093E\u0917\u0942 \u0928\u0939\u0940\u0902: {codes}",
  couponNotApplied: "\u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u093E \u0915\u0942\u092A\u0928 ({code}) \u0905\u092D\u0940 \u0932\u093E\u0917\u0942 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964 \u092F\u0939 \u092C\u091A\u0924 \u092A\u093E\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0907\u0938\u0947 \u0916\u0941\u0926 \u0921\u093E\u0932\u0947\u0902\u0964",
  preAppliedLost: "\u092A\u0939\u0932\u0947 \u0938\u0947 \u0932\u093E\u0917\u0942 \u0915\u0942\u092A\u0928 \u0916\u094B\u091C \u0915\u0947 \u0926\u094C\u0930\u093E\u0928 \u0939\u091F\u093E \u0926\u093F\u092F\u093E \u0917\u092F\u093E\u0964 \u091A\u093E\u0939\u0947\u0902 \u0924\u094B \u0909\u0938\u0947 \u092B\u093F\u0930 \u0938\u0947 \u0932\u0917\u093E\u090F\u0901\u0964",
  couldNotRestore: "\u0906\u0916\u093C\u093F\u0930\u0940 \u0906\u091C\u093C\u092E\u093E\u092F\u093E \u0915\u0942\u092A\u0928 \u0939\u091F\u093E\u092F\u093E \u0928\u0939\u0940\u0902 \u091C\u093E \u0938\u0915\u093E\u0964 \u092D\u0941\u0917\u0924\u093E\u0928 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0915\u093E\u0930\u094D\u091F \u0915\u0940 \u0915\u0941\u0932 \u0930\u093E\u0936\u093F \u091C\u093E\u0901\u091A \u0932\u0947\u0902\u0964",
  noOffers: "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u0915\u094B\u0908 \u0924\u0941\u0930\u0902\u0924 \u092E\u093F\u0932\u0928\u0947 \u0935\u093E\u0932\u093E \u092C\u0948\u0902\u0915 \u0911\u092B\u093C\u0930 \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u093E\u0964",
  payHint: "\u0905\u0917\u0932\u093E \u0915\u0926\u092E: \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u0947\u091C \u0916\u094B\u0932\u0947\u0902 \u0914\u0930 \u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u093E \u092C\u0948\u0902\u0915 \u0911\u092B\u093C\u0930 \u0926\u0947\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F Promo-Flow \u092B\u093F\u0930 \u0938\u0947 \u0926\u092C\u093E\u090F\u0901\u0964",
  totalOnPage: "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u0915\u0941\u0932 \u0930\u093E\u0936\u093F",
  tryMore: "{n} \u0914\u0930 \u0906\u091C\u093C\u092E\u093E\u090F\u0901",
  tryMoreWait: "{s} \u0938\u0947\u0915\u0902\u0921 \u092E\u0947\u0902 \u0914\u0930 \u0906\u091C\u093C\u092E\u093E\u090F\u0901",
  srcYours: "\u0906\u092A\u0915\u093E",
  srcSite: "\u0938\u093E\u0907\u091F",
  srcShared: "\u0938\u093E\u091D\u093E",
  srcFeed: "\u092B\u093C\u0940\u0921",
  srcDataset: "\u092A\u0941\u0930\u093E\u0928\u0940 \u0938\u0942\u091A\u0940",
  srcKnown: "\u091C\u094D\u091E\u093E\u0924",
  ageToday: "\u0906\u091C",
  ageDays: "{d} \u0926\u093F\u0928 \u092A\u0939\u0932\u0947",
  skippedMinSpend: "\u091B\u094B\u0921\u093C\u093E \u0917\u092F\u093E, \u092C\u0921\u093C\u093E \u0915\u093E\u0930\u094D\u091F \u091A\u093E\u0939\u093F\u090F: {codes}",
  sharePrompt: "{code} \u091A\u0932 \u0917\u092F\u093E\u0964 \u0915\u094D\u092F\u093E \u0907\u0938\u0947 \u0926\u0942\u0938\u0930\u0947 Promo-Flow \u0909\u092A\u092F\u094B\u0917\u0915\u0930\u094D\u0924\u093E\u0913\u0902 \u0915\u0947 \u0938\u093E\u0925 \u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902? \u0915\u0947\u0935\u0932 \u0938\u094D\u091F\u094B\u0930 \u0914\u0930 \u0915\u094B\u0921 \u092D\u0947\u091C\u093E \u091C\u093E\u0924\u093E \u0939\u0948\u0964",
  shareYes: "\u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902",
  shareNo: "\u0928\u0939\u0940\u0902",
  shareAlways: "\u0939\u092E\u0947\u0936\u093E \u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902",
  sharedThanks: "\u0938\u093E\u091D\u093E \u0915\u093F\u092F\u093E \u0917\u092F\u093E\u0964 \u0927\u0928\u094D\u092F\u0935\u093E\u0926\u0964",
  shareModeL: "\u092E\u0947\u0930\u0947 \u0932\u093F\u090F \u091A\u0932\u0947 \u0915\u094B\u0921 \u0938\u093E\u091D\u093E \u0915\u0930\u0928\u093E",
  shareAsk: "\u0939\u0930 \u092C\u093E\u0930 \u092A\u0942\u091B\u0947\u0902",
  shareAlwaysOpt: "\u0939\u092E\u0947\u0936\u093E",
  shareNever: "\u0915\u092D\u0940 \u0928\u0939\u0940\u0902"
};

// src/i18n/mr.json
var mr_default = {
  appName: "Promo-Flow",
  tagline: "\u091A\u0947\u0915\u0906\u0909\u091F\u0935\u0930 \u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u0915\u0942\u092A\u0928 \u0906\u0923\u093F \u092C\u0901\u0915 \u0911\u092B\u0930 \u0936\u094B\u0927\u0924\u094B",
  find: "\u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u092C\u091A\u0924 \u0936\u094B\u0927\u093E",
  stop: "\u0925\u093E\u0902\u092C\u0935\u093E",
  language: "\u092D\u093E\u0937\u093E",
  yourCodes: "\u092E\u093E\u091D\u0947 \u0915\u0942\u092A\u0928 \u0915\u094B\u0921",
  yourCodesHint: "\u092A\u094D\u0930\u0924\u094D\u092F\u0947\u0915 \u0913\u0933\u0940\u0924 \u090F\u0915 \u0915\u094B\u0921. \u092B\u0915\u094D\u0924 \u0924\u0941\u092E\u091A\u094D\u092F\u093E\u0915\u0921\u0947 \u0906\u0927\u0940\u092A\u093E\u0938\u0942\u0928 \u0905\u0938\u0932\u0947\u0932\u0947 \u0915\u094B\u0921.",
  addCode: "\u091C\u0924\u0928 \u0915\u0930\u093E",
  telemetry: "\u0928\u093F\u0928\u093E\u0935\u0940 \u0928\u093F\u0915\u093E\u0932 \u0936\u0947\u0905\u0930 \u0915\u0930\u093E",
  telemetryHint: "\u092B\u0915\u094D\u0924 \u092A\u093E\u0920\u0935\u0932\u0947 \u091C\u093E\u0924\u0947: \u0938\u094D\u091F\u094B\u0905\u0930, \u0915\u094B\u0921, \u091A\u093E\u0932\u0932\u093E \u0915\u0940 \u0928\u093E\u0939\u0940. \u0935\u0948\u092F\u0915\u094D\u0924\u093F\u0915 \u092E\u093E\u0939\u093F\u0924\u0940 \u0928\u093E\u0939\u0940.",
  apiBase: "\u0938\u0930\u094D\u0935\u094D\u0939\u0930 \u092A\u0924\u094D\u0924\u093E",
  working: "\u0915\u093E\u092E \u0938\u0941\u0930\u0942 \u0906\u0939\u0947\u2026",
  trying: "{code} \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u093E\u0939\u0924 \u0906\u0939\u0947 ({n}/{total})",
  noField: "\u092F\u093E \u092A\u093E\u0928\u093E\u0935\u0930 \u092A\u094D\u0930\u094B\u092E\u094B-\u0915\u094B\u0921 \u092C\u0949\u0915\u094D\u0938 \u0938\u093E\u092A\u0921\u0932\u093E \u0928\u093E\u0939\u0940. \u092A\u0947\u092E\u0947\u0902\u091F/\u091A\u0947\u0915\u0906\u0909\u091F \u091F\u092A\u094D\u092A\u093E \u0909\u0918\u0921\u0942\u0928 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  captcha: "\u0938\u093E\u0907\u091F \u092A\u0921\u0924\u093E\u0933\u0923\u0940 \u092E\u093E\u0917\u0924 \u0906\u0939\u0947. \u0924\u0941\u092E\u094D\u0939\u0940 \u0938\u094D\u0935\u0924\u0903 \u092A\u0942\u0930\u094D\u0923 \u0915\u0930\u0942 \u0936\u0915\u093E\u0932 \u092E\u094D\u0939\u0923\u0942\u0928 \u0925\u093E\u0902\u092C\u0935\u0932\u0947.",
  noTotal: "\u092F\u093E \u092A\u093E\u0928\u093E\u0935\u0930 \u0926\u0947\u092F \u090F\u0915\u0942\u0923 \u0930\u0915\u094D\u0915\u092E \u0935\u093E\u091A\u0924\u093E \u0906\u0932\u0940 \u0928\u093E\u0939\u0940.",
  noCodes: "\u092F\u093E \u0938\u094D\u091F\u094B\u0905\u0930\u0938\u093E\u0920\u0940 \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u093E\u0939\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u0915\u094B\u0921 \u0928\u093E\u0939\u0940\u0924. \u092A\u0949\u092A\u0905\u092A\u092E\u0927\u094D\u092F\u0947 \u0938\u094D\u0935\u0924\u0903\u091A\u0947 \u0915\u094B\u0921 \u091C\u094B\u0921\u093E.",
  done: "\u092A\u0942\u0930\u094D\u0923 \u091D\u093E\u0932\u0947",
  before: "\u0906\u0927\u0940",
  after: "\u0928\u0902\u0924\u0930",
  youSave: "\u0924\u0941\u092E\u091A\u0940 \u092C\u091A\u0924",
  bankOffer: "\u092C\u0901\u0915/\u092A\u0947\u092E\u0947\u0902\u091F \u0911\u092B\u0930",
  bankHint: "\u0911\u092B\u0930\u091A\u094D\u092F\u093E \u092E\u091C\u0915\u0941\u0930\u093E\u0935\u0930\u0942\u0928 \u0905\u0902\u0926\u093E\u091C. \u0924\u094D\u092F\u093E \u0915\u093E\u0930\u094D\u0921/\u092A\u0926\u094D\u0927\u0924\u0940\u0928\u0947 \u092A\u0948\u0938\u0947 \u092D\u0930\u0932\u094D\u092F\u093E\u0935\u0930 \u092E\u093F\u0933\u0947\u0932; Promo-Flow \u0924\u0940 \u0932\u093E\u0917\u0942 \u0915\u0930\u0924 \u0928\u093E\u0939\u0940.",
  couponApplied: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942 \u091D\u093E\u0932\u0947",
  noneWorked: "\u092F\u093E \u0915\u093E\u0930\u094D\u091F\u0935\u0930 \u0915\u094B\u0923\u0924\u093E\u0939\u0940 \u0915\u094B\u0921 \u091A\u093E\u0932\u0932\u093E \u0928\u093E\u0939\u0940.",
  estimate: "\u0905\u0902\u0926\u093E\u091C",
  close: "\u092C\u0902\u0926 \u0915\u0930\u093E",
  stopped: "\u0925\u093E\u0902\u092C\u0935\u0932\u0947.",
  unverifiedSite: "\u092F\u093E \u0938\u093E\u0907\u091F\u091A\u093E \u0938\u092A\u094B\u0930\u094D\u091F \u092A\u094D\u0930\u093E\u092F\u094B\u0917\u093F\u0915 \u0906\u0939\u0947. \u092A\u0948\u0938\u0947 \u092D\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u0905\u0902\u0924\u093F\u092E \u0930\u0915\u094D\u0915\u092E \u0924\u092A\u093E\u0938\u093E.",
  notCheckout: "\u0906\u0927\u0940 \u0915\u093E\u0930\u094D\u091F \u0915\u093F\u0902\u0935\u093E \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u093E\u0928 \u0909\u0918\u0921\u093E.",
  capReached: "\u0915\u092E\u093E\u0932 \u092A\u094D\u0930\u092F\u0924\u094D\u0928\u093E\u0902\u0928\u0902\u0924\u0930 \u0925\u093E\u0902\u092C\u0932\u0947.",
  diagnoseTitle: "\u0939\u0947 \u092A\u093E\u0928 \u0924\u092A\u093E\u0938\u093E",
  diagnoseState: "\u092A\u093E\u0928\u093E\u091A\u0940 \u0938\u094D\u0925\u093F\u0924\u0940",
  stateBag: "\u092C\u0945\u0917 / \u0915\u093E\u0930\u094D\u091F",
  stateCouponPanelOpen: "\u0915\u0942\u092A\u0928 \u092A\u0945\u0928\u0932 \u0909\u0918\u0921\u0947",
  stateCouponApplied: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942",
  stateCouponError: "\u0915\u0942\u092A\u0928 \u0924\u094D\u0930\u0941\u091F\u0940",
  statePayment: "\u092A\u0947\u092E\u0947\u0902\u091F \u092A\u093E\u0928",
  diagnoseCopy: "\u0938\u094D\u0928\u0945\u092A\u0936\u0949\u091F \u0915\u0949\u092A\u0940 \u0915\u0930\u093E",
  diagnoseDownload: "\u0921\u093E\u0909\u0928\u0932\u094B\u0921",
  diagnoseNotice: "\u0938\u094D\u0928\u0945\u092A\u0936\u0949\u091F \u092F\u093E\u091A \u0921\u093F\u0935\u094D\u0939\u093E\u0907\u0938\u0935\u0930 \u0915\u0949\u092A\u0940 \u0939\u094B\u0924\u094B, \u0915\u0941\u0920\u0947\u0939\u0940 \u092A\u093E\u0920\u0935\u0932\u093E \u091C\u093E\u0924 \u0928\u093E\u0939\u0940.",
  diagnoseCopied: "\u0915\u0949\u092A\u0940 \u091D\u093E\u0932\u0947.",
  diagnoseFailed: "\u0939\u0947 \u092A\u093E\u0928 \u0915\u0945\u092A\u094D\u091A\u0930 \u0915\u0930\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940.",
  loginRequired: "\u0915\u0942\u092A\u0928 \u0932\u093E\u0917\u0942 \u0915\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u092F\u093E \u0938\u093E\u0907\u091F\u0935\u0930 \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u093E\u0935\u0947 \u0932\u093E\u0917\u0947\u0932. \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u0942\u0928 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  rateLimited: "\u0938\u093E\u0907\u091F \u0915\u0942\u092A\u0928 \u092A\u094D\u0930\u092F\u0924\u094D\u0928\u093E\u0902\u0935\u0930 \u092E\u0930\u094D\u092F\u093E\u0926\u093E \u0918\u093E\u0932\u0924 \u0906\u0939\u0947. \u0905\u0921\u091A\u0923 \u091F\u093E\u0933\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u0925\u093E\u0902\u092C\u0935\u0932\u0947; \u0928\u0902\u0924\u0930 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  originUser: "\u0924\u0941\u092E\u091A\u094D\u092F\u093E \u0938\u094D\u0935\u0924\u0903\u091A\u094D\u092F\u093E \u0915\u094B\u0921\u092E\u0927\u0942\u0928",
  originListed: "\u0938\u093E\u0907\u091F\u0928\u0947 \u0924\u0941\u092E\u091A\u094D\u092F\u093E \u0915\u093E\u0930\u094D\u091F\u0938\u093E\u0920\u0940 \u0926\u093E\u0916\u0935\u0932\u0947\u0932\u0947",
  originShared: "\u0936\u0947\u0905\u0930 \u0915\u0947\u0932\u0947\u0932\u094D\u092F\u093E \u092F\u093E\u0926\u0940\u0924\u0942\u0928",
  skippedIneligible: "\u0935\u0917\u0933\u0932\u0947, \u0938\u093E\u0907\u091F\u0928\u0941\u0938\u093E\u0930 \u0932\u093E\u0917\u0942 \u0928\u093E\u0939\u0940\u0924: {codes}",
  couponNotApplied: "\u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u0915\u0942\u092A\u0928 ({code}) \u0938\u0927\u094D\u092F\u093E \u0932\u093E\u0917\u0942 \u0928\u093E\u0939\u0940. \u0939\u0940 \u092C\u091A\u0924 \u092E\u093F\u0933\u0935\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u0924\u0947 \u0938\u094D\u0935\u0924\u0903 \u091F\u093E\u0915\u093E.",
  preAppliedLost: "\u0906\u0927\u0940\u092A\u093E\u0938\u0942\u0928 \u0932\u093E\u0917\u0942 \u0905\u0938\u0932\u0947\u0932\u0947 \u0915\u0942\u092A\u0928 \u0936\u094B\u0927\u093E\u0926\u0930\u092E\u094D\u092F\u093E\u0928 \u0915\u093E\u0922\u0932\u0947 \u0917\u0947\u0932\u0947. \u0939\u0935\u0947 \u0905\u0938\u0932\u094D\u092F\u093E\u0938 \u092A\u0941\u0928\u094D\u0939\u093E \u0932\u093E\u0935\u093E.",
  couldNotRestore: "\u0936\u0947\u0935\u091F\u091A\u0947 \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u093E\u0939\u093F\u0932\u0947\u0932\u0947 \u0915\u0942\u092A\u0928 \u0915\u093E\u0922\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940. \u092A\u0948\u0938\u0947 \u092D\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u0915\u093E\u0930\u094D\u091F\u091A\u0940 \u090F\u0915\u0942\u0923 \u0930\u0915\u094D\u0915\u092E \u0924\u092A\u093E\u0938\u093E.",
  noOffers: "\u092F\u093E \u092A\u093E\u0928\u093E\u0935\u0930 \u0924\u093E\u0924\u094D\u0915\u093E\u0933 \u092E\u093F\u0933\u0923\u093E\u0930\u0940 \u092C\u0901\u0915 \u0911\u092B\u0930 \u0938\u093E\u092A\u0921\u0932\u0940 \u0928\u093E\u0939\u0940.",
  payHint: "\u092A\u0941\u0922\u0940\u0932 \u092A\u093E\u092F\u0930\u0940: \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u093E\u0928 \u0909\u0918\u0921\u093E \u0906\u0923\u093F \u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u092C\u0901\u0915 \u0911\u092B\u0930 \u092A\u093E\u0939\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 Promo-Flow \u092A\u0941\u0928\u094D\u0939\u093E \u0926\u093E\u092C\u093E.",
  totalOnPage: "\u092F\u093E \u092A\u093E\u0928\u093E\u0935\u0930\u0940\u0932 \u090F\u0915\u0942\u0923 \u0930\u0915\u094D\u0915\u092E",
  tryMore: "\u0906\u0923\u0916\u0940 {n} \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u0939\u093E",
  tryMoreWait: "{s} \u0938\u0947\u0915\u0902\u0926\u093E\u0902\u0924 \u0906\u0923\u0916\u0940 \u0935\u093E\u092A\u0930\u0942\u0928 \u092A\u0939\u093E",
  srcYours: "\u0924\u0941\u092E\u091A\u093E",
  srcSite: "\u0938\u093E\u0907\u091F",
  srcShared: "\u0936\u0947\u0905\u0930 \u0915\u0947\u0932\u0947\u0932\u093E",
  srcFeed: "\u092B\u0940\u0921",
  srcDataset: "\u091C\u0941\u0928\u0940 \u092F\u093E\u0926\u0940",
  srcKnown: "\u091C\u094D\u091E\u093E\u0924",
  ageToday: "\u0906\u091C",
  ageDays: "{d} \u0926\u093F\u0935\u0938\u093E\u0902\u092A\u0942\u0930\u094D\u0935\u0940",
  skippedMinSpend: "\u0935\u0917\u0933\u0932\u0947, \u092E\u094B\u0920\u093E \u0915\u093E\u0930\u094D\u091F \u0939\u0935\u093E: {codes}",
  sharePrompt: "{code} \u091A\u093E\u0932\u0932\u093E. \u0907\u0924\u0930 Promo-Flow \u0935\u093E\u092A\u0930\u0915\u0930\u094D\u0924\u094D\u092F\u093E\u0902\u0938\u094B\u092C\u0924 \u0936\u0947\u0905\u0930 \u0915\u0930\u093E\u092F\u091A\u093E? \u092B\u0915\u094D\u0924 \u0938\u094D\u091F\u094B\u0905\u0930 \u0906\u0923\u093F \u0915\u094B\u0921 \u092A\u093E\u0920\u0935\u0932\u093E \u091C\u093E\u0924\u094B.",
  shareYes: "\u0936\u0947\u0905\u0930 \u0915\u0930\u093E",
  shareNo: "\u0928\u093E\u0939\u0940",
  shareAlways: "\u0928\u0947\u0939\u092E\u0940 \u0936\u0947\u0905\u0930 \u0915\u0930\u093E",
  sharedThanks: "\u0936\u0947\u0905\u0930 \u0915\u0947\u0932\u0947. \u0927\u0928\u094D\u092F\u0935\u093E\u0926.",
  shareModeL: "\u092E\u093E\u091D\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u091A\u093E\u0932\u0932\u0947\u0932\u0947 \u0915\u094B\u0921 \u0936\u0947\u0905\u0930 \u0915\u0930\u0923\u0947",
  shareAsk: "\u092A\u094D\u0930\u0924\u094D\u092F\u0947\u0915 \u0935\u0947\u0933\u0940 \u0935\u093F\u091A\u093E\u0930\u093E",
  shareAlwaysOpt: "\u0928\u0947\u0939\u092E\u0940",
  shareNever: "\u0915\u0927\u0940\u091A \u0928\u093E\u0939\u0940"
};

// src/i18n/ta.json
var ta_default = {
  appName: "Promo-Flow",
  tagline: "\u0B9A\u0BC6\u0B95\u0BCD\u0B85\u0BB5\u0BC1\u0B9F\u0BCD\u0B9F\u0BBF\u0BB2\u0BCD \u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BB5\u0B99\u0BCD\u0B95\u0BBF \u0B9A\u0BB2\u0BC1\u0B95\u0BC8\u0BAF\u0BC8\u0B95\u0BCD \u0B95\u0BA3\u0BCD\u0B9F\u0BB1\u0BBF\u0BAF\u0BC1\u0BAE\u0BCD",
  find: "\u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0B9A\u0BC7\u0BAE\u0BBF\u0BAA\u0BCD\u0BAA\u0BC8\u0B95\u0BCD \u0B95\u0BA3\u0BCD\u0B9F\u0BC1\u0BAA\u0BBF\u0B9F\u0BBF",
  stop: "\u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1",
  language: "\u0BAE\u0BCA\u0BB4\u0BBF",
  yourCodes: "\u0B8E\u0BA9\u0BCD \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BCD",
  yourCodesHint: "\u0B92\u0BB0\u0BC1 \u0BB5\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC1 \u0B92\u0BB0\u0BC1 \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1. \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0B9F\u0BAE\u0BCD \u0B8F\u0BB1\u0BCD\u0B95\u0BA9\u0BB5\u0BC7 \u0B89\u0BB3\u0BCD\u0BB3\u0BB5\u0BC8 \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD.",
  addCode: "\u0B9A\u0BC7\u0BAE\u0BBF",
  telemetry: "\u0BAA\u0BC6\u0BAF\u0BB0\u0BBF\u0BB2\u0BCD\u0BB2\u0BBE \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0BC1\u0B95\u0BB3\u0BC8\u0BAA\u0BCD \u0BAA\u0B95\u0BBF\u0BB0\u0BCD",
  telemetryHint: "\u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BB5\u0BA4\u0BC1: \u0B95\u0B9F\u0BC8, \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1, \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BA4\u0BBE \u0B87\u0BB2\u0BCD\u0BB2\u0BC8\u0BAF\u0BBE. \u0BA4\u0BA9\u0BBF\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BA4\u0BB0\u0BB5\u0BC1 \u0B87\u0BB2\u0BCD\u0BB2\u0BC8.",
  apiBase: "\u0B9A\u0BB0\u0BCD\u0BB5\u0BB0\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
  working: "\u0BB5\u0BC7\u0BB2\u0BC8 \u0BA8\u0B9F\u0B95\u0BCD\u0B95\u0BBF\u0BB1\u0BA4\u0BC1\u2026",
  trying: "{code} \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1 ({n}/{total})",
  noField: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BAA\u0BCD\u0BB0\u0BCB\u0BAE\u0BCB \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BCD\u0B9F\u0BC1\u0BAA\u0BCD \u0BAA\u0BC6\u0B9F\u0BCD\u0B9F\u0BBF \u0B95\u0BBF\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAA\u0BA3\u0BAE\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BAE\u0BCD/\u0B9A\u0BC6\u0B95\u0BCD\u0B85\u0BB5\u0BC1\u0B9F\u0BCD \u0BAA\u0B9F\u0BBF\u0BAF\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BB5\u0BC1\u0BAE\u0BCD.",
  captcha: "\u0BA4\u0BB3\u0BAE\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BC1 \u0B95\u0BC7\u0B9F\u0BCD\u0B95\u0BBF\u0BB1\u0BA4\u0BC1. \u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BC7 \u0BAE\u0BC1\u0B9F\u0BBF\u0B95\u0BCD\u0B95 \u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  noTotal: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BBF\u0BAF \u0BAE\u0BCA\u0BA4\u0BCD\u0BA4\u0BA4\u0BCD\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0B9F\u0BBF\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8.",
  noCodes: "\u0B87\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BC1 \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95 \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAA\u0BBE\u0BAA\u0BCD\u0B85\u0BAA\u0BCD\u0BAA\u0BBF\u0BB2\u0BCD \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BC8\u0B9A\u0BCD \u0B9A\u0BC7\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  done: "\u0BAE\u0BC1\u0B9F\u0BBF\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1",
  before: "\u0BAE\u0BC1\u0BA9\u0BCD",
  after: "\u0BAA\u0BBF\u0BA9\u0BCD",
  youSave: "\u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BC7\u0BAE\u0BBF\u0BAA\u0BCD\u0BAA\u0BA4\u0BC1",
  bankOffer: "\u0BB5\u0B99\u0BCD\u0B95\u0BBF/\u0BAA\u0BC7\u0BAE\u0BC6\u0BA3\u0BCD\u0B9F\u0BCD \u0B9A\u0BB2\u0BC1\u0B95\u0BC8",
  bankHint: "\u0B9A\u0BB2\u0BC1\u0B95\u0BC8 \u0B89\u0BB0\u0BC8\u0BAF\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC0\u0B9F\u0BC1. \u0B85\u0BA8\u0BCD\u0BA4 \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BC1/\u0BAE\u0BC1\u0BB1\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BBE\u0BB2\u0BCD \u0B95\u0BBF\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD; Promo-Flow \u0B87\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BBE\u0BA4\u0BC1.",
  couponApplied: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
  noneWorked: "\u0B87\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BBF\u0BB2\u0BCD \u0B8E\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0BAE\u0BCD \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8.",
  estimate: "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC0\u0B9F\u0BC1",
  close: "\u0BAE\u0BC2\u0B9F\u0BC1",
  stopped: "\u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  unverifiedSite: "\u0B87\u0BA8\u0BCD\u0BA4\u0BA4\u0BCD \u0BA4\u0BB3\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BCD \u0B86\u0BA4\u0BB0\u0BB5\u0BC1 \u0B9A\u0BCB\u0BA4\u0BA9\u0BC8 \u0BA8\u0BBF\u0BB2\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1. \u0BAA\u0BA3\u0BAE\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD \u0B87\u0BB1\u0BC1\u0BA4\u0BBF\u0BA4\u0BCD \u0BA4\u0BCA\u0B95\u0BC8\u0BAF\u0BC8\u0B9A\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  notCheckout: "\u0BAE\u0BC1\u0BA4\u0BB2\u0BBF\u0BB2\u0BCD \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD \u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0BAA\u0BC7\u0BAE\u0BC6\u0BA3\u0BCD\u0B9F\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  capReached: "\u0B85\u0BA4\u0BBF\u0B95\u0BAA\u0B9F\u0BCD\u0B9A \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD \u0BAA\u0BBF\u0BB1\u0B95\u0BC1 \u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  diagnoseTitle: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0B9A\u0BCD \u0B9A\u0BCB\u0BA4\u0BBF",
  diagnoseState: "\u0BAA\u0B95\u0BCD\u0B95 \u0BA8\u0BBF\u0BB2\u0BC8",
  stateBag: "\u0BAA\u0BC8 / \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD",
  stateCouponPanelOpen: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAA\u0BB2\u0B95\u0BAE\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1",
  stateCouponApplied: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
  stateCouponError: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAA\u0BBF\u0BB4\u0BC8",
  statePayment: "\u0BAA\u0BC7\u0BAE\u0BC6\u0BA3\u0BCD\u0B9F\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BAE\u0BCD",
  diagnoseCopy: "\u0BB8\u0BCD\u0BA9\u0BBE\u0BAA\u0BCD\u0BB7\u0BBE\u0B9F\u0BCD\u0B9F\u0BC8 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1",
  diagnoseDownload: "\u0BAA\u0BA4\u0BBF\u0BB5\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BC1",
  diagnoseNotice: "\u0BB8\u0BCD\u0BA9\u0BBE\u0BAA\u0BCD\u0BB7\u0BBE\u0B9F\u0BCD \u0B87\u0BA8\u0BCD\u0BA4\u0B9A\u0BCD \u0B9A\u0BBE\u0BA4\u0BA9\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BC7\u0BAF\u0BC7 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BAE\u0BCD; \u0B8E\u0B99\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BBE\u0BA4\u0BC1.",
  diagnoseCopied: "\u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  diagnoseFailed: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0BBF\u0B9F\u0BBF\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8.",
  loginRequired: "\u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD\u0B95\u0BB3\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4 \u0BAE\u0BC1\u0BA9\u0BCD \u0B87\u0BA8\u0BCD\u0BA4\u0BA4\u0BCD \u0BA4\u0BB3\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BA8\u0BC1\u0BB4\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD. \u0B89\u0BB3\u0BCD\u0BA8\u0BC1\u0BB4\u0BC8\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BB5\u0BC1\u0BAE\u0BCD.",
  rateLimited: "\u0BA4\u0BB3\u0BAE\u0BCD \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BC8\u0B95\u0BCD \u0B95\u0B9F\u0BCD\u0B9F\u0BC1\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1. \u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BB2\u0BC8\u0BA4\u0BCD \u0BA4\u0BB5\u0BBF\u0BB0\u0BCD\u0B95\u0BCD\u0B95 \u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1; \u0BAA\u0BBF\u0BB1\u0B95\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BB5\u0BC1\u0BAE\u0BCD.",
  originUser: "\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BCA\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1",
  originListed: "\u0BA4\u0BB3\u0BAE\u0BCD \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BBE\u0B95\u0BAA\u0BCD \u0BAA\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BB2\u0BBF\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
  originShared: "\u0BAA\u0B95\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BAA\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BB2\u0BBF\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1",
  skippedIneligible: "\u0BA4\u0BB5\u0BBF\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BB5\u0BC8, \u0BA4\u0BB3\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BCD\u0BAA\u0B9F\u0BBF \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBE\u0BA4\u0BC1: {codes}",
  couponNotApplied: "\u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD ({code}) \u0B87\u0BAA\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1 \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0B87\u0BA8\u0BCD\u0BA4\u0B9A\u0BCD \u0B9A\u0BC7\u0BAE\u0BBF\u0BAA\u0BCD\u0BAA\u0BC8\u0BAA\u0BCD \u0BAA\u0BC6\u0BB1 \u0B85\u0BA4\u0BC8 \u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BC7 \u0B89\u0BB3\u0BCD\u0BB3\u0BBF\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD.",
  preAppliedLost: "\u0B8F\u0BB1\u0BCD\u0B95\u0BA9\u0BB5\u0BC7 \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BCD \u0BA4\u0BC7\u0B9F\u0BB2\u0BBF\u0BA9\u0BCD \u0BAA\u0BCB\u0BA4\u0BC1 \u0BA8\u0BC0\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. \u0BA4\u0BC7\u0BB5\u0BC8\u0BAF\u0BC6\u0BA9\u0BBF\u0BB2\u0BCD \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
  couldNotRestore: "\u0B95\u0B9F\u0BC8\u0B9A\u0BBF\u0BAF\u0BBE\u0B95 \u0BAE\u0BC1\u0BAF\u0BA9\u0BCD\u0BB1 \u0B95\u0BC2\u0BAA\u0BCD\u0BAA\u0BA9\u0BC8 \u0BA8\u0BC0\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAA\u0BA3\u0BAE\u0BCD \u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD \u0BA4\u0BCA\u0B95\u0BC8\u0BAF\u0BC8\u0B9A\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  noOffers: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B89\u0B9F\u0BA9\u0B9F\u0BBF \u0BB5\u0B99\u0BCD\u0B95\u0BBF\u0B9A\u0BCD \u0B9A\u0BB2\u0BC1\u0B95\u0BC8\u0B95\u0BB3\u0BCD \u0B8E\u0BA4\u0BC1\u0BB5\u0BC1\u0BAE\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8.",
  payHint: "\u0B85\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BA4\u0BC1: \u0BAA\u0BC7\u0BAE\u0BC6\u0BA3\u0BCD\u0B9F\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1 \u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0BB5\u0B99\u0BCD\u0B95\u0BBF\u0B9A\u0BCD \u0B9A\u0BB2\u0BC1\u0B95\u0BC8\u0BAF\u0BC8\u0BAA\u0BCD \u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95 Promo-Flow-\u0B90 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
  totalOnPage: "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BAE\u0BCA\u0BA4\u0BCD\u0BA4\u0BA4\u0BCD \u0BA4\u0BCA\u0B95\u0BC8",
  tryMore: "\u0BAE\u0BC7\u0BB2\u0BC1\u0BAE\u0BCD {n} \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF \u0B9A\u0BC6\u0BAF\u0BCD",
  tryMoreWait: "{s} \u0BB5\u0BBF\u0BA8\u0BBE\u0B9F\u0BBF\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0BAE\u0BC7\u0BB2\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF",
  srcYours: "\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B9F\u0BC8\u0BAF\u0BA4\u0BC1",
  srcSite: "\u0BA4\u0BB3\u0BAE\u0BCD",
  srcShared: "\u0BAA\u0B95\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
  srcFeed: "\u0B83\u0BAA\u0BC0\u0B9F\u0BCD",
  srcDataset: "\u0BAA\u0BB4\u0BC8\u0BAF \u0BAA\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BB2\u0BCD",
  srcKnown: "\u0B85\u0BB1\u0BBF\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1",
  ageToday: "\u0B87\u0BA9\u0BCD\u0BB1\u0BC1",
  ageDays: "{d} \u0BA8\u0BBE\u0BB3\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD",
  skippedMinSpend: "\u0BA4\u0BB5\u0BBF\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1, \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD \u0BA4\u0BC7\u0BB5\u0BC8: {codes}",
  sharePrompt: "{code} \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BA4\u0BC1. \u0BAE\u0BB1\u0BCD\u0BB1 Promo-Flow \u0BAA\u0BAF\u0BA9\u0BB0\u0BCD\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0B95\u0BBF\u0BB0\u0BB5\u0BBE? \u0B95\u0B9F\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BC7 \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BAE\u0BCD.",
  shareYes: "\u0BAA\u0B95\u0BBF\u0BB0\u0BCD",
  shareNo: "\u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BBE\u0BAE\u0BCD",
  shareAlways: "\u0B8E\u0BAA\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1\u0BAE\u0BCD \u0BAA\u0B95\u0BBF\u0BB0\u0BCD",
  sharedThanks: "\u0BAA\u0B95\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. \u0BA8\u0BA9\u0BCD\u0BB1\u0BBF.",
  shareModeL: "\u0B8E\u0BA9\u0B95\u0BCD\u0B95\u0BC1 \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4 \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BC8\u0BAA\u0BCD \u0BAA\u0B95\u0BBF\u0BB0\u0BCD\u0BA4\u0BB2\u0BCD",
  shareAsk: "\u0B92\u0BB5\u0BCD\u0BB5\u0BCA\u0BB0\u0BC1 \u0BAE\u0BC1\u0BB1\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0B95\u0BC7\u0BB3\u0BCD",
  shareAlwaysOpt: "\u0B8E\u0BAA\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1\u0BAE\u0BCD",
  shareNever: "\u0B92\u0BB0\u0BC1\u0BAA\u0BCB\u0BA4\u0BC1\u0BAE\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8"
};

// src/i18n/te.json
var te_default = {
  appName: "Promo-Flow",
  tagline: "\u0C1A\u0C46\u0C15\u0C4D\u200C\u0C05\u0C35\u0C41\u0C1F\u0C4D\u200C\u0C32\u0C4B \u0C09\u0C24\u0C4D\u0C24\u0C2E \u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C2E\u0C30\u0C3F\u0C2F\u0C41 \u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D \u0C06\u0C2B\u0C30\u0C4D\u200C\u0C28\u0C41 \u0C15\u0C28\u0C41\u0C17\u0C4A\u0C02\u0C1F\u0C41\u0C02\u0C26\u0C3F",
  find: "\u0C09\u0C24\u0C4D\u0C24\u0C2E \u0C06\u0C26\u0C3E\u0C28\u0C41 \u0C15\u0C28\u0C41\u0C17\u0C4A\u0C28\u0C02\u0C21\u0C3F",
  stop: "\u0C06\u0C2A\u0C02\u0C21\u0C3F",
  language: "\u0C2D\u0C3E\u0C37",
  yourCodes: "\u0C28\u0C3E \u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32\u0C41",
  yourCodesHint: "\u0C2A\u0C4D\u0C30\u0C24\u0C3F \u0C32\u0C48\u0C28\u0C4D\u200C\u0C15\u0C41 \u0C12\u0C15 \u0C15\u0C4B\u0C21\u0C4D. \u0C2E\u0C40 \u0C26\u0C17\u0C4D\u0C17\u0C30 \u0C07\u0C2A\u0C4D\u0C2A\u0C1F\u0C3F\u0C15\u0C47 \u0C09\u0C28\u0C4D\u0C28\u0C35\u0C3F \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47.",
  addCode: "\u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  telemetry: "\u0C05\u0C1C\u0C4D\u0C1E\u0C3E\u0C24 \u0C2B\u0C32\u0C3F\u0C24\u0C3E\u0C32\u0C28\u0C41 \u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C02\u0C21\u0C3F",
  telemetryHint: "\u0C2A\u0C02\u0C2A\u0C47\u0C26\u0C3F: \u0C38\u0C4D\u0C1F\u0C4B\u0C30\u0C4D, \u0C15\u0C4B\u0C21\u0C4D, \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C38\u0C3F\u0C02\u0C26\u0C3E \u0C32\u0C47\u0C26\u0C3E. \u0C35\u0C4D\u0C2F\u0C15\u0C4D\u0C24\u0C3F\u0C17\u0C24 \u0C21\u0C47\u0C1F\u0C3E \u0C32\u0C47\u0C26\u0C41.",
  apiBase: "\u0C38\u0C30\u0C4D\u0C35\u0C30\u0C4D \u0C1A\u0C3F\u0C30\u0C41\u0C28\u0C3E\u0C2E\u0C3E",
  working: "\u0C2A\u0C28\u0C3F \u0C1C\u0C30\u0C41\u0C17\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F\u2026",
  trying: "{code} \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C38\u0C4D\u0C24\u0C4B\u0C02\u0C26\u0C3F ({n}/{total})",
  noField: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C2A\u0C4D\u0C30\u0C4B\u0C2E\u0C4B \u0C15\u0C4B\u0C21\u0C4D \u0C2C\u0C3E\u0C15\u0C4D\u0C38\u0C4D \u0C15\u0C28\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41. \u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D/\u0C1A\u0C46\u0C15\u0C4D\u200C\u0C05\u0C35\u0C41\u0C1F\u0C4D \u0C26\u0C36\u0C28\u0C41 \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  captcha: "\u0C38\u0C48\u0C1F\u0C4D \u0C27\u0C43\u0C35\u0C40\u0C15\u0C30\u0C23 \u0C05\u0C21\u0C41\u0C17\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F. \u0C2E\u0C40\u0C30\u0C47 \u0C2A\u0C42\u0C30\u0C4D\u0C24\u0C3F \u0C1A\u0C47\u0C2F\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C06\u0C2A\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F.",
  noTotal: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C3F\u0C02\u0C1A\u0C3E\u0C32\u0C4D\u0C38\u0C3F\u0C28 \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C1A\u0C26\u0C35\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C02.",
  noCodes: "\u0C08 \u0C38\u0C4D\u0C1F\u0C4B\u0C30\u0C4D\u200C\u0C15\u0C41 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32\u0C41 \u0C32\u0C47\u0C35\u0C41. \u0C2A\u0C3E\u0C2A\u0C2A\u0C4D\u200C\u0C32\u0C4B \u0C2E\u0C40 \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C1C\u0C4B\u0C21\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  done: "\u0C2A\u0C42\u0C30\u0C4D\u0C24\u0C2F\u0C3F\u0C02\u0C26\u0C3F",
  before: "\u0C2E\u0C41\u0C02\u0C26\u0C41",
  after: "\u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24",
  youSave: "\u0C2E\u0C40 \u0C06\u0C26\u0C3E",
  bankOffer: "\u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D/\u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C06\u0C2B\u0C30\u0C4D",
  bankHint: "\u0C06\u0C2B\u0C30\u0C4D \u0C1F\u0C46\u0C15\u0C4D\u0C38\u0C4D\u0C1F\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C05\u0C02\u0C1A\u0C28\u0C3E. \u0C06 \u0C15\u0C3E\u0C30\u0C4D\u0C21\u0C4D/\u0C2A\u0C26\u0C4D\u0C27\u0C24\u0C3F\u0C24\u0C4B \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C3F\u0C38\u0C4D\u0C24\u0C47 \u0C35\u0C38\u0C4D\u0C24\u0C41\u0C02\u0C26\u0C3F; Promo-Flow \u0C26\u0C40\u0C28\u0C4D\u0C28\u0C3F \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C26\u0C41.",
  couponApplied: "\u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F",
  noneWorked: "\u0C08 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D\u200C\u0C32\u0C4B \u0C0F \u0C15\u0C4B\u0C21\u0C4D \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C2F\u0C32\u0C47\u0C26\u0C41.",
  estimate: "\u0C05\u0C02\u0C1A\u0C28\u0C3E",
  close: "\u0C2E\u0C42\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  stopped: "\u0C06\u0C2A\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F.",
  unverifiedSite: "\u0C08 \u0C38\u0C48\u0C1F\u0C4D \u0C2E\u0C26\u0C4D\u0C26\u0C24\u0C41 \u0C2A\u0C4D\u0C30\u0C2F\u0C4B\u0C17\u0C3E\u0C24\u0C4D\u0C2E\u0C15\u0C02. \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C3F\u0C02\u0C1A\u0C47 \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C24\u0C41\u0C26\u0C3F \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  notCheckout: "\u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D \u0C32\u0C47\u0C26\u0C3E \u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C24\u0C46\u0C30\u0C35\u0C02\u0C21\u0C3F.",
  capReached: "\u0C17\u0C30\u0C3F\u0C37\u0C4D\u0C20 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3E\u0C32 \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 \u0C06\u0C17\u0C3F\u0C02\u0C26\u0C3F.",
  diagnoseTitle: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C2A\u0C30\u0C3F\u0C36\u0C40\u0C32\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F",
  diagnoseState: "\u0C2A\u0C47\u0C1C\u0C40 \u0C38\u0C4D\u0C25\u0C3F\u0C24\u0C3F",
  stateBag: "\u0C2C\u0C4D\u0C2F\u0C3E\u0C17\u0C4D / \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D",
  stateCouponPanelOpen: "\u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C2A\u0C4D\u0C2F\u0C3E\u0C28\u0C46\u0C32\u0C4D \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3F \u0C09\u0C02\u0C26\u0C3F",
  stateCouponApplied: "\u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F",
  stateCouponError: "\u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C32\u0C4B\u0C2A\u0C02",
  statePayment: "\u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C2A\u0C47\u0C1C\u0C40",
  diagnoseCopy: "\u0C38\u0C4D\u0C28\u0C3E\u0C2A\u0C4D\u200C\u0C37\u0C3E\u0C1F\u0C4D \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  diagnoseDownload: "\u0C21\u0C4C\u0C28\u0C4D\u200C\u0C32\u0C4B\u0C21\u0C4D",
  diagnoseNotice: "\u0C38\u0C4D\u0C28\u0C3E\u0C2A\u0C4D\u200C\u0C37\u0C3E\u0C1F\u0C4D \u0C08 \u0C2A\u0C30\u0C3F\u0C15\u0C30\u0C02\u0C32\u0C4B\u0C28\u0C47 \u0C15\u0C3E\u0C2A\u0C40 \u0C05\u0C35\u0C41\u0C24\u0C41\u0C02\u0C26\u0C3F; \u0C0E\u0C15\u0C4D\u0C15\u0C21\u0C3F\u0C15\u0C40 \u0C2A\u0C02\u0C2A\u0C2C\u0C21\u0C26\u0C41.",
  diagnoseCopied: "\u0C15\u0C3E\u0C2A\u0C40 \u0C05\u0C2F\u0C3F\u0C02\u0C26\u0C3F.",
  diagnoseFailed: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C15\u0C4D\u0C2F\u0C3E\u0C2A\u0C4D\u0C1A\u0C30\u0C4D \u0C1A\u0C47\u0C2F\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C02.",
  loginRequired: "\u0C15\u0C42\u0C2A\u0C28\u0C4D\u0C32\u0C41 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C08 \u0C38\u0C48\u0C1F\u0C4D\u200C\u0C32\u0C4B \u0C32\u0C3E\u0C17\u0C3F\u0C28\u0C4D \u0C15\u0C3E\u0C35\u0C3E\u0C32\u0C3F. \u0C32\u0C3E\u0C17\u0C3F\u0C28\u0C4D \u0C05\u0C2F\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  rateLimited: "\u0C38\u0C48\u0C1F\u0C4D \u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3E\u0C32\u0C28\u0C41 \u0C2A\u0C30\u0C3F\u0C2E\u0C3F\u0C24\u0C02 \u0C1A\u0C47\u0C38\u0C4D\u0C24\u0C4B\u0C02\u0C26\u0C3F. \u0C38\u0C2E\u0C38\u0C4D\u0C2F \u0C30\u0C3E\u0C15\u0C41\u0C02\u0C21\u0C3E \u0C06\u0C2A\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F; \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  originUser: "\u0C2E\u0C40 \u0C38\u0C4D\u0C35\u0C02\u0C24 \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32 \u0C28\u0C41\u0C02\u0C21\u0C3F",
  originListed: "\u0C38\u0C48\u0C1F\u0C4D \u0C2E\u0C40 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D \u0C15\u0C4B\u0C38\u0C02 \u0C1A\u0C42\u0C2A\u0C3F\u0C28\u0C26\u0C3F",
  originShared: "\u0C37\u0C47\u0C30\u0C4D \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C1C\u0C3E\u0C2C\u0C3F\u0C24\u0C3E \u0C28\u0C41\u0C02\u0C21\u0C3F",
  skippedIneligible: "\u0C26\u0C3E\u0C1F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F, \u0C38\u0C48\u0C1F\u0C4D \u0C2A\u0C4D\u0C30\u0C15\u0C3E\u0C30\u0C02 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C1A\u0C35\u0C41: {codes}",
  couponNotApplied: "\u0C09\u0C24\u0C4D\u0C24\u0C2E \u0C15\u0C42\u0C2A\u0C28\u0C4D ({code}) \u0C2A\u0C4D\u0C30\u0C38\u0C4D\u0C24\u0C41\u0C24\u0C02 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41. \u0C08 \u0C06\u0C26\u0C3E \u0C2A\u0C4A\u0C02\u0C26\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C26\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C2E\u0C40\u0C30\u0C47 \u0C28\u0C2E\u0C4B\u0C26\u0C41 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  preAppliedLost: "\u0C07\u0C02\u0C24\u0C15\u0C41 \u0C2E\u0C41\u0C02\u0C26\u0C47 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C38\u0C3F\u0C28 \u0C15\u0C42\u0C2A\u0C28\u0C4D \u0C36\u0C4B\u0C27\u0C28 \u0C38\u0C2E\u0C2F\u0C02\u0C32\u0C4B \u0C24\u0C40\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F. \u0C15\u0C3E\u0C35\u0C3E\u0C32\u0C02\u0C1F\u0C47 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C1C\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  couldNotRestore: "\u0C1A\u0C3F\u0C35\u0C30\u0C17\u0C3E \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C3F\u0C28 \u0C15\u0C42\u0C2A\u0C28\u0C4D\u200C\u0C28\u0C41 \u0C24\u0C40\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C02. \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C3F\u0C02\u0C1A\u0C47 \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  noOffers: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C24\u0C15\u0C4D\u0C37\u0C23 \u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D \u0C06\u0C2B\u0C30\u0C4D\u0C32\u0C41 \u0C15\u0C28\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41.",
  payHint: "\u0C24\u0C26\u0C41\u0C2A\u0C30\u0C3F: \u0C2A\u0C47\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3F \u0C09\u0C24\u0C4D\u0C24\u0C2E \u0C2C\u0C4D\u0C2F\u0C3E\u0C02\u0C15\u0C4D \u0C06\u0C2B\u0C30\u0C4D\u200C\u0C28\u0C41 \u0C1A\u0C42\u0C21\u0C1F\u0C3E\u0C28\u0C3F\u0C15\u0C3F Promo-Flow\u200C\u0C28\u0C41 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F.",
  totalOnPage: "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C02",
  tryMore: "\u0C2E\u0C30\u0C4B {n} \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F",
  tryMoreWait: "{s} \u0C38\u0C46\u0C15\u0C28\u0C4D\u0C32\u0C32\u0C4B \u0C2E\u0C30\u0C3F\u0C28\u0C4D\u0C28\u0C3F \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F",
  srcYours: "\u0C2E\u0C40\u0C26\u0C3F",
  srcSite: "\u0C38\u0C48\u0C1F\u0C4D",
  srcShared: "\u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C41\u0C28\u0C4D\u0C28\u0C26\u0C3F",
  srcFeed: "\u0C2B\u0C40\u0C21\u0C4D",
  srcDataset: "\u0C2A\u0C3E\u0C24 \u0C1C\u0C3E\u0C2C\u0C3F\u0C24\u0C3E",
  srcKnown: "\u0C24\u0C46\u0C32\u0C3F\u0C38\u0C3F\u0C28\u0C26\u0C3F",
  ageToday: "\u0C08\u0C30\u0C4B\u0C1C\u0C41",
  ageDays: "{d} \u0C30\u0C4B\u0C1C\u0C41\u0C32 \u0C15\u0C4D\u0C30\u0C3F\u0C24\u0C02",
  skippedMinSpend: "\u0C35\u0C26\u0C3F\u0C32\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F, \u0C2A\u0C46\u0C26\u0C4D\u0C26 \u0C15\u0C3E\u0C30\u0C4D\u0C1F\u0C4D \u0C15\u0C3E\u0C35\u0C3E\u0C32\u0C3F: {codes}",
  sharePrompt: "{code} \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C38\u0C3F\u0C02\u0C26\u0C3F. \u0C07\u0C24\u0C30 Promo-Flow \u0C35\u0C3F\u0C28\u0C3F\u0C2F\u0C4B\u0C17\u0C26\u0C3E\u0C30\u0C41\u0C32\u0C24\u0C4B \u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C35\u0C3E\u0C32\u0C3E? \u0C38\u0C4D\u0C1F\u0C4B\u0C30\u0C4D \u0C2E\u0C30\u0C3F\u0C2F\u0C41 \u0C15\u0C4B\u0C21\u0C4D \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C2A\u0C02\u0C2A\u0C2C\u0C21\u0C24\u0C3E\u0C2F\u0C3F.",
  shareYes: "\u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C02\u0C21\u0C3F",
  shareNo: "\u0C35\u0C26\u0C4D\u0C26\u0C41",
  shareAlways: "\u0C0E\u0C32\u0C4D\u0C32\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C42 \u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C02\u0C21\u0C3F",
  sharedThanks: "\u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F. \u0C27\u0C28\u0C4D\u0C2F\u0C35\u0C3E\u0C26\u0C3E\u0C32\u0C41.",
  shareModeL: "\u0C28\u0C3E\u0C15\u0C41 \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C2A\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C35\u0C21\u0C02",
  shareAsk: "\u0C2A\u0C4D\u0C30\u0C24\u0C3F\u0C38\u0C3E\u0C30\u0C3F \u0C05\u0C21\u0C17\u0C02\u0C21\u0C3F",
  shareAlwaysOpt: "\u0C0E\u0C32\u0C4D\u0C32\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C42",
  shareNever: "\u0C0E\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C42 \u0C35\u0C26\u0C4D\u0C26\u0C41"
};

// src/i18n/i18n.js
var TABLES = { en: en_default, hi: hi_default, mr: mr_default, ta: ta_default, te: te_default };
function pickLang(saved, navLang = "en") {
  if (saved && TABLES[saved]) return saved;
  const base = String(navLang).toLowerCase().split("-")[0];
  return TABLES[base] ? base : "en";
}

// backend/data/seed.json
var seed_default = {
  stores: [
    {
      domain: "localhost",
      name: "Demo Store (local test checkout)",
      adapter: "generic"
    },
    {
      domain: "amazon.in",
      name: "Amazon India",
      adapter: "amazon"
    },
    {
      domain: "amazon.com",
      name: "Amazon",
      adapter: "amazon"
    },
    {
      domain: "flipkart.com",
      name: "Flipkart",
      adapter: "flipkart"
    },
    {
      domain: "ajio.com",
      name: "Ajio",
      adapter: "generic"
    },
    {
      domain: "myntra.com",
      name: "Myntra",
      adapter: "generic"
    }
  ],
  coupons: [
    {
      domain: "localhost",
      code: "SAVE10",
      type: "percent",
      value: 1e3,
      minSpend: 5e4,
      source: "demo",
      stats: {
        tries: 40,
        successes: 36
      }
    },
    {
      domain: "localhost",
      code: "FLAT100",
      type: "flat",
      value: 1e4,
      minSpend: 99900,
      source: "demo",
      stats: {
        tries: 30,
        successes: 24
      }
    },
    {
      domain: "localhost",
      code: "WELCOME50",
      type: "flat",
      value: 5e3,
      minSpend: 0,
      source: "demo",
      stats: {
        tries: 20,
        successes: 15
      }
    },
    {
      domain: "localhost",
      code: "BIG500",
      type: "flat",
      value: 5e4,
      minSpend: 1e6,
      source: "demo",
      stats: {
        tries: 20,
        successes: 2
      }
    },
    {
      domain: "localhost",
      code: "OLD20",
      type: "percent",
      value: 2e3,
      source: "demo",
      stats: {
        tries: 25,
        successes: 0
      }
    },
    {
      domain: "localhost",
      code: "NOPE",
      type: "unknown",
      value: 0,
      source: "demo",
      stats: {
        tries: 10,
        successes: 0
      }
    },
    {
      domain: "ajio.com",
      code: "NEW30",
      source: "zoutons.com (third-party, unverified)",
      firstOrderOnly: true
    },
    {
      domain: "ajio.com",
      code: "NEW10",
      source: "zoutons.com (third-party, unverified)",
      firstOrderOnly: true
    },
    {
      domain: "ajio.com",
      code: "NEW500",
      source: "zoutons.com (third-party, unverified)",
      firstOrderOnly: true
    },
    {
      domain: "ajio.com",
      code: "NEW300",
      source: "zoutons.com (third-party, unverified)",
      firstOrderOnly: true
    },
    {
      domain: "ajio.com",
      code: "NEW25",
      source: "zoutons.com (third-party, unverified)",
      firstOrderOnly: true
    },
    {
      domain: "ajio.com",
      code: "FIRSTBUY",
      source: "zoutons.com (third-party, unverified)",
      firstOrderOnly: true
    },
    {
      domain: "ajio.com",
      code: "FIRSTAPP",
      source: "zoutons.com (third-party, unverified)",
      firstOrderOnly: true
    },
    {
      domain: "ajio.com",
      code: "SALE5",
      source: "zoutons.com (third-party, unverified)",
      minSpend: 99e3
    },
    {
      domain: "ajio.com",
      code: "SALE10",
      source: "zoutons.com (third-party, unverified)",
      minSpend: 219e3
    },
    {
      domain: "ajio.com",
      code: "SALE350",
      source: "zoutons.com (third-party, unverified)",
      minSpend: 249e3
    },
    {
      domain: "ajio.com",
      code: "SAVE5",
      source: "zoutons.com (third-party, unverified)",
      minSpend: 149e3
    },
    {
      domain: "ajio.com",
      code: "WISH",
      source: "zoutons.com (third-party, unverified)",
      minSpend: 199900
    },
    {
      domain: "ajio.com",
      code: "GLOWUP",
      source: "zoutons.com (third-party, unverified)"
    },
    {
      domain: "ajio.com",
      code: "AJIOGRAM20",
      source: "zoutons.com (third-party, unverified)"
    },
    {
      domain: "ajio.com",
      code: "SWEETHOME",
      source: "zoutons.com (third-party, unverified)"
    },
    {
      domain: "ajio.com",
      code: "FREEDEL",
      source: "zoutons.com (third-party, unverified)",
      minSpend: 79900
    },
    {
      domain: "ajio.com",
      code: "FASHIONATION10",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 199e3
    },
    {
      domain: "ajio.com",
      code: "FASHIONATION15",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 299e3
    },
    {
      domain: "ajio.com",
      code: "AJIOMANIA500",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 449e3
    },
    {
      domain: "ajio.com",
      code: "AJIOMANIA800",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 559e3
    },
    {
      domain: "ajio.com",
      code: "FLASHSALE",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 289e3
    },
    {
      domain: "ajio.com",
      code: "WINTERSPL",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 249e3
    },
    {
      domain: "myntra.com",
      code: "MYNTRA100",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 49900,
      firstOrderOnly: true
    },
    {
      domain: "myntra.com",
      code: "MYNTRA200",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 89900,
      firstOrderOnly: true
    },
    {
      domain: "myntra.com",
      code: "MYNTRA300",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 169900,
      firstOrderOnly: true
    },
    {
      domain: "myntra.com",
      code: "MYNTRA400",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 209900,
      firstOrderOnly: true
    },
    {
      domain: "myntra.com",
      code: "MYNTRA500",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 299900,
      firstOrderOnly: true
    },
    {
      domain: "myntra.com",
      code: "MYNTRASAVE",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 49900
    },
    {
      domain: "myntra.com",
      code: "NORETURNX",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 39900
    },
    {
      domain: "myntra.com",
      code: "EXTRA50",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 4e4
    },
    {
      domain: "myntra.com",
      code: "SPORTS20OFF",
      source: "gopaisa.com (third-party, unverified)"
    },
    {
      domain: "myntra.com",
      code: "MFCGET",
      source: "gopaisa.com (third-party, unverified)"
    },
    {
      domain: "myntra.com",
      code: "MFC10",
      source: "gopaisa.com (third-party, unverified)"
    },
    {
      domain: "myntra.com",
      code: "FESTIVE10",
      source: "gopaisa.com (third-party, unverified)",
      minSpend: 13e4
    }
  ]
};

// src/adapters/recipe.js
var ID_RE = /^[a-z0-9-]{2,40}$/;
var HOST_RE = /^[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?$/;
var TAG_RE = /^[a-z][a-z0-9-]{0,20}$/i;
var ATTR_RE = /^[a-z][a-z0-9_:.-]{0,60}$/i;
var MAX_STR = 200;
var MAX_LIST = 10;
var isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
function str(v, path, errors, { required = false } = {}) {
  if (v === void 0 || v === null) {
    if (required) errors.push(`${path}: required`);
    return void 0;
  }
  if (typeof v !== "string") {
    errors.push(`${path}: must be a string`);
    return void 0;
  }
  if (v.length === 0 || v.length > MAX_STR) {
    errors.push(`${path}: must be 1-${MAX_STR} characters`);
    return void 0;
  }
  return v;
}
function strList(v, path, errors, { max = MAX_LIST, item = null } = {}) {
  if (v === void 0 || v === null) return void 0;
  if (!Array.isArray(v)) {
    errors.push(`${path}: must be an array`);
    return void 0;
  }
  if (v.length > max) {
    errors.push(`${path}: at most ${max} items`);
    return void 0;
  }
  const out = [];
  v.forEach((s, i) => {
    const ok = str(s, `${path}[${i}]`, errors);
    if (ok === void 0) return;
    if (item && !item.test(ok)) {
      errors.push(`${path}[${i}]: invalid value`);
      return;
    }
    out.push(ok);
  });
  return out;
}
function locator(v, path, errors) {
  if (v === void 0 || v === null) return void 0;
  if (!isObj(v)) {
    errors.push(`${path}: must be an object`);
    return void 0;
  }
  const out = {};
  const css = str(v.css, `${path}.css`, errors);
  const text = strList(v.text, `${path}.text`, errors);
  const tag = strList(v.tag, `${path}.tag`, errors, { item: TAG_RE });
  if (css) out.css = css;
  if (text?.length) out.text = text;
  if (tag?.length) out.tag = tag;
  if (!out.css && !out.text) {
    errors.push(`${path}: needs css or text`);
    return void 0;
  }
  return out;
}
function codeLocator(v, path, errors) {
  if (!isObj(v)) {
    errors.push(`${path}: must be an object`);
    return void 0;
  }
  if (v.attr !== void 0) {
    const a = str(v.attr, `${path}.attr`, errors);
    if (a && !ATTR_RE.test(a)) {
      errors.push(`${path}.attr: invalid attribute name`);
      return void 0;
    }
    return a ? { attr: a } : void 0;
  }
  const css = str(v.css, `${path}.css`, errors, { required: true });
  return css ? { css } : void 0;
}
function pageDef(v, path, errors, { required }) {
  if (v === void 0 || v === null) {
    if (required) errors.push(`${path}: required`);
    return void 0;
  }
  if (!isObj(v)) {
    errors.push(`${path}: must be an object`);
    return void 0;
  }
  const prefixes = strList(v.pathPrefixes, `${path}.pathPrefixes`, errors, { item: /^\// });
  if (!prefixes?.length) {
    errors.push(`${path}.pathPrefixes: needs at least one path starting with /`);
    return void 0;
  }
  return { pathPrefixes: prefixes };
}
function clampInt(v, lo, hi, dflt) {
  const n = Number.isFinite(v) ? Math.round(v) : dflt;
  return Math.min(hi, Math.max(lo, n));
}
function validateRecipe(input) {
  const errors = [];
  if (!isObj(input)) return { ok: false, errors: ["recipe: must be an object"], recipe: null };
  const r = {};
  const id = str(input.id, "id", errors, { required: true });
  if (id && !ID_RE.test(id)) errors.push("id: must match ^[a-z0-9-]{2,40}$");
  else if (id) r.id = id;
  if (!Number.isInteger(input.version) || input.version < 1) errors.push("version: must be an integer >= 1");
  else r.version = input.version;
  const hosts = strList(input.hosts, "hosts", errors, { item: HOST_RE });
  if (!hosts?.length) errors.push("hosts: needs at least one host");
  else r.hosts = hosts.map((h) => h.toLowerCase());
  if (input.verified !== void 0 && typeof input.verified !== "boolean") errors.push("verified: must be a boolean");
  r.verified = input.verified === true;
  const pages = {};
  if (!isObj(input.pages)) errors.push("pages: required");
  else {
    const bag = pageDef(input.pages.bag, "pages.bag", errors, { required: true });
    const payment = pageDef(input.pages.payment, "pages.payment", errors, { required: false });
    if (bag) pages.bag = bag;
    if (payment) pages.payment = payment;
  }
  r.pages = pages;
  const c = isObj(input.coupon) ? input.coupon : null;
  if (!c) errors.push("coupon: required");
  else {
    const coupon = {};
    for (const k of ["open", "panel", "input", "apply", "close", "message", "applied", "remove", "deselect", "confirm", "applyConfirm"]) {
      const l = locator(c[k], `coupon.${k}`, errors);
      if (l) coupon[k] = l;
    }
    if (c.panelClosesOnApply !== void 0 && typeof c.panelClosesOnApply !== "boolean") errors.push("coupon.panelClosesOnApply: must be a boolean");
    coupon.panelClosesOnApply = c.panelClosesOnApply === true;
    if (!coupon.open && !coupon.input) errors.push("coupon: needs open or input");
    if (c.listed !== void 0) {
      if (!isObj(c.listed)) errors.push("coupon.listed: must be an object");
      else {
        const item = locator(c.listed.item, "coupon.listed.item", errors);
        const code = codeLocator(c.listed.code, "coupon.listed.code", errors);
        const select = locator(c.listed.select, "coupon.listed.select", errors);
        const inel = strList(c.listed.ineligibleText, "coupon.listed.ineligibleText", errors);
        if (item && code) coupon.listed = { item, code, ...select ? { select } : {}, ineligibleText: inel ?? [] };
        else if (!item || !code) errors.push("coupon.listed: needs item and code");
      }
    }
    r.coupon = coupon;
  }
  const total = locator(input.total, "total", errors);
  if (total) r.total = total;
  if (input.offers !== void 0) {
    if (!isObj(input.offers)) errors.push("offers: must be an object");
    else {
      const container = locator(input.offers.container, "offers.container", errors);
      const item = locator(input.offers.item, "offers.item", errors);
      if (container) r.offers = { container, ...item ? { item } : {} };
    }
  }
  const wall = locator(input.loginWall, "loginWall", errors);
  if (wall) r.loginWall = wall;
  const lim = isObj(input.limits) ? input.limits : {};
  const onlyLocal = r.hosts?.every((h) => h === "localhost") ?? false;
  r.limits = {
    maxAttempts: clampInt(lim.maxAttempts, 1, 6, 6),
    delayMs: clampInt(lim.delayMs, onlyLocal ? 0 : 1500, 1e4, 1500),
    jitterMs: clampInt(lim.jitterMs, 0, 5e3, 1e3)
  };
  return errors.length ? { ok: false, errors, recipe: null } : { ok: true, errors: [], recipe: r };
}

// backend/data/recipes/demo-modal.json
var demo_modal_default = {
  id: "demo-modal",
  version: 1,
  hosts: ["localhost"],
  verified: false,
  pages: {
    bag: { pathPrefixes: ["/modal.html"] },
    payment: { pathPrefixes: ["/payment.html"] }
  },
  coupon: {
    open: { text: ["apply coupon"], tag: ["button", "a"] },
    panel: { css: "[role=dialog]" },
    input: { css: "input[name=coupon]" },
    apply: { text: ["check"], tag: ["button"] },
    close: { text: ["close"], tag: ["button"] },
    panelClosesOnApply: true,
    listed: {
      item: { css: "[data-coupon]" },
      code: { attr: "data-coupon" },
      select: { css: "input[type=radio]" },
      ineligibleText: ["not applicable"]
    },
    message: { css: "[role=alert]" },
    applied: { text: ["coupon applied"] },
    remove: { text: ["remove"], tag: ["button", "a"] }
  },
  total: { css: "[data-total]" },
  offers: { container: { css: "#offers" } },
  loginWall: { text: ["login to apply"] },
  limits: { maxAttempts: 6, delayMs: 1500, jitterMs: 1e3 }
};

// backend/data/recipes/myntra.json
var myntra_default = {
  id: "myntra",
  version: 2,
  hosts: [
    "www.myntra.com",
    "myntra.com"
  ],
  verified: true,
  pages: {
    bag: {
      pathPrefixes: [
        "/checkout/cart"
      ]
    },
    payment: {
      pathPrefixes: [
        "/checkout/payment"
      ]
    }
  },
  coupon: {
    open: {
      css: ".coupons-base-content button"
    },
    panel: {
      css: ".couponsModal-base-modalContainer"
    },
    input: {
      css: "#coupon-input-field"
    },
    apply: {
      css: ".couponsForm-base-applyButton"
    },
    message: {
      css: ".couponsForm-base-errorMessage"
    },
    applied: {
      css: ".coupons-base-applied"
    },
    panelClosesOnApply: true,
    listed: {
      item: {
        css: ".coupon-base-validCouponContainer"
      },
      code: {
        css: ".coupon-base-labelChecked, .coupon-base-labelUnchecked"
      },
      ineligibleText: [
        "more to apply"
      ]
    },
    deselect: {
      css: ".coupon-base-labelChecked"
    },
    confirm: {
      css: "#applyCoupon"
    },
    applyConfirm: {
      css: "#applyCoupon"
    }
  },
  total: {
    css: ".priceDetail-base-total .priceDetail-base-value"
  },
  offers: {
    container: {
      css: ".bankOffersV2-base-container"
    },
    item: {
      css: ".bankOffersV2-base-offerBody"
    }
  },
  limits: {
    maxAttempts: 6,
    delayMs: 1500,
    jitterMs: 1e3
  }
};

// backend/data/recipes/ajio.json
var ajio_default = {
  id: "ajio",
  version: 1,
  hosts: [
    "www.ajio.com",
    "ajio.com"
  ],
  verified: true,
  pages: {
    bag: {
      pathPrefixes: [
        "/cart"
      ]
    },
    payment: {
      pathPrefixes: [
        "/payment"
      ]
    }
  },
  coupon: {
    input: {
      css: "#couponCodeInput"
    },
    apply: {
      css: ".input-box-div .apply-button"
    },
    message: {
      css: ".voucher-error"
    },
    applied: {
      css: ".applied-voucher .voucher-label"
    },
    remove: {
      css: '.ic-delete[aria-label^="Remove coupon"]'
    },
    listed: {
      item: {
        css: ".voucher-list-item"
      },
      code: {
        css: ".voucher-code"
      },
      select: {
        css: "input.offer-radio"
      },
      ineligibleText: []
    }
  },
  total: {
    css: "#orderTotal .price-value"
  },
  limits: {
    maxAttempts: 6,
    delayMs: 1500,
    jitterMs: 1e3
  }
};

// src/adapters/bundledRecipes.js
var RAW = [demo_modal_default, myntra_default, ajio_default];
var bundledRecipes = RAW.map((r) => validateRecipe(r)).filter((v) => v.ok).map((v) => v.recipe);
function recipeForHost(host, list = bundledRecipes) {
  const h = String(host || "").toLowerCase().replace(/^www\./, "");
  return list.find((r) => r.hosts.includes(h)) ?? null;
}

// src/adapters/recipeSource.js
var normHost = (h) => String(h || "").toLowerCase().replace(/^www\./, "");
function chooseRecipe(host, serverRaw, bundledRaw) {
  const h = normHost(host);
  const accept = (raw) => {
    if (!raw) return null;
    const v = validateRecipe(raw);
    return v.ok && v.recipe.hosts.includes(h) ? v.recipe : null;
  };
  const server = accept(serverRaw);
  const local = accept(bundledRaw);
  if (server && local) return server.version >= local.version ? server : local;
  return server ?? local ?? null;
}

// src/lib/lastResult.js
var LAST_MAX_AGE_MS = 30 * 60 * 1e3;
var lastKey = (host) => `pf:last:${host}`;
var CODE_RE2 = /^[A-Z0-9_-]{1,32}$/;
var HOST_RE2 = /^[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?$/;
function makeLast(msg, now = Date.now()) {
  const host = String(msg?.host || "").toLowerCase();
  const code = String(msg?.code || "").toUpperCase();
  if (!HOST_RE2.test(host) || !CODE_RE2.test(code)) return null;
  if (!Number.isInteger(msg.baseline) || !Number.isInteger(msg.payable) || msg.baseline < 0 || msg.payable < 0) return null;
  return { host, code, baseline: msg.baseline, payable: msg.payable, at: now };
}
function freshLast(entry, host, now = Date.now()) {
  if (!entry || typeof entry.at !== "number") return null;
  if (entry.host !== String(host).toLowerCase()) return null;
  const age = now - entry.at;
  return age >= 0 && age <= LAST_MAX_AGE_MS ? entry : null;
}

// src/background/serviceWorker.js
var SHARE_MODES = ["ask", "always", "never"];
async function clientIdOf(s) {
  if (s.clientId) return s.clientId;
  const clientId = crypto.randomUUID();
  await chrome.storage.local.set({ clientId });
  return clientId;
}
var DEFAULTS = { apiBase: "http://localhost:3000", telemetry: false, userCodes: [], lang: null, shareMode: "ask" };
var SERVER_K = 30;
var TTL = 6 * 36e5;
async function settings() {
  const s = await chrome.storage.local.get(["apiBase", "telemetry", "userCodes", "lang", "clientId", "cache", "shareMode"]);
  return { ...DEFAULTS, ...s };
}
async function loadCache() {
  const { cache } = await chrome.storage.local.get("cache");
  return TtlCache.restore(cache, TTL);
}
async function saveCache(c) {
  await chrome.storage.local.set({ cache: c.serialize() });
}
async function fetchServer(apiBase, domain) {
  const cache = await loadCache();
  const hit = cache.get(domain);
  if (hit) return hit;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 4e3);
    const r = await fetch(`${apiBase.replace(/\/$/, "")}/api/v1/coupons/${encodeURIComponent(domain)}?k=${SERVER_K}`, { signal: ctrl.signal });
    clearTimeout(timer);
    if (!r.ok) return [];
    const { coupons } = await r.json();
    cache.set(domain, coupons);
    await saveCache(cache);
    return coupons;
  } catch {
    return [];
  }
}
async function getRecipe(apiBase, host) {
  const bundled = recipeForHost(host, bundledRecipes);
  const cache = await loadCache();
  const key = `recipe:${host}`;
  let entry = cache.get(key);
  if (entry === void 0) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 4e3);
      const r = await fetch(`${apiBase.replace(/\/$/, "")}/api/v1/stores/${encodeURIComponent(host)}/config`, { signal: ctrl.signal });
      clearTimeout(timer);
      if (r.ok) entry = { recipe: (await r.json()).recipe ?? null };
      else if (r.status === 404) entry = { recipe: null };
      if (entry) {
        cache.set(key, entry);
        await saveCache(cache);
      }
    } catch {
    }
  }
  return chooseRecipe(host, entry?.recipe ?? null, bundled);
}
async function runOnTab(tabId, url) {
  const host = normalizeHost(new URL(url).hostname);
  const s = await settings();
  const server = await fetchServer(s.apiBase, host);
  const seedForHost = seed_default.coupons.filter((c) => c.domain === host);
  const known = buildCandidates({ server, seed: seedForHost, user: s.userCodes }, SERVER_K).map((c) => {
    const out = { code: c.code, origin: c.origin };
    for (const k of META_KEYS) if (c[k] != null) out[k] = c[k];
    return out;
  });
  const recipe = await getRecipe(s.apiBase, host);
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  const stored = await chrome.storage.local.get("overrides");
  await chrome.tabs.sendMessage(tabId, {
    type: "PF_START",
    candidates: known,
    recipe,
    lang: pickLang(s.lang, chrome.i18n.getUILanguage()),
    overrides: stored.overrides?.[host],
    shareMode: SHARE_MODES.includes(s.shareMode) ? s.shareMode : "ask"
  });
  return { ok: true, count: known.length };
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "PF_RUN") {
    runOnTab(msg.tabId, msg.url).then(sendResponse, (e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }
  if (msg?.type === "PF_SAVE_LAST") {
    const entry = makeLast(msg);
    if (entry) chrome.storage.session.set({ [lastKey(entry.host)]: entry });
    return false;
  }
  if (msg?.type === "PF_GET_LAST") {
    const host = String(msg.host || "").toLowerCase();
    chrome.storage.session.get(lastKey(host)).then((r) => sendResponse(freshLast(r[lastKey(host)], host)), () => sendResponse(null));
    return true;
  }
  if (msg?.type === "PF_SHARE") {
    (async () => {
      const s = await settings();
      if (s.shareMode === "never") return sendResponse({ ok: false });
      const r = await fetch(`${s.apiBase.replace(/\/$/, "")}/api/v1/coupons/share`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: msg.domain, code: msg.code, clientId: await clientIdOf(s) })
      }).catch(() => null);
      sendResponse({ ok: !!r?.ok });
    })();
    return true;
  }
  if (msg?.type === "PF_SET_SHARE_MODE") {
    if (SHARE_MODES.includes(msg.mode)) chrome.storage.local.set({ shareMode: msg.mode });
    return false;
  }
  if (msg?.type === "PF_REPORT") {
    (async () => {
      const s = await settings();
      if (!s.telemetry) return;
      const clientId = await clientIdOf(s);
      await fetch(`${s.apiBase.replace(/\/$/, "")}/api/v1/coupons/report`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: msg.domain, code: msg.code, outcome: msg.outcome, clientId })
      }).catch(() => {
      });
    })();
    return false;
  }
});
chrome.runtime.onInstalled.addListener(() => chrome.alarms.create("pf-sweep", { periodInMinutes: 60 }));
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== "pf-sweep") return;
  const c = await loadCache();
  c.sweep();
  await saveCache(c);
});
